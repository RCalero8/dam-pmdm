import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormEditor2 } from './component/form-editor2/form-editor2';

@Component({
  imports: [RouterOutlet, FormEditor2 ],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  protected readonly title = signal('form-reactive');
}
