import { t as __commonJSMin } from "./rolldown-runtime-DYf_mQCB.js";
// node_modules/@angular/core/fesm2022/_effect-chunk.mjs
/**
* @license Angular v22.2.5
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var activeConsumer = [null];
var inNotificationPhase = [false];
var epoch = 1;
var postProducerCreatedFn = null;
var SIGNAL = /* @__PURE__ */ Symbol("SIGNAL");
function setActiveConsumer(consumer) {
	const prev = activeConsumer[0];
	activeConsumer[0] = consumer;
	return prev;
}
function getActiveConsumer() {
	return activeConsumer[0];
}
function isInNotificationPhase() {
	return inNotificationPhase[0];
}
var REACTIVE_NODE = {
	version: 0,
	lastCleanEpoch: 0,
	dirty: false,
	producers: void 0,
	producersTail: void 0,
	consumers: void 0,
	consumersTail: void 0,
	recomputing: false,
	consumerAllowSignalWrites: false,
	consumerIsAlwaysLive: false,
	kind: "unknown",
	producerMustRecompute: () => false,
	producerRecomputeValue: () => {},
	consumerMarkedDirty: () => {},
	consumerOnSignalRead: () => {}
};
function producerAccessed(node) {
	if (inNotificationPhase[0]) throw new Error(typeof ngDevMode !== "undefined" && ngDevMode ? `Assertion error: signal read during notification phase` : "");
	const consumer = activeConsumer[0];
	if (consumer === null) return;
	consumer.consumerOnSignalRead(node);
	const prevProducerLink = consumer.producersTail;
	if (prevProducerLink !== void 0 && prevProducerLink.producer === node) return;
	let nextProducerLink = void 0;
	const isRecomputing = consumer.recomputing;
	if (isRecomputing) {
		nextProducerLink = prevProducerLink !== void 0 ? prevProducerLink.nextProducer : consumer.producers;
		if (nextProducerLink !== void 0 && nextProducerLink.producer === node) {
			consumer.producersTail = nextProducerLink;
			nextProducerLink.lastReadVersion = node.version;
			nextProducerLink.knownValidAtEpoch = epoch;
			return;
		}
	}
	const prevConsumerLink = node.consumersTail;
	if (prevConsumerLink !== void 0 && prevConsumerLink.consumer === consumer && (!isRecomputing || prevConsumerLink.knownValidAtEpoch === epoch)) return;
	const isLive = consumerIsLive(consumer);
	const newLink = {
		producer: node,
		consumer,
		nextProducer: nextProducerLink,
		prevConsumer: void 0,
		knownValidAtEpoch: epoch,
		lastReadVersion: node.version,
		nextConsumer: void 0
	};
	consumer.producersTail = newLink;
	if (prevProducerLink !== void 0) prevProducerLink.nextProducer = newLink;
	else consumer.producers = newLink;
	if (isLive) producerAddLiveConsumer(node, newLink);
}
function producerIncrementEpoch() {
	epoch++;
}
function producerUpdateValueVersion(node) {
	if (consumerIsLive(node) && !node.dirty) return;
	if (!node.dirty && node.lastCleanEpoch === epoch) return;
	if (!node.producerMustRecompute(node) && !consumerPollProducersForChange(node)) {
		producerMarkClean(node);
		return;
	}
	node.producerRecomputeValue(node);
	producerMarkClean(node);
}
function producerNotifyConsumers(node) {
	if (node.consumers === void 0) return;
	const prev = inNotificationPhase[0];
	inNotificationPhase[0] = true;
	try {
		for (let link = node.consumers; link !== void 0; link = link.nextConsumer) {
			const consumer = link.consumer;
			if (!consumer.dirty) consumerMarkDirty(consumer);
		}
	} finally {
		inNotificationPhase[0] = prev;
	}
}
function producerUpdatesAllowed() {
	return activeConsumer[0]?.consumerAllowSignalWrites !== false;
}
function consumerMarkDirty(node) {
	node.dirty = true;
	producerNotifyConsumers(node);
	node.consumerMarkedDirty?.(node);
}
function producerMarkClean(node) {
	node.dirty = false;
	node.lastCleanEpoch = epoch;
}
function consumerBeforeComputation(node) {
	if (node) resetConsumerBeforeComputation(node);
	return setActiveConsumer(node);
}
function resetConsumerBeforeComputation(node) {
	if (node.producersTail?.knownValidAtEpoch === epoch) {
		let producer = node.producers;
		while (producer !== void 0) {
			producer.knownValidAtEpoch = null;
			producer = producer.nextProducer;
		}
	}
	node.producersTail = void 0;
	node.recomputing = true;
}
function consumerAfterComputation(node, prevConsumer) {
	setActiveConsumer(prevConsumer);
	if (node) finalizeConsumerAfterComputation(node);
}
function finalizeConsumerAfterComputation(node) {
	node.recomputing = false;
	const producersTail = node.producersTail;
	let toRemove = producersTail !== void 0 ? producersTail.nextProducer : node.producers;
	if (toRemove !== void 0) {
		if (consumerIsLive(node)) do
			toRemove = producerRemoveLiveConsumerLink(toRemove);
		while (toRemove !== void 0);
		if (producersTail !== void 0) producersTail.nextProducer = void 0;
		else node.producers = void 0;
	}
}
function consumerPollProducersForChange(node) {
	for (let link = node.producers; link !== void 0; link = link.nextProducer) {
		const producer = link.producer;
		const seenVersion = link.lastReadVersion;
		if (seenVersion !== producer.version) return true;
		producerUpdateValueVersion(producer);
		if (seenVersion !== producer.version) return true;
	}
	return false;
}
function consumerDestroy(node) {
	if (consumerIsLive(node)) {
		let link = node.producers;
		while (link !== void 0) link = producerRemoveLiveConsumerLink(link);
	}
	node.producers = void 0;
	node.producersTail = void 0;
	node.consumers = void 0;
	node.consumersTail = void 0;
}
function producerAddLiveConsumer(node, link) {
	const consumersTail = node.consumersTail;
	const wasLive = consumerIsLive(node);
	if (consumersTail !== void 0) {
		link.nextConsumer = consumersTail.nextConsumer;
		consumersTail.nextConsumer = link;
	} else {
		link.nextConsumer = void 0;
		node.consumers = link;
	}
	link.prevConsumer = consumersTail;
	node.consumersTail = link;
	if (!wasLive) for (let link = node.producers; link !== void 0; link = link.nextProducer) producerAddLiveConsumer(link.producer, link);
}
function producerRemoveLiveConsumerLink(link) {
	const producer = link.producer;
	const nextProducer = link.nextProducer;
	const nextConsumer = link.nextConsumer;
	const prevConsumer = link.prevConsumer;
	link.nextConsumer = void 0;
	link.prevConsumer = void 0;
	if (nextConsumer !== void 0) nextConsumer.prevConsumer = prevConsumer;
	else producer.consumersTail = prevConsumer;
	if (prevConsumer !== void 0) prevConsumer.nextConsumer = nextConsumer;
	else {
		producer.consumers = nextConsumer;
		if (!consumerIsLive(producer)) {
			let producerLink = producer.producers;
			while (producerLink !== void 0) producerLink = producerRemoveLiveConsumerLink(producerLink);
		}
	}
	return nextProducer;
}
function consumerIsLive(node) {
	return node.consumerIsAlwaysLive || node.consumers !== void 0;
}
function runPostProducerCreatedFn(node) {
	postProducerCreatedFn?.(node);
}
function defaultEquals(a, b) {
	return Object.is(a, b);
}
function createComputed(computation, equal) {
	const node = Object.create(COMPUTED_NODE);
	node.computation = computation;
	if (equal !== void 0) node.equal = equal;
	const computed = () => {
		producerUpdateValueVersion(node);
		producerAccessed(node);
		if (node.value === ERRORED) throw node.error;
		return node.value;
	};
	computed[SIGNAL] = node;
	if (typeof ngDevMode !== "undefined" && ngDevMode) computed.toString = () => `[Computed${node.debugName ? " (" + node.debugName + ")" : ""}: ${String(node.value)}]`;
	runPostProducerCreatedFn(node);
	return computed;
}
var UNSET = /* @__PURE__ */ Symbol("UNSET");
var COMPUTING = /* @__PURE__ */ Symbol("COMPUTING");
var ERRORED = /* @__PURE__ */ Symbol("ERRORED");
var COMPUTED_NODE = /* @__PURE__ */ (() => {
	return {
		...REACTIVE_NODE,
		value: UNSET,
		dirty: true,
		error: null,
		equal: defaultEquals,
		kind: "computed",
		producerMustRecompute(node) {
			return node.value === UNSET || node.value === COMPUTING;
		},
		producerRecomputeValue(node) {
			if (node.value === COMPUTING) throw new Error(typeof ngDevMode !== "undefined" && ngDevMode ? "Detected cycle in computations." : "");
			const oldValue = node.value;
			node.value = COMPUTING;
			const prevConsumer = consumerBeforeComputation(node);
			let newValue;
			let wasEqual = false;
			try {
				newValue = node.computation();
				setActiveConsumer(null);
				wasEqual = oldValue !== UNSET && oldValue !== ERRORED && newValue !== ERRORED && node.equal(oldValue, newValue);
			} catch (err) {
				newValue = ERRORED;
				node.error = err;
			} finally {
				consumerAfterComputation(node, prevConsumer);
			}
			if (wasEqual) {
				node.value = oldValue;
				return;
			}
			node.value = newValue;
			node.version++;
		}
	};
})();
function defaultThrowError() {
	throw new Error();
}
var throwInvalidWriteToSignalErrorFn = defaultThrowError;
function throwInvalidWriteToSignalError(node) {
	throwInvalidWriteToSignalErrorFn(node);
}
function setThrowInvalidWriteToSignalError(fn) {
	throwInvalidWriteToSignalErrorFn = fn;
}
var postSignalSetFn = null;
function createSignal(initialValue, equal) {
	const node = Object.create(SIGNAL_NODE);
	node.value = initialValue;
	if (equal !== void 0) node.equal = equal;
	const getter = () => signalGetFn(node);
	getter[SIGNAL] = node;
	if (typeof ngDevMode !== "undefined" && ngDevMode) getter.toString = () => `[Signal${node.debugName ? " (" + node.debugName + ")" : ""}: ${String(node.value)}]`;
	runPostProducerCreatedFn(node);
	const set = (newValue) => signalSetFn(node, newValue);
	const update = (updateFn) => signalUpdateFn(node, updateFn);
	return [
		getter,
		set,
		update
	];
}
function signalGetFn(node) {
	producerAccessed(node);
	return node.value;
}
function signalSetFn(node, newValue) {
	if (!producerUpdatesAllowed()) throwInvalidWriteToSignalError(node);
	if (!node.equal(node.value, newValue)) {
		node.value = newValue;
		signalValueChanged(node);
	}
}
function signalUpdateFn(node, updater) {
	if (!producerUpdatesAllowed()) throwInvalidWriteToSignalError(node);
	signalSetFn(node, updater(node.value));
}
var SIGNAL_NODE = /* @__PURE__ */ (() => {
	return {
		...REACTIVE_NODE,
		equal: defaultEquals,
		value: void 0,
		kind: "signal"
	};
})();
function signalValueChanged(node) {
	node.version++;
	producerIncrementEpoch();
	producerNotifyConsumers(node);
	postSignalSetFn?.(node);
}
var BASE_EFFECT_NODE = /* @__PURE__ */ (() => ({
	...REACTIVE_NODE,
	consumerIsAlwaysLive: true,
	consumerAllowSignalWrites: true,
	dirty: true,
	kind: "effect"
}))();
function runEffect(node) {
	node.dirty = false;
	if (node.version > 0 && !consumerPollProducersForChange(node)) return;
	node.version++;
	const prevNode = consumerBeforeComputation(node);
	try {
		node.cleanup();
		node.fn();
	} finally {
		consumerAfterComputation(node, prevNode);
	}
}
// node_modules/@angular/core/fesm2022/_not_found-chunk.mjs
/**
* @license Angular v22.2.5
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _currentInjector = [void 0];
function getCurrentInjector() {
	return _currentInjector[0];
}
function setCurrentInjector(injector) {
	const former = _currentInjector[0];
	_currentInjector[0] = injector;
	return former;
}
var NOT_FOUND = Symbol("NotFound");
function isNotFound(e) {
	return e === NOT_FOUND || e?.name === "ɵNotFound";
}
// node_modules/@angular/core/fesm2022/_untracked-chunk.mjs
/**
* @license Angular v22.2.5
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function createLinkedSignal(sourceFn, computationFn, equalityFn) {
	const node = Object.create(LINKED_SIGNAL_NODE);
	node.source = sourceFn;
	node.computation = computationFn;
	if (equalityFn != void 0) node.equal = equalityFn;
	const linkedSignalGetter = () => {
		producerUpdateValueVersion(node);
		producerAccessed(node);
		if (node.value === ERRORED) throw node.error;
		return node.value;
	};
	const getter = linkedSignalGetter;
	getter[SIGNAL] = node;
	if (typeof ngDevMode !== "undefined" && ngDevMode) getter.toString = () => `[LinkedSignal${node.debugName ? " (" + node.debugName + ")" : ""}: ${String(node.value)}]`;
	runPostProducerCreatedFn(node);
	return getter;
}
function linkedSignalSetFn(node, newValue) {
	producerUpdateValueVersion(node);
	signalSetFn(node, newValue);
	producerMarkClean(node);
}
function linkedSignalUpdateFn(node, updater) {
	producerUpdateValueVersion(node);
	if (node.value === ERRORED) throw node.error;
	signalUpdateFn(node, updater);
	producerMarkClean(node);
}
var LINKED_SIGNAL_NODE = /* @__PURE__ */ (() => {
	return {
		...REACTIVE_NODE,
		value: UNSET,
		dirty: true,
		error: null,
		equal: defaultEquals,
		kind: "linkedSignal",
		producerMustRecompute(node) {
			return node.value === UNSET || node.value === COMPUTING;
		},
		producerRecomputeValue(node) {
			if (node.value === COMPUTING) throw new Error(typeof ngDevMode !== "undefined" && ngDevMode ? "Detected cycle in computations." : "");
			const oldValue = node.value;
			node.value = COMPUTING;
			const prevConsumer = consumerBeforeComputation(node);
			let newValue;
			let wasEqual = false;
			try {
				const newSourceValue = node.source();
				const oldValueValid = oldValue !== UNSET && oldValue !== ERRORED;
				const prev = oldValueValid ? {
					source: node.sourceValue,
					value: oldValue
				} : void 0;
				newValue = node.computation(newSourceValue, prev);
				node.sourceValue = newSourceValue;
				setActiveConsumer(null);
				wasEqual = oldValueValid && newValue !== ERRORED && node.equal(oldValue, newValue);
			} catch (err) {
				newValue = ERRORED;
				node.error = err;
			} finally {
				consumerAfterComputation(node, prevConsumer);
			}
			if (wasEqual) {
				node.value = oldValue;
				return;
			}
			node.value = newValue;
			node.version++;
		}
	};
})();
function untracked$1(nonReactiveReadsFn) {
	const prevConsumer = setActiveConsumer(null);
	try {
		return nonReactiveReadsFn();
	} finally {
		setActiveConsumer(prevConsumer);
	}
}
// node_modules/@angular/core/fesm2022/primitives-signals.mjs
/**
* @license Angular v22.2.5
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var formatter = {
	header: (sig, config) => {
		if (!isSignal$1(sig) || config?.ngSkipFormatting) return null;
		let value;
		try {
			value = sig();
		} catch (e) {
			return ["span", `Signal(⚠️ Error)${e.message ? `: ${e.message}` : ""}`];
		}
		const kind = "computation" in sig[SIGNAL] ? "Computed" : "Signal";
		const isPrimitive = value === null || !Array.isArray(value) && typeof value !== "object";
		return [
			"span",
			{},
			[
				"span",
				{},
				`${kind}(`
			],
			(() => {
				if (isSignal$1(value)) return formatter.header(value, config);
				else if (isPrimitive && value !== void 0 && typeof value !== "function") return ["object", { object: value }];
				else return prettifyPreview(value);
			})(),
			[
				"span",
				{},
				`)`
			]
		];
	},
	hasBody: (sig, config) => {
		if (!isSignal$1(sig)) return false;
		try {
			sig();
		} catch {
			return false;
		}
		return !config?.ngSkipFormatting;
	},
	body: (sig, config) => {
		const color = "var(--sys-color-primary)";
		return [
			"div",
			{ style: `background: #FFFFFF10; padding-left: 4px; padding-top: 2px; padding-bottom: 2px;` },
			[
				"div",
				{ style: `color: ${color}` },
				"Signal value: "
			],
			[
				"div",
				{ style: `padding-left: .5rem;` },
				["object", {
					object: sig(),
					config
				}]
			],
			[
				"div",
				{ style: `color: ${color}` },
				"Signal function: "
			],
			[
				"div",
				{ style: `padding-left: .5rem;` },
				["object", {
					object: sig,
					config: {
						...config,
						ngSkipFormatting: true
					}
				}]
			]
		];
	}
};
function prettifyPreview(value) {
	if (value === null) return "null";
	if (Array.isArray(value)) return `Array(${value.length})`;
	if (value instanceof Element) return `<${value.tagName.toLowerCase()}>`;
	if (value instanceof URL) return `URL`;
	switch (typeof value) {
		case "undefined": return "undefined";
		case "function": if ("prototype" in value) return "class";
		else return "() => {…}";
		case "object": if (value.constructor.name === "Object") return "{…}";
		else return `${value.constructor.name} {}`;
		default: return ["object", {
			object: value,
			config: { ngSkipFormatting: true }
		}];
	}
}
function isSignal$1(value) {
	return value[SIGNAL] !== void 0;
}
function installDevToolsSignalFormatter() {
	globalThis.devtoolsFormatters ??= [];
	if (!globalThis.devtoolsFormatters.some((f) => f === formatter)) globalThis.devtoolsFormatters.push(formatter);
}
if (typeof ngDevMode === "undefined" || ngDevMode) installDevToolsSignalFormatter();
// node_modules/rxjs/dist/cjs/internal/util/isFunction.js
var require_isFunction = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isFunction = void 0;
	function isFunction(value) {
		return typeof value === "function";
	}
	exports.isFunction = isFunction;
}));
// node_modules/rxjs/dist/cjs/internal/util/createErrorClass.js
var require_createErrorClass = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createErrorClass = void 0;
	function createErrorClass(createImpl) {
		var _super = function(instance) {
			Error.call(instance);
			instance.stack = (/* @__PURE__ */ new Error()).stack;
		};
		var ctorFunc = createImpl(_super);
		ctorFunc.prototype = Object.create(Error.prototype);
		ctorFunc.prototype.constructor = ctorFunc;
		return ctorFunc;
	}
	exports.createErrorClass = createErrorClass;
}));
// node_modules/rxjs/dist/cjs/internal/util/UnsubscriptionError.js
var require_UnsubscriptionError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.UnsubscriptionError = void 0;
	exports.UnsubscriptionError = require_createErrorClass().createErrorClass(function(_super) {
		return function UnsubscriptionErrorImpl(errors) {
			_super(this);
			this.message = errors ? errors.length + " errors occurred during unsubscription:\n" + errors.map(function(err, i) {
				return i + 1 + ") " + err.toString();
			}).join("\n  ") : "";
			this.name = "UnsubscriptionError";
			this.errors = errors;
		};
	});
}));
// node_modules/rxjs/dist/cjs/internal/util/arrRemove.js
var require_arrRemove = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.arrRemove = void 0;
	function arrRemove(arr, item) {
		if (arr) {
			var index = arr.indexOf(item);
			0 <= index && arr.splice(index, 1);
		}
	}
	exports.arrRemove = arrRemove;
}));
// node_modules/rxjs/dist/cjs/internal/Subscription.js
var require_Subscription = /* @__PURE__ */ __commonJSMin(((exports, module, this$50) => {
	var __values = this$50 && this$50.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	var __read = this$50 && this$50.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$50 && this$50.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isSubscription = exports.EMPTY_SUBSCRIPTION = exports.Subscription = void 0;
	var isFunction_1 = require_isFunction();
	var UnsubscriptionError_1 = require_UnsubscriptionError();
	var arrRemove_1 = require_arrRemove();
	var Subscription = function() {
		function Subscription(initialTeardown) {
			this.initialTeardown = initialTeardown;
			this.closed = false;
			this._parentage = null;
			this._finalizers = null;
		}
		Subscription.prototype.unsubscribe = function() {
			var e_1, _a, e_2, _b;
			var errors;
			if (!this.closed) {
				this.closed = true;
				var _parentage = this._parentage;
				if (_parentage) {
					this._parentage = null;
					if (Array.isArray(_parentage)) try {
						for (var _parentage_1 = __values(_parentage), _parentage_1_1 = _parentage_1.next(); !_parentage_1_1.done; _parentage_1_1 = _parentage_1.next()) _parentage_1_1.value.remove(this);
					} catch (e_1_1) {
						e_1 = { error: e_1_1 };
					} finally {
						try {
							if (_parentage_1_1 && !_parentage_1_1.done && (_a = _parentage_1.return)) _a.call(_parentage_1);
						} finally {
							if (e_1) throw e_1.error;
						}
					}
					else _parentage.remove(this);
				}
				var initialFinalizer = this.initialTeardown;
				if (isFunction_1.isFunction(initialFinalizer)) try {
					initialFinalizer();
				} catch (e) {
					errors = e instanceof UnsubscriptionError_1.UnsubscriptionError ? e.errors : [e];
				}
				var _finalizers = this._finalizers;
				if (_finalizers) {
					this._finalizers = null;
					try {
						for (var _finalizers_1 = __values(_finalizers), _finalizers_1_1 = _finalizers_1.next(); !_finalizers_1_1.done; _finalizers_1_1 = _finalizers_1.next()) {
							var finalizer = _finalizers_1_1.value;
							try {
								execFinalizer(finalizer);
							} catch (err) {
								errors = errors !== null && errors !== void 0 ? errors : [];
								if (err instanceof UnsubscriptionError_1.UnsubscriptionError) errors = __spreadArray(__spreadArray([], __read(errors)), __read(err.errors));
								else errors.push(err);
							}
						}
					} catch (e_2_1) {
						e_2 = { error: e_2_1 };
					} finally {
						try {
							if (_finalizers_1_1 && !_finalizers_1_1.done && (_b = _finalizers_1.return)) _b.call(_finalizers_1);
						} finally {
							if (e_2) throw e_2.error;
						}
					}
				}
				if (errors) throw new UnsubscriptionError_1.UnsubscriptionError(errors);
			}
		};
		Subscription.prototype.add = function(teardown) {
			var _a;
			if (teardown && teardown !== this) {
				if (this.closed) execFinalizer(teardown);
				else {
					if (teardown instanceof Subscription) {
						if (teardown.closed || teardown._hasParent(this)) return;
						teardown._addParent(this);
					}
					(this._finalizers = (_a = this._finalizers) !== null && _a !== void 0 ? _a : []).push(teardown);
				}
			}
		};
		Subscription.prototype._hasParent = function(parent) {
			var _parentage = this._parentage;
			return _parentage === parent || Array.isArray(_parentage) && _parentage.includes(parent);
		};
		Subscription.prototype._addParent = function(parent) {
			var _parentage = this._parentage;
			this._parentage = Array.isArray(_parentage) ? (_parentage.push(parent), _parentage) : _parentage ? [_parentage, parent] : parent;
		};
		Subscription.prototype._removeParent = function(parent) {
			var _parentage = this._parentage;
			if (_parentage === parent) this._parentage = null;
			else if (Array.isArray(_parentage)) arrRemove_1.arrRemove(_parentage, parent);
		};
		Subscription.prototype.remove = function(teardown) {
			var _finalizers = this._finalizers;
			_finalizers && arrRemove_1.arrRemove(_finalizers, teardown);
			if (teardown instanceof Subscription) teardown._removeParent(this);
		};
		Subscription.EMPTY = (function() {
			var empty = new Subscription();
			empty.closed = true;
			return empty;
		})();
		return Subscription;
	}();
	exports.Subscription = Subscription;
	exports.EMPTY_SUBSCRIPTION = Subscription.EMPTY;
	function isSubscription(value) {
		return value instanceof Subscription || value && "closed" in value && isFunction_1.isFunction(value.remove) && isFunction_1.isFunction(value.add) && isFunction_1.isFunction(value.unsubscribe);
	}
	exports.isSubscription = isSubscription;
	function execFinalizer(finalizer) {
		if (isFunction_1.isFunction(finalizer)) finalizer();
		else finalizer.unsubscribe();
	}
}));
// node_modules/rxjs/dist/cjs/internal/config.js
var require_config = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.config = void 0;
	exports.config = {
		onUnhandledError: null,
		onStoppedNotification: null,
		Promise: void 0,
		useDeprecatedSynchronousErrorHandling: false,
		useDeprecatedNextContext: false
	};
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/timeoutProvider.js
var require_timeoutProvider = /* @__PURE__ */ __commonJSMin(((exports, module, this$49) => {
	var __read = this$49 && this$49.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$49 && this$49.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.timeoutProvider = void 0;
	exports.timeoutProvider = {
		setTimeout: function(handler, timeout) {
			var args = [];
			for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
			var delegate = exports.timeoutProvider.delegate;
			if (delegate === null || delegate === void 0 ? void 0 : delegate.setTimeout) return delegate.setTimeout.apply(delegate, __spreadArray([handler, timeout], __read(args)));
			return setTimeout.apply(void 0, __spreadArray([handler, timeout], __read(args)));
		},
		clearTimeout: function(handle) {
			var delegate = exports.timeoutProvider.delegate;
			return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearTimeout) || clearTimeout)(handle);
		},
		delegate: void 0
	};
}));
// node_modules/rxjs/dist/cjs/internal/util/reportUnhandledError.js
var require_reportUnhandledError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.reportUnhandledError = void 0;
	var config_1 = require_config();
	var timeoutProvider_1 = require_timeoutProvider();
	function reportUnhandledError(err) {
		timeoutProvider_1.timeoutProvider.setTimeout(function() {
			var onUnhandledError = config_1.config.onUnhandledError;
			if (onUnhandledError) onUnhandledError(err);
			else throw err;
		});
	}
	exports.reportUnhandledError = reportUnhandledError;
}));
// node_modules/rxjs/dist/cjs/internal/util/noop.js
var require_noop = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.noop = void 0;
	function noop() {}
	exports.noop = noop;
}));
// node_modules/rxjs/dist/cjs/internal/NotificationFactories.js
var require_NotificationFactories = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createNotification = exports.nextNotification = exports.errorNotification = exports.COMPLETE_NOTIFICATION = void 0;
	exports.COMPLETE_NOTIFICATION = (function() {
		return createNotification("C", void 0, void 0);
	})();
	function errorNotification(error) {
		return createNotification("E", void 0, error);
	}
	exports.errorNotification = errorNotification;
	function nextNotification(value) {
		return createNotification("N", value, void 0);
	}
	exports.nextNotification = nextNotification;
	function createNotification(kind, value, error) {
		return {
			kind,
			value,
			error
		};
	}
	exports.createNotification = createNotification;
}));
// node_modules/rxjs/dist/cjs/internal/util/errorContext.js
var require_errorContext = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.captureError = exports.errorContext = void 0;
	var config_1 = require_config();
	var context = null;
	function errorContext(cb) {
		if (config_1.config.useDeprecatedSynchronousErrorHandling) {
			var isRoot = !context;
			if (isRoot) context = {
				errorThrown: false,
				error: null
			};
			cb();
			if (isRoot) {
				var _a = context, errorThrown = _a.errorThrown, error = _a.error;
				context = null;
				if (errorThrown) throw error;
			}
		} else cb();
	}
	exports.errorContext = errorContext;
	function captureError(err) {
		if (config_1.config.useDeprecatedSynchronousErrorHandling && context) {
			context.errorThrown = true;
			context.error = err;
		}
	}
	exports.captureError = captureError;
}));
// node_modules/rxjs/dist/cjs/internal/Subscriber.js
var require_Subscriber = /* @__PURE__ */ __commonJSMin(((exports, module, this$48) => {
	var __extends = this$48 && this$48.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.EMPTY_OBSERVER = exports.SafeSubscriber = exports.Subscriber = void 0;
	var isFunction_1 = require_isFunction();
	var Subscription_1 = require_Subscription();
	var config_1 = require_config();
	var reportUnhandledError_1 = require_reportUnhandledError();
	var noop_1 = require_noop();
	var NotificationFactories_1 = require_NotificationFactories();
	var timeoutProvider_1 = require_timeoutProvider();
	var errorContext_1 = require_errorContext();
	var Subscriber = function(_super) {
		__extends(Subscriber, _super);
		function Subscriber(destination) {
			var _this = _super.call(this) || this;
			_this.isStopped = false;
			if (destination) {
				_this.destination = destination;
				if (Subscription_1.isSubscription(destination)) destination.add(_this);
			} else _this.destination = exports.EMPTY_OBSERVER;
			return _this;
		}
		Subscriber.create = function(next, error, complete) {
			return new SafeSubscriber(next, error, complete);
		};
		Subscriber.prototype.next = function(value) {
			if (this.isStopped) handleStoppedNotification(NotificationFactories_1.nextNotification(value), this);
			else this._next(value);
		};
		Subscriber.prototype.error = function(err) {
			if (this.isStopped) handleStoppedNotification(NotificationFactories_1.errorNotification(err), this);
			else {
				this.isStopped = true;
				this._error(err);
			}
		};
		Subscriber.prototype.complete = function() {
			if (this.isStopped) handleStoppedNotification(NotificationFactories_1.COMPLETE_NOTIFICATION, this);
			else {
				this.isStopped = true;
				this._complete();
			}
		};
		Subscriber.prototype.unsubscribe = function() {
			if (!this.closed) {
				this.isStopped = true;
				_super.prototype.unsubscribe.call(this);
				this.destination = null;
			}
		};
		Subscriber.prototype._next = function(value) {
			this.destination.next(value);
		};
		Subscriber.prototype._error = function(err) {
			try {
				this.destination.error(err);
			} finally {
				this.unsubscribe();
			}
		};
		Subscriber.prototype._complete = function() {
			try {
				this.destination.complete();
			} finally {
				this.unsubscribe();
			}
		};
		return Subscriber;
	}(Subscription_1.Subscription);
	exports.Subscriber = Subscriber;
	var _bind = Function.prototype.bind;
	function bind(fn, thisArg) {
		return _bind.call(fn, thisArg);
	}
	var ConsumerObserver = function() {
		function ConsumerObserver(partialObserver) {
			this.partialObserver = partialObserver;
		}
		ConsumerObserver.prototype.next = function(value) {
			var partialObserver = this.partialObserver;
			if (partialObserver.next) try {
				partialObserver.next(value);
			} catch (error) {
				handleUnhandledError(error);
			}
		};
		ConsumerObserver.prototype.error = function(err) {
			var partialObserver = this.partialObserver;
			if (partialObserver.error) try {
				partialObserver.error(err);
			} catch (error) {
				handleUnhandledError(error);
			}
			else handleUnhandledError(err);
		};
		ConsumerObserver.prototype.complete = function() {
			var partialObserver = this.partialObserver;
			if (partialObserver.complete) try {
				partialObserver.complete();
			} catch (error) {
				handleUnhandledError(error);
			}
		};
		return ConsumerObserver;
	}();
	var SafeSubscriber = function(_super) {
		__extends(SafeSubscriber, _super);
		function SafeSubscriber(observerOrNext, error, complete) {
			var _this = _super.call(this) || this;
			var partialObserver;
			if (isFunction_1.isFunction(observerOrNext) || !observerOrNext) partialObserver = {
				next: observerOrNext !== null && observerOrNext !== void 0 ? observerOrNext : void 0,
				error: error !== null && error !== void 0 ? error : void 0,
				complete: complete !== null && complete !== void 0 ? complete : void 0
			};
			else {
				var context_1;
				if (_this && config_1.config.useDeprecatedNextContext) {
					context_1 = Object.create(observerOrNext);
					context_1.unsubscribe = function() {
						return _this.unsubscribe();
					};
					partialObserver = {
						next: observerOrNext.next && bind(observerOrNext.next, context_1),
						error: observerOrNext.error && bind(observerOrNext.error, context_1),
						complete: observerOrNext.complete && bind(observerOrNext.complete, context_1)
					};
				} else partialObserver = observerOrNext;
			}
			_this.destination = new ConsumerObserver(partialObserver);
			return _this;
		}
		return SafeSubscriber;
	}(Subscriber);
	exports.SafeSubscriber = SafeSubscriber;
	function handleUnhandledError(error) {
		if (config_1.config.useDeprecatedSynchronousErrorHandling) errorContext_1.captureError(error);
		else reportUnhandledError_1.reportUnhandledError(error);
	}
	function defaultErrorHandler(err) {
		throw err;
	}
	function handleStoppedNotification(notification, subscriber) {
		var onStoppedNotification = config_1.config.onStoppedNotification;
		onStoppedNotification && timeoutProvider_1.timeoutProvider.setTimeout(function() {
			return onStoppedNotification(notification, subscriber);
		});
	}
	exports.EMPTY_OBSERVER = {
		closed: true,
		next: noop_1.noop,
		error: defaultErrorHandler,
		complete: noop_1.noop
	};
}));
// node_modules/rxjs/dist/cjs/internal/symbol/observable.js
var require_observable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.observable = void 0;
	exports.observable = (function() {
		return typeof Symbol === "function" && Symbol.observable || "@@observable";
	})();
}));
// node_modules/rxjs/dist/cjs/internal/util/identity.js
var require_identity = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.identity = void 0;
	function identity(x) {
		return x;
	}
	exports.identity = identity;
}));
// node_modules/rxjs/dist/cjs/internal/util/pipe.js
var require_pipe = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.pipeFromArray = exports.pipe = void 0;
	var identity_1 = require_identity();
	function pipe() {
		var fns = [];
		for (var _i = 0; _i < arguments.length; _i++) fns[_i] = arguments[_i];
		return pipeFromArray(fns);
	}
	exports.pipe = pipe;
	function pipeFromArray(fns) {
		if (fns.length === 0) return identity_1.identity;
		if (fns.length === 1) return fns[0];
		return function piped(input) {
			return fns.reduce(function(prev, fn) {
				return fn(prev);
			}, input);
		};
	}
	exports.pipeFromArray = pipeFromArray;
}));
// node_modules/rxjs/dist/cjs/internal/Observable.js
var require_Observable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Observable = void 0;
	var Subscriber_1 = require_Subscriber();
	var Subscription_1 = require_Subscription();
	var observable_1 = require_observable();
	var pipe_1 = require_pipe();
	var config_1 = require_config();
	var isFunction_1 = require_isFunction();
	var errorContext_1 = require_errorContext();
	exports.Observable = function() {
		function Observable(subscribe) {
			if (subscribe) this._subscribe = subscribe;
		}
		Observable.prototype.lift = function(operator) {
			var observable = new Observable();
			observable.source = this;
			observable.operator = operator;
			return observable;
		};
		Observable.prototype.subscribe = function(observerOrNext, error, complete) {
			var _this = this;
			var subscriber = isSubscriber(observerOrNext) ? observerOrNext : new Subscriber_1.SafeSubscriber(observerOrNext, error, complete);
			errorContext_1.errorContext(function() {
				var _a = _this, operator = _a.operator, source = _a.source;
				subscriber.add(operator ? operator.call(subscriber, source) : source ? _this._subscribe(subscriber) : _this._trySubscribe(subscriber));
			});
			return subscriber;
		};
		Observable.prototype._trySubscribe = function(sink) {
			try {
				return this._subscribe(sink);
			} catch (err) {
				sink.error(err);
			}
		};
		Observable.prototype.forEach = function(next, promiseCtor) {
			var _this = this;
			promiseCtor = getPromiseCtor(promiseCtor);
			return new promiseCtor(function(resolve, reject) {
				var subscriber = new Subscriber_1.SafeSubscriber({
					next: function(value) {
						try {
							next(value);
						} catch (err) {
							reject(err);
							subscriber.unsubscribe();
						}
					},
					error: reject,
					complete: resolve
				});
				_this.subscribe(subscriber);
			});
		};
		Observable.prototype._subscribe = function(subscriber) {
			var _a;
			return (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber);
		};
		Observable.prototype[observable_1.observable] = function() {
			return this;
		};
		Observable.prototype.pipe = function() {
			var operations = [];
			for (var _i = 0; _i < arguments.length; _i++) operations[_i] = arguments[_i];
			return pipe_1.pipeFromArray(operations)(this);
		};
		Observable.prototype.toPromise = function(promiseCtor) {
			var _this = this;
			promiseCtor = getPromiseCtor(promiseCtor);
			return new promiseCtor(function(resolve, reject) {
				var value;
				_this.subscribe(function(x) {
					return value = x;
				}, function(err) {
					return reject(err);
				}, function() {
					return resolve(value);
				});
			});
		};
		Observable.create = function(subscribe) {
			return new Observable(subscribe);
		};
		return Observable;
	}();
	function getPromiseCtor(promiseCtor) {
		var _a;
		return (_a = promiseCtor !== null && promiseCtor !== void 0 ? promiseCtor : config_1.config.Promise) !== null && _a !== void 0 ? _a : Promise;
	}
	function isObserver(value) {
		return value && isFunction_1.isFunction(value.next) && isFunction_1.isFunction(value.error) && isFunction_1.isFunction(value.complete);
	}
	function isSubscriber(value) {
		return value && value instanceof Subscriber_1.Subscriber || isObserver(value) && Subscription_1.isSubscription(value);
	}
}));
// node_modules/rxjs/dist/cjs/internal/util/lift.js
var require_lift = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.operate = exports.hasLift = void 0;
	var isFunction_1 = require_isFunction();
	function hasLift(source) {
		return isFunction_1.isFunction(source === null || source === void 0 ? void 0 : source.lift);
	}
	exports.hasLift = hasLift;
	function operate(init) {
		return function(source) {
			if (hasLift(source)) return source.lift(function(liftedSource) {
				try {
					return init(liftedSource, this);
				} catch (err) {
					this.error(err);
				}
			});
			throw new TypeError("Unable to lift unknown Observable type");
		};
	}
	exports.operate = operate;
}));
// node_modules/rxjs/dist/cjs/internal/operators/OperatorSubscriber.js
var require_OperatorSubscriber = /* @__PURE__ */ __commonJSMin(((exports, module, this$47) => {
	var __extends = this$47 && this$47.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.OperatorSubscriber = exports.createOperatorSubscriber = void 0;
	var Subscriber_1 = require_Subscriber();
	function createOperatorSubscriber(destination, onNext, onComplete, onError, onFinalize) {
		return new OperatorSubscriber(destination, onNext, onComplete, onError, onFinalize);
	}
	exports.createOperatorSubscriber = createOperatorSubscriber;
	var OperatorSubscriber = function(_super) {
		__extends(OperatorSubscriber, _super);
		function OperatorSubscriber(destination, onNext, onComplete, onError, onFinalize, shouldUnsubscribe) {
			var _this = _super.call(this, destination) || this;
			_this.onFinalize = onFinalize;
			_this.shouldUnsubscribe = shouldUnsubscribe;
			_this._next = onNext ? function(value) {
				try {
					onNext(value);
				} catch (err) {
					destination.error(err);
				}
			} : _super.prototype._next;
			_this._error = onError ? function(err) {
				try {
					onError(err);
				} catch (err) {
					destination.error(err);
				} finally {
					this.unsubscribe();
				}
			} : _super.prototype._error;
			_this._complete = onComplete ? function() {
				try {
					onComplete();
				} catch (err) {
					destination.error(err);
				} finally {
					this.unsubscribe();
				}
			} : _super.prototype._complete;
			return _this;
		}
		OperatorSubscriber.prototype.unsubscribe = function() {
			var _a;
			if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
				var closed_1 = this.closed;
				_super.prototype.unsubscribe.call(this);
				!closed_1 && ((_a = this.onFinalize) === null || _a === void 0 || _a.call(this));
			}
		};
		return OperatorSubscriber;
	}(Subscriber_1.Subscriber);
	exports.OperatorSubscriber = OperatorSubscriber;
}));
// node_modules/rxjs/dist/cjs/internal/operators/refCount.js
var require_refCount = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.refCount = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function refCount() {
		return lift_1.operate(function(source, subscriber) {
			var connection = null;
			source._refCount++;
			var refCounter = OperatorSubscriber_1.createOperatorSubscriber(subscriber, void 0, void 0, void 0, function() {
				if (!source || source._refCount <= 0 || 0 < --source._refCount) {
					connection = null;
					return;
				}
				var sharedConnection = source._connection;
				var conn = connection;
				connection = null;
				if (sharedConnection && (!conn || sharedConnection === conn)) sharedConnection.unsubscribe();
				subscriber.unsubscribe();
			});
			source.subscribe(refCounter);
			if (!refCounter.closed) connection = source.connect();
		});
	}
	exports.refCount = refCount;
}));
// node_modules/rxjs/dist/cjs/internal/observable/ConnectableObservable.js
var require_ConnectableObservable = /* @__PURE__ */ __commonJSMin(((exports, module, this$46) => {
	var __extends = this$46 && this$46.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectableObservable = void 0;
	var Observable_1 = require_Observable();
	var Subscription_1 = require_Subscription();
	var refCount_1 = require_refCount();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var lift_1 = require_lift();
	exports.ConnectableObservable = function(_super) {
		__extends(ConnectableObservable, _super);
		function ConnectableObservable(source, subjectFactory) {
			var _this = _super.call(this) || this;
			_this.source = source;
			_this.subjectFactory = subjectFactory;
			_this._subject = null;
			_this._refCount = 0;
			_this._connection = null;
			if (lift_1.hasLift(source)) _this.lift = source.lift;
			return _this;
		}
		ConnectableObservable.prototype._subscribe = function(subscriber) {
			return this.getSubject().subscribe(subscriber);
		};
		ConnectableObservable.prototype.getSubject = function() {
			var subject = this._subject;
			if (!subject || subject.isStopped) this._subject = this.subjectFactory();
			return this._subject;
		};
		ConnectableObservable.prototype._teardown = function() {
			this._refCount = 0;
			var _connection = this._connection;
			this._subject = this._connection = null;
			_connection === null || _connection === void 0 || _connection.unsubscribe();
		};
		ConnectableObservable.prototype.connect = function() {
			var _this = this;
			var connection = this._connection;
			if (!connection) {
				connection = this._connection = new Subscription_1.Subscription();
				var subject_1 = this.getSubject();
				connection.add(this.source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subject_1, void 0, function() {
					_this._teardown();
					subject_1.complete();
				}, function(err) {
					_this._teardown();
					subject_1.error(err);
				}, function() {
					return _this._teardown();
				})));
				if (connection.closed) {
					this._connection = null;
					connection = Subscription_1.Subscription.EMPTY;
				}
			}
			return connection;
		};
		ConnectableObservable.prototype.refCount = function() {
			return refCount_1.refCount()(this);
		};
		return ConnectableObservable;
	}(Observable_1.Observable);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/performanceTimestampProvider.js
var require_performanceTimestampProvider = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.performanceTimestampProvider = void 0;
	exports.performanceTimestampProvider = {
		now: function() {
			return (exports.performanceTimestampProvider.delegate || performance).now();
		},
		delegate: void 0
	};
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/animationFrameProvider.js
var require_animationFrameProvider = /* @__PURE__ */ __commonJSMin(((exports, module, this$45) => {
	var __read = this$45 && this$45.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$45 && this$45.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.animationFrameProvider = void 0;
	var Subscription_1 = require_Subscription();
	exports.animationFrameProvider = {
		schedule: function(callback) {
			var request = requestAnimationFrame;
			var cancel = cancelAnimationFrame;
			var delegate = exports.animationFrameProvider.delegate;
			if (delegate) {
				request = delegate.requestAnimationFrame;
				cancel = delegate.cancelAnimationFrame;
			}
			var handle = request(function(timestamp) {
				cancel = void 0;
				callback(timestamp);
			});
			return new Subscription_1.Subscription(function() {
				return cancel === null || cancel === void 0 ? void 0 : cancel(handle);
			});
		},
		requestAnimationFrame: function() {
			var args = [];
			for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
			var delegate = exports.animationFrameProvider.delegate;
			return ((delegate === null || delegate === void 0 ? void 0 : delegate.requestAnimationFrame) || requestAnimationFrame).apply(void 0, __spreadArray([], __read(args)));
		},
		cancelAnimationFrame: function() {
			var args = [];
			for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
			var delegate = exports.animationFrameProvider.delegate;
			return ((delegate === null || delegate === void 0 ? void 0 : delegate.cancelAnimationFrame) || cancelAnimationFrame).apply(void 0, __spreadArray([], __read(args)));
		},
		delegate: void 0
	};
}));
// node_modules/rxjs/dist/cjs/internal/observable/dom/animationFrames.js
var require_animationFrames = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.animationFrames = void 0;
	var Observable_1 = require_Observable();
	var performanceTimestampProvider_1 = require_performanceTimestampProvider();
	var animationFrameProvider_1 = require_animationFrameProvider();
	function animationFrames(timestampProvider) {
		return timestampProvider ? animationFramesFactory(timestampProvider) : DEFAULT_ANIMATION_FRAMES;
	}
	exports.animationFrames = animationFrames;
	function animationFramesFactory(timestampProvider) {
		return new Observable_1.Observable(function(subscriber) {
			var provider = timestampProvider || performanceTimestampProvider_1.performanceTimestampProvider;
			var start = provider.now();
			var id = 0;
			var run = function() {
				if (!subscriber.closed) id = animationFrameProvider_1.animationFrameProvider.requestAnimationFrame(function(timestamp) {
					id = 0;
					var now = provider.now();
					subscriber.next({
						timestamp: timestampProvider ? now : timestamp,
						elapsed: now - start
					});
					run();
				});
			};
			run();
			return function() {
				if (id) animationFrameProvider_1.animationFrameProvider.cancelAnimationFrame(id);
			};
		});
	}
	var DEFAULT_ANIMATION_FRAMES = animationFramesFactory();
}));
// node_modules/rxjs/dist/cjs/internal/util/ObjectUnsubscribedError.js
var require_ObjectUnsubscribedError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ObjectUnsubscribedError = void 0;
	exports.ObjectUnsubscribedError = require_createErrorClass().createErrorClass(function(_super) {
		return function ObjectUnsubscribedErrorImpl() {
			_super(this);
			this.name = "ObjectUnsubscribedError";
			this.message = "object unsubscribed";
		};
	});
}));
// node_modules/rxjs/dist/cjs/internal/Subject.js
var require_Subject = /* @__PURE__ */ __commonJSMin(((exports, module, this$44) => {
	var __extends = this$44 && this$44.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	var __values = this$44 && this$44.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AnonymousSubject = exports.Subject = void 0;
	var Observable_1 = require_Observable();
	var Subscription_1 = require_Subscription();
	var ObjectUnsubscribedError_1 = require_ObjectUnsubscribedError();
	var arrRemove_1 = require_arrRemove();
	var errorContext_1 = require_errorContext();
	var Subject = function(_super) {
		__extends(Subject, _super);
		function Subject() {
			var _this = _super.call(this) || this;
			_this.closed = false;
			_this.currentObservers = null;
			_this.observers = [];
			_this.isStopped = false;
			_this.hasError = false;
			_this.thrownError = null;
			return _this;
		}
		Subject.prototype.lift = function(operator) {
			var subject = new AnonymousSubject(this, this);
			subject.operator = operator;
			return subject;
		};
		Subject.prototype._throwIfClosed = function() {
			if (this.closed) throw new ObjectUnsubscribedError_1.ObjectUnsubscribedError();
		};
		Subject.prototype.next = function(value) {
			var _this = this;
			errorContext_1.errorContext(function() {
				var e_1, _a;
				_this._throwIfClosed();
				if (!_this.isStopped) {
					if (!_this.currentObservers) _this.currentObservers = Array.from(_this.observers);
					try {
						for (var _b = __values(_this.currentObservers), _c = _b.next(); !_c.done; _c = _b.next()) _c.value.next(value);
					} catch (e_1_1) {
						e_1 = { error: e_1_1 };
					} finally {
						try {
							if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
						} finally {
							if (e_1) throw e_1.error;
						}
					}
				}
			});
		};
		Subject.prototype.error = function(err) {
			var _this = this;
			errorContext_1.errorContext(function() {
				_this._throwIfClosed();
				if (!_this.isStopped) {
					_this.hasError = _this.isStopped = true;
					_this.thrownError = err;
					var observers = _this.observers;
					while (observers.length) observers.shift().error(err);
				}
			});
		};
		Subject.prototype.complete = function() {
			var _this = this;
			errorContext_1.errorContext(function() {
				_this._throwIfClosed();
				if (!_this.isStopped) {
					_this.isStopped = true;
					var observers = _this.observers;
					while (observers.length) observers.shift().complete();
				}
			});
		};
		Subject.prototype.unsubscribe = function() {
			this.isStopped = this.closed = true;
			this.observers = this.currentObservers = null;
		};
		Object.defineProperty(Subject.prototype, "observed", {
			get: function() {
				var _a;
				return ((_a = this.observers) === null || _a === void 0 ? void 0 : _a.length) > 0;
			},
			enumerable: false,
			configurable: true
		});
		Subject.prototype._trySubscribe = function(subscriber) {
			this._throwIfClosed();
			return _super.prototype._trySubscribe.call(this, subscriber);
		};
		Subject.prototype._subscribe = function(subscriber) {
			this._throwIfClosed();
			this._checkFinalizedStatuses(subscriber);
			return this._innerSubscribe(subscriber);
		};
		Subject.prototype._innerSubscribe = function(subscriber) {
			var _this = this;
			var _a = this, hasError = _a.hasError, isStopped = _a.isStopped, observers = _a.observers;
			if (hasError || isStopped) return Subscription_1.EMPTY_SUBSCRIPTION;
			this.currentObservers = null;
			observers.push(subscriber);
			return new Subscription_1.Subscription(function() {
				_this.currentObservers = null;
				arrRemove_1.arrRemove(observers, subscriber);
			});
		};
		Subject.prototype._checkFinalizedStatuses = function(subscriber) {
			var _a = this, hasError = _a.hasError, thrownError = _a.thrownError, isStopped = _a.isStopped;
			if (hasError) subscriber.error(thrownError);
			else if (isStopped) subscriber.complete();
		};
		Subject.prototype.asObservable = function() {
			var observable = new Observable_1.Observable();
			observable.source = this;
			return observable;
		};
		Subject.create = function(destination, source) {
			return new AnonymousSubject(destination, source);
		};
		return Subject;
	}(Observable_1.Observable);
	exports.Subject = Subject;
	var AnonymousSubject = function(_super) {
		__extends(AnonymousSubject, _super);
		function AnonymousSubject(destination, source) {
			var _this = _super.call(this) || this;
			_this.destination = destination;
			_this.source = source;
			return _this;
		}
		AnonymousSubject.prototype.next = function(value) {
			var _a, _b;
			(_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.next) === null || _b === void 0 || _b.call(_a, value);
		};
		AnonymousSubject.prototype.error = function(err) {
			var _a, _b;
			(_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.error) === null || _b === void 0 || _b.call(_a, err);
		};
		AnonymousSubject.prototype.complete = function() {
			var _a, _b;
			(_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.complete) === null || _b === void 0 || _b.call(_a);
		};
		AnonymousSubject.prototype._subscribe = function(subscriber) {
			var _a, _b;
			return (_b = (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber)) !== null && _b !== void 0 ? _b : Subscription_1.EMPTY_SUBSCRIPTION;
		};
		return AnonymousSubject;
	}(Subject);
	exports.AnonymousSubject = AnonymousSubject;
}));
// node_modules/rxjs/dist/cjs/internal/BehaviorSubject.js
var require_BehaviorSubject = /* @__PURE__ */ __commonJSMin(((exports, module, this$43) => {
	var __extends = this$43 && this$43.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.BehaviorSubject = void 0;
	exports.BehaviorSubject = function(_super) {
		__extends(BehaviorSubject, _super);
		function BehaviorSubject(_value) {
			var _this = _super.call(this) || this;
			_this._value = _value;
			return _this;
		}
		Object.defineProperty(BehaviorSubject.prototype, "value", {
			get: function() {
				return this.getValue();
			},
			enumerable: false,
			configurable: true
		});
		BehaviorSubject.prototype._subscribe = function(subscriber) {
			var subscription = _super.prototype._subscribe.call(this, subscriber);
			!subscription.closed && subscriber.next(this._value);
			return subscription;
		};
		BehaviorSubject.prototype.getValue = function() {
			var _a = this, hasError = _a.hasError, thrownError = _a.thrownError, _value = _a._value;
			if (hasError) throw thrownError;
			this._throwIfClosed();
			return _value;
		};
		BehaviorSubject.prototype.next = function(value) {
			_super.prototype.next.call(this, this._value = value);
		};
		return BehaviorSubject;
	}(require_Subject().Subject);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/dateTimestampProvider.js
var require_dateTimestampProvider = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.dateTimestampProvider = void 0;
	exports.dateTimestampProvider = {
		now: function() {
			return (exports.dateTimestampProvider.delegate || Date).now();
		},
		delegate: void 0
	};
}));
// node_modules/rxjs/dist/cjs/internal/ReplaySubject.js
var require_ReplaySubject = /* @__PURE__ */ __commonJSMin(((exports, module, this$42) => {
	var __extends = this$42 && this$42.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ReplaySubject = void 0;
	var Subject_1 = require_Subject();
	var dateTimestampProvider_1 = require_dateTimestampProvider();
	exports.ReplaySubject = function(_super) {
		__extends(ReplaySubject, _super);
		function ReplaySubject(_bufferSize, _windowTime, _timestampProvider) {
			if (_bufferSize === void 0) _bufferSize = Infinity;
			if (_windowTime === void 0) _windowTime = Infinity;
			if (_timestampProvider === void 0) _timestampProvider = dateTimestampProvider_1.dateTimestampProvider;
			var _this = _super.call(this) || this;
			_this._bufferSize = _bufferSize;
			_this._windowTime = _windowTime;
			_this._timestampProvider = _timestampProvider;
			_this._buffer = [];
			_this._infiniteTimeWindow = true;
			_this._infiniteTimeWindow = _windowTime === Infinity;
			_this._bufferSize = Math.max(1, _bufferSize);
			_this._windowTime = Math.max(1, _windowTime);
			return _this;
		}
		ReplaySubject.prototype.next = function(value) {
			var _a = this, isStopped = _a.isStopped, _buffer = _a._buffer, _infiniteTimeWindow = _a._infiniteTimeWindow, _timestampProvider = _a._timestampProvider, _windowTime = _a._windowTime;
			if (!isStopped) {
				_buffer.push(value);
				!_infiniteTimeWindow && _buffer.push(_timestampProvider.now() + _windowTime);
			}
			this._trimBuffer();
			_super.prototype.next.call(this, value);
		};
		ReplaySubject.prototype._subscribe = function(subscriber) {
			this._throwIfClosed();
			this._trimBuffer();
			var subscription = this._innerSubscribe(subscriber);
			var _a = this, _infiniteTimeWindow = _a._infiniteTimeWindow;
			var copy = _a._buffer.slice();
			for (var i = 0; i < copy.length && !subscriber.closed; i += _infiniteTimeWindow ? 1 : 2) subscriber.next(copy[i]);
			this._checkFinalizedStatuses(subscriber);
			return subscription;
		};
		ReplaySubject.prototype._trimBuffer = function() {
			var _a = this, _bufferSize = _a._bufferSize, _timestampProvider = _a._timestampProvider, _buffer = _a._buffer, _infiniteTimeWindow = _a._infiniteTimeWindow;
			var adjustedBufferSize = (_infiniteTimeWindow ? 1 : 2) * _bufferSize;
			_bufferSize < Infinity && adjustedBufferSize < _buffer.length && _buffer.splice(0, _buffer.length - adjustedBufferSize);
			if (!_infiniteTimeWindow) {
				var now = _timestampProvider.now();
				var last = 0;
				for (var i = 1; i < _buffer.length && _buffer[i] <= now; i += 2) last = i;
				last && _buffer.splice(0, last + 1);
			}
		};
		return ReplaySubject;
	}(Subject_1.Subject);
}));
// node_modules/rxjs/dist/cjs/internal/AsyncSubject.js
var require_AsyncSubject = /* @__PURE__ */ __commonJSMin(((exports, module, this$41) => {
	var __extends = this$41 && this$41.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AsyncSubject = void 0;
	exports.AsyncSubject = function(_super) {
		__extends(AsyncSubject, _super);
		function AsyncSubject() {
			var _this = _super !== null && _super.apply(this, arguments) || this;
			_this._value = null;
			_this._hasValue = false;
			_this._isComplete = false;
			return _this;
		}
		AsyncSubject.prototype._checkFinalizedStatuses = function(subscriber) {
			var _a = this, hasError = _a.hasError, _hasValue = _a._hasValue, _value = _a._value, thrownError = _a.thrownError, isStopped = _a.isStopped, _isComplete = _a._isComplete;
			if (hasError) subscriber.error(thrownError);
			else if (isStopped || _isComplete) {
				_hasValue && subscriber.next(_value);
				subscriber.complete();
			}
		};
		AsyncSubject.prototype.next = function(value) {
			if (!this.isStopped) {
				this._value = value;
				this._hasValue = true;
			}
		};
		AsyncSubject.prototype.complete = function() {
			var _a = this, _hasValue = _a._hasValue, _value = _a._value;
			if (!_a._isComplete) {
				this._isComplete = true;
				_hasValue && _super.prototype.next.call(this, _value);
				_super.prototype.complete.call(this);
			}
		};
		return AsyncSubject;
	}(require_Subject().Subject);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/Action.js
var require_Action = /* @__PURE__ */ __commonJSMin(((exports, module, this$40) => {
	var __extends = this$40 && this$40.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Action = void 0;
	exports.Action = function(_super) {
		__extends(Action, _super);
		function Action(scheduler, work) {
			return _super.call(this) || this;
		}
		Action.prototype.schedule = function(state, delay) {
			if (delay === void 0) delay = 0;
			return this;
		};
		return Action;
	}(require_Subscription().Subscription);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/intervalProvider.js
var require_intervalProvider = /* @__PURE__ */ __commonJSMin(((exports, module, this$39) => {
	var __read = this$39 && this$39.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$39 && this$39.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.intervalProvider = void 0;
	exports.intervalProvider = {
		setInterval: function(handler, timeout) {
			var args = [];
			for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
			var delegate = exports.intervalProvider.delegate;
			if (delegate === null || delegate === void 0 ? void 0 : delegate.setInterval) return delegate.setInterval.apply(delegate, __spreadArray([handler, timeout], __read(args)));
			return setInterval.apply(void 0, __spreadArray([handler, timeout], __read(args)));
		},
		clearInterval: function(handle) {
			var delegate = exports.intervalProvider.delegate;
			return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearInterval) || clearInterval)(handle);
		},
		delegate: void 0
	};
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/AsyncAction.js
var require_AsyncAction = /* @__PURE__ */ __commonJSMin(((exports, module, this$38) => {
	var __extends = this$38 && this$38.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AsyncAction = void 0;
	var Action_1 = require_Action();
	var intervalProvider_1 = require_intervalProvider();
	var arrRemove_1 = require_arrRemove();
	exports.AsyncAction = function(_super) {
		__extends(AsyncAction, _super);
		function AsyncAction(scheduler, work) {
			var _this = _super.call(this, scheduler, work) || this;
			_this.scheduler = scheduler;
			_this.work = work;
			_this.pending = false;
			return _this;
		}
		AsyncAction.prototype.schedule = function(state, delay) {
			var _a;
			if (delay === void 0) delay = 0;
			if (this.closed) return this;
			this.state = state;
			var id = this.id;
			var scheduler = this.scheduler;
			if (id != null) this.id = this.recycleAsyncId(scheduler, id, delay);
			this.pending = true;
			this.delay = delay;
			this.id = (_a = this.id) !== null && _a !== void 0 ? _a : this.requestAsyncId(scheduler, this.id, delay);
			return this;
		};
		AsyncAction.prototype.requestAsyncId = function(scheduler, _id, delay) {
			if (delay === void 0) delay = 0;
			return intervalProvider_1.intervalProvider.setInterval(scheduler.flush.bind(scheduler, this), delay);
		};
		AsyncAction.prototype.recycleAsyncId = function(_scheduler, id, delay) {
			if (delay === void 0) delay = 0;
			if (delay != null && this.delay === delay && this.pending === false) return id;
			if (id != null) intervalProvider_1.intervalProvider.clearInterval(id);
		};
		AsyncAction.prototype.execute = function(state, delay) {
			if (this.closed) return /* @__PURE__ */ new Error("executing a cancelled action");
			this.pending = false;
			var error = this._execute(state, delay);
			if (error) return error;
			else if (this.pending === false && this.id != null) this.id = this.recycleAsyncId(this.scheduler, this.id, null);
		};
		AsyncAction.prototype._execute = function(state, _delay) {
			var errored = false;
			var errorValue;
			try {
				this.work(state);
			} catch (e) {
				errored = true;
				errorValue = e ? e : /* @__PURE__ */ new Error("Scheduled action threw falsy error");
			}
			if (errored) {
				this.unsubscribe();
				return errorValue;
			}
		};
		AsyncAction.prototype.unsubscribe = function() {
			if (!this.closed) {
				var _a = this, id = _a.id, scheduler = _a.scheduler;
				var actions = scheduler.actions;
				this.work = this.state = this.scheduler = null;
				this.pending = false;
				arrRemove_1.arrRemove(actions, this);
				if (id != null) this.id = this.recycleAsyncId(scheduler, id, null);
				this.delay = null;
				_super.prototype.unsubscribe.call(this);
			}
		};
		return AsyncAction;
	}(Action_1.Action);
}));
// node_modules/rxjs/dist/cjs/internal/util/Immediate.js
var require_Immediate = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TestTools = exports.Immediate = void 0;
	var nextHandle = 1;
	var resolved;
	var activeHandles = {};
	function findAndClearHandle(handle) {
		if (handle in activeHandles) {
			delete activeHandles[handle];
			return true;
		}
		return false;
	}
	exports.Immediate = {
		setImmediate: function(cb) {
			var handle = nextHandle++;
			activeHandles[handle] = true;
			if (!resolved) resolved = Promise.resolve();
			resolved.then(function() {
				return findAndClearHandle(handle) && cb();
			});
			return handle;
		},
		clearImmediate: function(handle) {
			findAndClearHandle(handle);
		}
	};
	exports.TestTools = { pending: function() {
		return Object.keys(activeHandles).length;
	} };
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/immediateProvider.js
var require_immediateProvider = /* @__PURE__ */ __commonJSMin(((exports, module, this$37) => {
	var __read = this$37 && this$37.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$37 && this$37.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.immediateProvider = void 0;
	var Immediate_1 = require_Immediate();
	var setImmediate = Immediate_1.Immediate.setImmediate;
	var clearImmediate = Immediate_1.Immediate.clearImmediate;
	exports.immediateProvider = {
		setImmediate: function() {
			var args = [];
			for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
			var delegate = exports.immediateProvider.delegate;
			return ((delegate === null || delegate === void 0 ? void 0 : delegate.setImmediate) || setImmediate).apply(void 0, __spreadArray([], __read(args)));
		},
		clearImmediate: function(handle) {
			var delegate = exports.immediateProvider.delegate;
			return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearImmediate) || clearImmediate)(handle);
		},
		delegate: void 0
	};
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/AsapAction.js
var require_AsapAction = /* @__PURE__ */ __commonJSMin(((exports, module, this$36) => {
	var __extends = this$36 && this$36.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AsapAction = void 0;
	var AsyncAction_1 = require_AsyncAction();
	var immediateProvider_1 = require_immediateProvider();
	exports.AsapAction = function(_super) {
		__extends(AsapAction, _super);
		function AsapAction(scheduler, work) {
			var _this = _super.call(this, scheduler, work) || this;
			_this.scheduler = scheduler;
			_this.work = work;
			return _this;
		}
		AsapAction.prototype.requestAsyncId = function(scheduler, id, delay) {
			if (delay === void 0) delay = 0;
			if (delay !== null && delay > 0) return _super.prototype.requestAsyncId.call(this, scheduler, id, delay);
			scheduler.actions.push(this);
			return scheduler._scheduled || (scheduler._scheduled = immediateProvider_1.immediateProvider.setImmediate(scheduler.flush.bind(scheduler, void 0)));
		};
		AsapAction.prototype.recycleAsyncId = function(scheduler, id, delay) {
			var _a;
			if (delay === void 0) delay = 0;
			if (delay != null ? delay > 0 : this.delay > 0) return _super.prototype.recycleAsyncId.call(this, scheduler, id, delay);
			var actions = scheduler.actions;
			if (id != null && ((_a = actions[actions.length - 1]) === null || _a === void 0 ? void 0 : _a.id) !== id) {
				immediateProvider_1.immediateProvider.clearImmediate(id);
				if (scheduler._scheduled === id) scheduler._scheduled = void 0;
			}
		};
		return AsapAction;
	}(AsyncAction_1.AsyncAction);
}));
// node_modules/rxjs/dist/cjs/internal/Scheduler.js
var require_Scheduler = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Scheduler = void 0;
	var dateTimestampProvider_1 = require_dateTimestampProvider();
	exports.Scheduler = function() {
		function Scheduler(schedulerActionCtor, now) {
			if (now === void 0) now = Scheduler.now;
			this.schedulerActionCtor = schedulerActionCtor;
			this.now = now;
		}
		Scheduler.prototype.schedule = function(work, delay, state) {
			if (delay === void 0) delay = 0;
			return new this.schedulerActionCtor(this, work).schedule(state, delay);
		};
		Scheduler.now = dateTimestampProvider_1.dateTimestampProvider.now;
		return Scheduler;
	}();
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/AsyncScheduler.js
var require_AsyncScheduler = /* @__PURE__ */ __commonJSMin(((exports, module, this$35) => {
	var __extends = this$35 && this$35.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AsyncScheduler = void 0;
	var Scheduler_1 = require_Scheduler();
	exports.AsyncScheduler = function(_super) {
		__extends(AsyncScheduler, _super);
		function AsyncScheduler(SchedulerAction, now) {
			if (now === void 0) now = Scheduler_1.Scheduler.now;
			var _this = _super.call(this, SchedulerAction, now) || this;
			_this.actions = [];
			_this._active = false;
			return _this;
		}
		AsyncScheduler.prototype.flush = function(action) {
			var actions = this.actions;
			if (this._active) {
				actions.push(action);
				return;
			}
			var error;
			this._active = true;
			do
				if (error = action.execute(action.state, action.delay)) break;
			while (action = actions.shift());
			this._active = false;
			if (error) {
				while (action = actions.shift()) action.unsubscribe();
				throw error;
			}
		};
		return AsyncScheduler;
	}(Scheduler_1.Scheduler);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/AsapScheduler.js
var require_AsapScheduler = /* @__PURE__ */ __commonJSMin(((exports, module, this$34) => {
	var __extends = this$34 && this$34.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AsapScheduler = void 0;
	exports.AsapScheduler = function(_super) {
		__extends(AsapScheduler, _super);
		function AsapScheduler() {
			return _super !== null && _super.apply(this, arguments) || this;
		}
		AsapScheduler.prototype.flush = function(action) {
			this._active = true;
			var flushId = this._scheduled;
			this._scheduled = void 0;
			var actions = this.actions;
			var error;
			action = action || actions.shift();
			do
				if (error = action.execute(action.state, action.delay)) break;
			while ((action = actions[0]) && action.id === flushId && actions.shift());
			this._active = false;
			if (error) {
				while ((action = actions[0]) && action.id === flushId && actions.shift()) action.unsubscribe();
				throw error;
			}
		};
		return AsapScheduler;
	}(require_AsyncScheduler().AsyncScheduler);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/asap.js
var require_asap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.asap = exports.asapScheduler = void 0;
	var AsapAction_1 = require_AsapAction();
	exports.asapScheduler = new (require_AsapScheduler()).AsapScheduler(AsapAction_1.AsapAction);
	exports.asap = exports.asapScheduler;
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/async.js
var require_async = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.async = exports.asyncScheduler = void 0;
	var AsyncAction_1 = require_AsyncAction();
	exports.asyncScheduler = new (require_AsyncScheduler()).AsyncScheduler(AsyncAction_1.AsyncAction);
	exports.async = exports.asyncScheduler;
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/QueueAction.js
var require_QueueAction = /* @__PURE__ */ __commonJSMin(((exports, module, this$33) => {
	var __extends = this$33 && this$33.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.QueueAction = void 0;
	exports.QueueAction = function(_super) {
		__extends(QueueAction, _super);
		function QueueAction(scheduler, work) {
			var _this = _super.call(this, scheduler, work) || this;
			_this.scheduler = scheduler;
			_this.work = work;
			return _this;
		}
		QueueAction.prototype.schedule = function(state, delay) {
			if (delay === void 0) delay = 0;
			if (delay > 0) return _super.prototype.schedule.call(this, state, delay);
			this.delay = delay;
			this.state = state;
			this.scheduler.flush(this);
			return this;
		};
		QueueAction.prototype.execute = function(state, delay) {
			return delay > 0 || this.closed ? _super.prototype.execute.call(this, state, delay) : this._execute(state, delay);
		};
		QueueAction.prototype.requestAsyncId = function(scheduler, id, delay) {
			if (delay === void 0) delay = 0;
			if (delay != null && delay > 0 || delay == null && this.delay > 0) return _super.prototype.requestAsyncId.call(this, scheduler, id, delay);
			scheduler.flush(this);
			return 0;
		};
		return QueueAction;
	}(require_AsyncAction().AsyncAction);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/QueueScheduler.js
var require_QueueScheduler = /* @__PURE__ */ __commonJSMin(((exports, module, this$32) => {
	var __extends = this$32 && this$32.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.QueueScheduler = void 0;
	exports.QueueScheduler = function(_super) {
		__extends(QueueScheduler, _super);
		function QueueScheduler() {
			return _super !== null && _super.apply(this, arguments) || this;
		}
		return QueueScheduler;
	}(require_AsyncScheduler().AsyncScheduler);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/queue.js
var require_queue = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.queue = exports.queueScheduler = void 0;
	var QueueAction_1 = require_QueueAction();
	exports.queueScheduler = new (require_QueueScheduler()).QueueScheduler(QueueAction_1.QueueAction);
	exports.queue = exports.queueScheduler;
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/AnimationFrameAction.js
var require_AnimationFrameAction = /* @__PURE__ */ __commonJSMin(((exports, module, this$31) => {
	var __extends = this$31 && this$31.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AnimationFrameAction = void 0;
	var AsyncAction_1 = require_AsyncAction();
	var animationFrameProvider_1 = require_animationFrameProvider();
	exports.AnimationFrameAction = function(_super) {
		__extends(AnimationFrameAction, _super);
		function AnimationFrameAction(scheduler, work) {
			var _this = _super.call(this, scheduler, work) || this;
			_this.scheduler = scheduler;
			_this.work = work;
			return _this;
		}
		AnimationFrameAction.prototype.requestAsyncId = function(scheduler, id, delay) {
			if (delay === void 0) delay = 0;
			if (delay !== null && delay > 0) return _super.prototype.requestAsyncId.call(this, scheduler, id, delay);
			scheduler.actions.push(this);
			return scheduler._scheduled || (scheduler._scheduled = animationFrameProvider_1.animationFrameProvider.requestAnimationFrame(function() {
				return scheduler.flush(void 0);
			}));
		};
		AnimationFrameAction.prototype.recycleAsyncId = function(scheduler, id, delay) {
			var _a;
			if (delay === void 0) delay = 0;
			if (delay != null ? delay > 0 : this.delay > 0) return _super.prototype.recycleAsyncId.call(this, scheduler, id, delay);
			var actions = scheduler.actions;
			if (id != null && id === scheduler._scheduled && ((_a = actions[actions.length - 1]) === null || _a === void 0 ? void 0 : _a.id) !== id) {
				animationFrameProvider_1.animationFrameProvider.cancelAnimationFrame(id);
				scheduler._scheduled = void 0;
			}
		};
		return AnimationFrameAction;
	}(AsyncAction_1.AsyncAction);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/AnimationFrameScheduler.js
var require_AnimationFrameScheduler = /* @__PURE__ */ __commonJSMin(((exports, module, this$30) => {
	var __extends = this$30 && this$30.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AnimationFrameScheduler = void 0;
	exports.AnimationFrameScheduler = function(_super) {
		__extends(AnimationFrameScheduler, _super);
		function AnimationFrameScheduler() {
			return _super !== null && _super.apply(this, arguments) || this;
		}
		AnimationFrameScheduler.prototype.flush = function(action) {
			this._active = true;
			var flushId;
			if (action) flushId = action.id;
			else {
				flushId = this._scheduled;
				this._scheduled = void 0;
			}
			var actions = this.actions;
			var error;
			action = action || actions.shift();
			do
				if (error = action.execute(action.state, action.delay)) break;
			while ((action = actions[0]) && action.id === flushId && actions.shift());
			this._active = false;
			if (error) {
				while ((action = actions[0]) && action.id === flushId && actions.shift()) action.unsubscribe();
				throw error;
			}
		};
		return AnimationFrameScheduler;
	}(require_AsyncScheduler().AsyncScheduler);
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/animationFrame.js
var require_animationFrame = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.animationFrame = exports.animationFrameScheduler = void 0;
	var AnimationFrameAction_1 = require_AnimationFrameAction();
	exports.animationFrameScheduler = new (require_AnimationFrameScheduler()).AnimationFrameScheduler(AnimationFrameAction_1.AnimationFrameAction);
	exports.animationFrame = exports.animationFrameScheduler;
}));
// node_modules/rxjs/dist/cjs/internal/scheduler/VirtualTimeScheduler.js
var require_VirtualTimeScheduler = /* @__PURE__ */ __commonJSMin(((exports, module, this$29) => {
	var __extends = this$29 && this$29.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.VirtualAction = exports.VirtualTimeScheduler = void 0;
	var AsyncAction_1 = require_AsyncAction();
	var Subscription_1 = require_Subscription();
	exports.VirtualTimeScheduler = function(_super) {
		__extends(VirtualTimeScheduler, _super);
		function VirtualTimeScheduler(schedulerActionCtor, maxFrames) {
			if (schedulerActionCtor === void 0) schedulerActionCtor = VirtualAction;
			if (maxFrames === void 0) maxFrames = Infinity;
			var _this = _super.call(this, schedulerActionCtor, function() {
				return _this.frame;
			}) || this;
			_this.maxFrames = maxFrames;
			_this.frame = 0;
			_this.index = -1;
			return _this;
		}
		VirtualTimeScheduler.prototype.flush = function() {
			var _a = this, actions = _a.actions, maxFrames = _a.maxFrames;
			var error;
			var action;
			while ((action = actions[0]) && action.delay <= maxFrames) {
				actions.shift();
				this.frame = action.delay;
				if (error = action.execute(action.state, action.delay)) break;
			}
			if (error) {
				while (action = actions.shift()) action.unsubscribe();
				throw error;
			}
		};
		VirtualTimeScheduler.frameTimeFactor = 10;
		return VirtualTimeScheduler;
	}(require_AsyncScheduler().AsyncScheduler);
	var VirtualAction = function(_super) {
		__extends(VirtualAction, _super);
		function VirtualAction(scheduler, work, index) {
			if (index === void 0) index = scheduler.index += 1;
			var _this = _super.call(this, scheduler, work) || this;
			_this.scheduler = scheduler;
			_this.work = work;
			_this.index = index;
			_this.active = true;
			_this.index = scheduler.index = index;
			return _this;
		}
		VirtualAction.prototype.schedule = function(state, delay) {
			if (delay === void 0) delay = 0;
			if (Number.isFinite(delay)) {
				if (!this.id) return _super.prototype.schedule.call(this, state, delay);
				this.active = false;
				var action = new VirtualAction(this.scheduler, this.work);
				this.add(action);
				return action.schedule(state, delay);
			} else return Subscription_1.Subscription.EMPTY;
		};
		VirtualAction.prototype.requestAsyncId = function(scheduler, id, delay) {
			if (delay === void 0) delay = 0;
			this.delay = scheduler.frame + delay;
			var actions = scheduler.actions;
			actions.push(this);
			actions.sort(VirtualAction.sortActions);
			return 1;
		};
		VirtualAction.prototype.recycleAsyncId = function(scheduler, id, delay) {
			if (delay === void 0) delay = 0;
		};
		VirtualAction.prototype._execute = function(state, delay) {
			if (this.active === true) return _super.prototype._execute.call(this, state, delay);
		};
		VirtualAction.sortActions = function(a, b) {
			if (a.delay === b.delay) {
				if (a.index === b.index) return 0;
				else if (a.index > b.index) return 1;
				else return -1;
			} else if (a.delay > b.delay) return 1;
			else return -1;
		};
		return VirtualAction;
	}(AsyncAction_1.AsyncAction);
	exports.VirtualAction = VirtualAction;
}));
// node_modules/rxjs/dist/cjs/internal/observable/empty.js
var require_empty = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.empty = exports.EMPTY = void 0;
	var Observable_1 = require_Observable();
	exports.EMPTY = new Observable_1.Observable(function(subscriber) {
		return subscriber.complete();
	});
	function empty(scheduler) {
		return scheduler ? emptyScheduled(scheduler) : exports.EMPTY;
	}
	exports.empty = empty;
	function emptyScheduled(scheduler) {
		return new Observable_1.Observable(function(subscriber) {
			return scheduler.schedule(function() {
				return subscriber.complete();
			});
		});
	}
}));
// node_modules/rxjs/dist/cjs/internal/util/isScheduler.js
var require_isScheduler = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isScheduler = void 0;
	var isFunction_1 = require_isFunction();
	function isScheduler(value) {
		return value && isFunction_1.isFunction(value.schedule);
	}
	exports.isScheduler = isScheduler;
}));
// node_modules/rxjs/dist/cjs/internal/util/args.js
var require_args = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.popNumber = exports.popScheduler = exports.popResultSelector = void 0;
	var isFunction_1 = require_isFunction();
	var isScheduler_1 = require_isScheduler();
	function last(arr) {
		return arr[arr.length - 1];
	}
	function popResultSelector(args) {
		return isFunction_1.isFunction(last(args)) ? args.pop() : void 0;
	}
	exports.popResultSelector = popResultSelector;
	function popScheduler(args) {
		return isScheduler_1.isScheduler(last(args)) ? args.pop() : void 0;
	}
	exports.popScheduler = popScheduler;
	function popNumber(args, defaultValue) {
		return typeof last(args) === "number" ? args.pop() : defaultValue;
	}
	exports.popNumber = popNumber;
}));
// node_modules/rxjs/dist/cjs/internal/util/isArrayLike.js
var require_isArrayLike = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isArrayLike = void 0;
	exports.isArrayLike = (function(x) {
		return x && typeof x.length === "number" && typeof x !== "function";
	});
}));
// node_modules/rxjs/dist/cjs/internal/util/isPromise.js
var require_isPromise = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isPromise = void 0;
	var isFunction_1 = require_isFunction();
	function isPromise(value) {
		return isFunction_1.isFunction(value === null || value === void 0 ? void 0 : value.then);
	}
	exports.isPromise = isPromise;
}));
// node_modules/rxjs/dist/cjs/internal/util/isInteropObservable.js
var require_isInteropObservable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isInteropObservable = void 0;
	var observable_1 = require_observable();
	var isFunction_1 = require_isFunction();
	function isInteropObservable(input) {
		return isFunction_1.isFunction(input[observable_1.observable]);
	}
	exports.isInteropObservable = isInteropObservable;
}));
// node_modules/rxjs/dist/cjs/internal/util/isAsyncIterable.js
var require_isAsyncIterable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isAsyncIterable = void 0;
	var isFunction_1 = require_isFunction();
	function isAsyncIterable(obj) {
		return Symbol.asyncIterator && isFunction_1.isFunction(obj === null || obj === void 0 ? void 0 : obj[Symbol.asyncIterator]);
	}
	exports.isAsyncIterable = isAsyncIterable;
}));
// node_modules/rxjs/dist/cjs/internal/util/throwUnobservableError.js
var require_throwUnobservableError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createInvalidObservableTypeError = void 0;
	function createInvalidObservableTypeError(input) {
		return /* @__PURE__ */ new TypeError("You provided " + (input !== null && typeof input === "object" ? "an invalid object" : "'" + input + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.");
	}
	exports.createInvalidObservableTypeError = createInvalidObservableTypeError;
}));
// node_modules/rxjs/dist/cjs/internal/symbol/iterator.js
var require_iterator = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.iterator = exports.getSymbolIterator = void 0;
	function getSymbolIterator() {
		if (typeof Symbol !== "function" || !Symbol.iterator) return "@@iterator";
		return Symbol.iterator;
	}
	exports.getSymbolIterator = getSymbolIterator;
	exports.iterator = getSymbolIterator();
}));
// node_modules/rxjs/dist/cjs/internal/util/isIterable.js
var require_isIterable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isIterable = void 0;
	var iterator_1 = require_iterator();
	var isFunction_1 = require_isFunction();
	function isIterable(input) {
		return isFunction_1.isFunction(input === null || input === void 0 ? void 0 : input[iterator_1.iterator]);
	}
	exports.isIterable = isIterable;
}));
// node_modules/rxjs/dist/cjs/internal/util/isReadableStreamLike.js
var require_isReadableStreamLike = /* @__PURE__ */ __commonJSMin(((exports, module, this$28) => {
	var __generator = this$28 && this$28.__generator || function(thisArg, body) {
		var _ = {
			label: 0,
			sent: function() {
				if (t[0] & 1) throw t[1];
				return t[1];
			},
			trys: [],
			ops: []
		}, f, y, t, g = {
			next: verb(0),
			"throw": verb(1),
			"return": verb(2)
		};
		return typeof Symbol === "function" && (g[Symbol.iterator] = function() {
			return this;
		}), g;
		function verb(n) {
			return function(v) {
				return step([n, v]);
			};
		}
		function step(op) {
			if (f) throw new TypeError("Generator is already executing.");
			while (_) try {
				if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
				if (y = 0, t) op = [op[0] & 2, t.value];
				switch (op[0]) {
					case 0:
					case 1:
						t = op;
						break;
					case 4:
						_.label++;
						return {
							value: op[1],
							done: false
						};
					case 5:
						_.label++;
						y = op[1];
						op = [0];
						continue;
					case 7:
						op = _.ops.pop();
						_.trys.pop();
						continue;
					default:
						if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
							_ = 0;
							continue;
						}
						if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
							_.label = op[1];
							break;
						}
						if (op[0] === 6 && _.label < t[1]) {
							_.label = t[1];
							t = op;
							break;
						}
						if (t && _.label < t[2]) {
							_.label = t[2];
							_.ops.push(op);
							break;
						}
						if (t[2]) _.ops.pop();
						_.trys.pop();
						continue;
				}
				op = body.call(thisArg, _);
			} catch (e) {
				op = [6, e];
				y = 0;
			} finally {
				f = t = 0;
			}
			if (op[0] & 5) throw op[1];
			return {
				value: op[0] ? op[1] : void 0,
				done: true
			};
		}
	};
	var __await = this$28 && this$28.__await || function(v) {
		return this instanceof __await ? (this.v = v, this) : new __await(v);
	};
	var __asyncGenerator = this$28 && this$28.__asyncGenerator || function(thisArg, _arguments, generator) {
		if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
		var g = generator.apply(thisArg, _arguments || []), i, q = [];
		return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
			return this;
		}, i;
		function verb(n) {
			if (g[n]) i[n] = function(v) {
				return new Promise(function(a, b) {
					q.push([
						n,
						v,
						a,
						b
					]) > 1 || resume(n, v);
				});
			};
		}
		function resume(n, v) {
			try {
				step(g[n](v));
			} catch (e) {
				settle(q[0][3], e);
			}
		}
		function step(r) {
			r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
		}
		function fulfill(value) {
			resume("next", value);
		}
		function reject(value) {
			resume("throw", value);
		}
		function settle(f, v) {
			if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
		}
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isReadableStreamLike = exports.readableStreamLikeToAsyncGenerator = void 0;
	var isFunction_1 = require_isFunction();
	function readableStreamLikeToAsyncGenerator(readableStream) {
		return __asyncGenerator(this, arguments, function readableStreamLikeToAsyncGenerator_1() {
			var reader, _a, value, done;
			return __generator(this, function(_b) {
				switch (_b.label) {
					case 0:
						reader = readableStream.getReader();
						_b.label = 1;
					case 1:
						_b.trys.push([
							1,
							,
							9,
							10
						]);
						_b.label = 2;
					case 2: return [4, __await(reader.read())];
					case 3:
						_a = _b.sent(), value = _a.value, done = _a.done;
						if (!done) return [3, 5];
						return [4, __await(void 0)];
					case 4: return [2, _b.sent()];
					case 5: return [4, __await(value)];
					case 6: return [4, _b.sent()];
					case 7:
						_b.sent();
						return [3, 2];
					case 8: return [3, 10];
					case 9:
						reader.releaseLock();
						return [7];
					case 10: return [2];
				}
			});
		});
	}
	exports.readableStreamLikeToAsyncGenerator = readableStreamLikeToAsyncGenerator;
	function isReadableStreamLike(obj) {
		return isFunction_1.isFunction(obj === null || obj === void 0 ? void 0 : obj.getReader);
	}
	exports.isReadableStreamLike = isReadableStreamLike;
}));
// node_modules/rxjs/dist/cjs/internal/observable/innerFrom.js
var require_innerFrom = /* @__PURE__ */ __commonJSMin(((exports, module, this$27) => {
	var __awaiter = this$27 && this$27.__awaiter || function(thisArg, _arguments, P, generator) {
		function adopt(value) {
			return value instanceof P ? value : new P(function(resolve) {
				resolve(value);
			});
		}
		return new (P || (P = Promise))(function(resolve, reject) {
			function fulfilled(value) {
				try {
					step(generator.next(value));
				} catch (e) {
					reject(e);
				}
			}
			function rejected(value) {
				try {
					step(generator["throw"](value));
				} catch (e) {
					reject(e);
				}
			}
			function step(result) {
				result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
			}
			step((generator = generator.apply(thisArg, _arguments || [])).next());
		});
	};
	var __generator = this$27 && this$27.__generator || function(thisArg, body) {
		var _ = {
			label: 0,
			sent: function() {
				if (t[0] & 1) throw t[1];
				return t[1];
			},
			trys: [],
			ops: []
		}, f, y, t, g = {
			next: verb(0),
			"throw": verb(1),
			"return": verb(2)
		};
		return typeof Symbol === "function" && (g[Symbol.iterator] = function() {
			return this;
		}), g;
		function verb(n) {
			return function(v) {
				return step([n, v]);
			};
		}
		function step(op) {
			if (f) throw new TypeError("Generator is already executing.");
			while (_) try {
				if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
				if (y = 0, t) op = [op[0] & 2, t.value];
				switch (op[0]) {
					case 0:
					case 1:
						t = op;
						break;
					case 4:
						_.label++;
						return {
							value: op[1],
							done: false
						};
					case 5:
						_.label++;
						y = op[1];
						op = [0];
						continue;
					case 7:
						op = _.ops.pop();
						_.trys.pop();
						continue;
					default:
						if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
							_ = 0;
							continue;
						}
						if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
							_.label = op[1];
							break;
						}
						if (op[0] === 6 && _.label < t[1]) {
							_.label = t[1];
							t = op;
							break;
						}
						if (t && _.label < t[2]) {
							_.label = t[2];
							_.ops.push(op);
							break;
						}
						if (t[2]) _.ops.pop();
						_.trys.pop();
						continue;
				}
				op = body.call(thisArg, _);
			} catch (e) {
				op = [6, e];
				y = 0;
			} finally {
				f = t = 0;
			}
			if (op[0] & 5) throw op[1];
			return {
				value: op[0] ? op[1] : void 0,
				done: true
			};
		}
	};
	var __asyncValues = this$27 && this$27.__asyncValues || function(o) {
		if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
		var m = o[Symbol.asyncIterator], i;
		return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
			return this;
		}, i);
		function verb(n) {
			i[n] = o[n] && function(v) {
				return new Promise(function(resolve, reject) {
					v = o[n](v), settle(resolve, reject, v.done, v.value);
				});
			};
		}
		function settle(resolve, reject, d, v) {
			Promise.resolve(v).then(function(v) {
				resolve({
					value: v,
					done: d
				});
			}, reject);
		}
	};
	var __values = this$27 && this$27.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.fromReadableStreamLike = exports.fromAsyncIterable = exports.fromIterable = exports.fromPromise = exports.fromArrayLike = exports.fromInteropObservable = exports.innerFrom = void 0;
	var isArrayLike_1 = require_isArrayLike();
	var isPromise_1 = require_isPromise();
	var Observable_1 = require_Observable();
	var isInteropObservable_1 = require_isInteropObservable();
	var isAsyncIterable_1 = require_isAsyncIterable();
	var throwUnobservableError_1 = require_throwUnobservableError();
	var isIterable_1 = require_isIterable();
	var isReadableStreamLike_1 = require_isReadableStreamLike();
	var isFunction_1 = require_isFunction();
	var reportUnhandledError_1 = require_reportUnhandledError();
	var observable_1 = require_observable();
	function innerFrom(input) {
		if (input instanceof Observable_1.Observable) return input;
		if (input != null) {
			if (isInteropObservable_1.isInteropObservable(input)) return fromInteropObservable(input);
			if (isArrayLike_1.isArrayLike(input)) return fromArrayLike(input);
			if (isPromise_1.isPromise(input)) return fromPromise(input);
			if (isAsyncIterable_1.isAsyncIterable(input)) return fromAsyncIterable(input);
			if (isIterable_1.isIterable(input)) return fromIterable(input);
			if (isReadableStreamLike_1.isReadableStreamLike(input)) return fromReadableStreamLike(input);
		}
		throw throwUnobservableError_1.createInvalidObservableTypeError(input);
	}
	exports.innerFrom = innerFrom;
	function fromInteropObservable(obj) {
		return new Observable_1.Observable(function(subscriber) {
			var obs = obj[observable_1.observable]();
			if (isFunction_1.isFunction(obs.subscribe)) return obs.subscribe(subscriber);
			throw new TypeError("Provided object does not correctly implement Symbol.observable");
		});
	}
	exports.fromInteropObservable = fromInteropObservable;
	function fromArrayLike(array) {
		return new Observable_1.Observable(function(subscriber) {
			for (var i = 0; i < array.length && !subscriber.closed; i++) subscriber.next(array[i]);
			subscriber.complete();
		});
	}
	exports.fromArrayLike = fromArrayLike;
	function fromPromise(promise) {
		return new Observable_1.Observable(function(subscriber) {
			promise.then(function(value) {
				if (!subscriber.closed) {
					subscriber.next(value);
					subscriber.complete();
				}
			}, function(err) {
				return subscriber.error(err);
			}).then(null, reportUnhandledError_1.reportUnhandledError);
		});
	}
	exports.fromPromise = fromPromise;
	function fromIterable(iterable) {
		return new Observable_1.Observable(function(subscriber) {
			var e_1, _a;
			try {
				for (var iterable_1 = __values(iterable), iterable_1_1 = iterable_1.next(); !iterable_1_1.done; iterable_1_1 = iterable_1.next()) {
					var value = iterable_1_1.value;
					subscriber.next(value);
					if (subscriber.closed) return;
				}
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (iterable_1_1 && !iterable_1_1.done && (_a = iterable_1.return)) _a.call(iterable_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
			subscriber.complete();
		});
	}
	exports.fromIterable = fromIterable;
	function fromAsyncIterable(asyncIterable) {
		return new Observable_1.Observable(function(subscriber) {
			process(asyncIterable, subscriber).catch(function(err) {
				return subscriber.error(err);
			});
		});
	}
	exports.fromAsyncIterable = fromAsyncIterable;
	function fromReadableStreamLike(readableStream) {
		return fromAsyncIterable(isReadableStreamLike_1.readableStreamLikeToAsyncGenerator(readableStream));
	}
	exports.fromReadableStreamLike = fromReadableStreamLike;
	function process(asyncIterable, subscriber) {
		var asyncIterable_1, asyncIterable_1_1;
		var e_2, _a;
		return __awaiter(this, void 0, void 0, function() {
			var value, e_2_1;
			return __generator(this, function(_b) {
				switch (_b.label) {
					case 0:
						_b.trys.push([
							0,
							5,
							6,
							11
						]);
						asyncIterable_1 = __asyncValues(asyncIterable);
						_b.label = 1;
					case 1: return [4, asyncIterable_1.next()];
					case 2:
						if (!(asyncIterable_1_1 = _b.sent(), !asyncIterable_1_1.done)) return [3, 4];
						value = asyncIterable_1_1.value;
						subscriber.next(value);
						if (subscriber.closed) return [2];
						_b.label = 3;
					case 3: return [3, 1];
					case 4: return [3, 11];
					case 5:
						e_2_1 = _b.sent();
						e_2 = { error: e_2_1 };
						return [3, 11];
					case 6:
						_b.trys.push([
							6,
							,
							9,
							10
						]);
						if (!(asyncIterable_1_1 && !asyncIterable_1_1.done && (_a = asyncIterable_1.return))) return [3, 8];
						return [4, _a.call(asyncIterable_1)];
					case 7:
						_b.sent();
						_b.label = 8;
					case 8: return [3, 10];
					case 9:
						if (e_2) throw e_2.error;
						return [7];
					case 10: return [7];
					case 11:
						subscriber.complete();
						return [2];
				}
			});
		});
	}
}));
// node_modules/rxjs/dist/cjs/internal/util/executeSchedule.js
var require_executeSchedule = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.executeSchedule = void 0;
	function executeSchedule(parentSubscription, scheduler, work, delay, repeat) {
		if (delay === void 0) delay = 0;
		if (repeat === void 0) repeat = false;
		var scheduleSubscription = scheduler.schedule(function() {
			work();
			if (repeat) parentSubscription.add(this.schedule(null, delay));
			else this.unsubscribe();
		}, delay);
		parentSubscription.add(scheduleSubscription);
		if (!repeat) return scheduleSubscription;
	}
	exports.executeSchedule = executeSchedule;
}));
// node_modules/rxjs/dist/cjs/internal/operators/observeOn.js
var require_observeOn = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.observeOn = void 0;
	var executeSchedule_1 = require_executeSchedule();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function observeOn(scheduler, delay) {
		if (delay === void 0) delay = 0;
		return lift_1.operate(function(source, subscriber) {
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
					return subscriber.next(value);
				}, delay);
			}, function() {
				return executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
					return subscriber.complete();
				}, delay);
			}, function(err) {
				return executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
					return subscriber.error(err);
				}, delay);
			}));
		});
	}
	exports.observeOn = observeOn;
}));
// node_modules/rxjs/dist/cjs/internal/operators/subscribeOn.js
var require_subscribeOn = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.subscribeOn = void 0;
	var lift_1 = require_lift();
	function subscribeOn(scheduler, delay) {
		if (delay === void 0) delay = 0;
		return lift_1.operate(function(source, subscriber) {
			subscriber.add(scheduler.schedule(function() {
				return source.subscribe(subscriber);
			}, delay));
		});
	}
	exports.subscribeOn = subscribeOn;
}));
// node_modules/rxjs/dist/cjs/internal/scheduled/scheduleObservable.js
var require_scheduleObservable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scheduleObservable = void 0;
	var innerFrom_1 = require_innerFrom();
	var observeOn_1 = require_observeOn();
	var subscribeOn_1 = require_subscribeOn();
	function scheduleObservable(input, scheduler) {
		return innerFrom_1.innerFrom(input).pipe(subscribeOn_1.subscribeOn(scheduler), observeOn_1.observeOn(scheduler));
	}
	exports.scheduleObservable = scheduleObservable;
}));
// node_modules/rxjs/dist/cjs/internal/scheduled/schedulePromise.js
var require_schedulePromise = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.schedulePromise = void 0;
	var innerFrom_1 = require_innerFrom();
	var observeOn_1 = require_observeOn();
	var subscribeOn_1 = require_subscribeOn();
	function schedulePromise(input, scheduler) {
		return innerFrom_1.innerFrom(input).pipe(subscribeOn_1.subscribeOn(scheduler), observeOn_1.observeOn(scheduler));
	}
	exports.schedulePromise = schedulePromise;
}));
// node_modules/rxjs/dist/cjs/internal/scheduled/scheduleArray.js
var require_scheduleArray = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scheduleArray = void 0;
	var Observable_1 = require_Observable();
	function scheduleArray(input, scheduler) {
		return new Observable_1.Observable(function(subscriber) {
			var i = 0;
			return scheduler.schedule(function() {
				if (i === input.length) subscriber.complete();
				else {
					subscriber.next(input[i++]);
					if (!subscriber.closed) this.schedule();
				}
			});
		});
	}
	exports.scheduleArray = scheduleArray;
}));
// node_modules/rxjs/dist/cjs/internal/scheduled/scheduleIterable.js
var require_scheduleIterable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scheduleIterable = void 0;
	var Observable_1 = require_Observable();
	var iterator_1 = require_iterator();
	var isFunction_1 = require_isFunction();
	var executeSchedule_1 = require_executeSchedule();
	function scheduleIterable(input, scheduler) {
		return new Observable_1.Observable(function(subscriber) {
			var iterator;
			executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
				iterator = input[iterator_1.iterator]();
				executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
					var _a;
					var value;
					var done;
					try {
						_a = iterator.next(), value = _a.value, done = _a.done;
					} catch (err) {
						subscriber.error(err);
						return;
					}
					if (done) subscriber.complete();
					else subscriber.next(value);
				}, 0, true);
			});
			return function() {
				return isFunction_1.isFunction(iterator === null || iterator === void 0 ? void 0 : iterator.return) && iterator.return();
			};
		});
	}
	exports.scheduleIterable = scheduleIterable;
}));
// node_modules/rxjs/dist/cjs/internal/scheduled/scheduleAsyncIterable.js
var require_scheduleAsyncIterable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scheduleAsyncIterable = void 0;
	var Observable_1 = require_Observable();
	var executeSchedule_1 = require_executeSchedule();
	function scheduleAsyncIterable(input, scheduler) {
		if (!input) throw new Error("Iterable cannot be null");
		return new Observable_1.Observable(function(subscriber) {
			executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
				var iterator = input[Symbol.asyncIterator]();
				executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
					iterator.next().then(function(result) {
						if (result.done) subscriber.complete();
						else subscriber.next(result.value);
					});
				}, 0, true);
			});
		});
	}
	exports.scheduleAsyncIterable = scheduleAsyncIterable;
}));
// node_modules/rxjs/dist/cjs/internal/scheduled/scheduleReadableStreamLike.js
var require_scheduleReadableStreamLike = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scheduleReadableStreamLike = void 0;
	var scheduleAsyncIterable_1 = require_scheduleAsyncIterable();
	var isReadableStreamLike_1 = require_isReadableStreamLike();
	function scheduleReadableStreamLike(input, scheduler) {
		return scheduleAsyncIterable_1.scheduleAsyncIterable(isReadableStreamLike_1.readableStreamLikeToAsyncGenerator(input), scheduler);
	}
	exports.scheduleReadableStreamLike = scheduleReadableStreamLike;
}));
// node_modules/rxjs/dist/cjs/internal/scheduled/scheduled.js
var require_scheduled = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scheduled = void 0;
	var scheduleObservable_1 = require_scheduleObservable();
	var schedulePromise_1 = require_schedulePromise();
	var scheduleArray_1 = require_scheduleArray();
	var scheduleIterable_1 = require_scheduleIterable();
	var scheduleAsyncIterable_1 = require_scheduleAsyncIterable();
	var isInteropObservable_1 = require_isInteropObservable();
	var isPromise_1 = require_isPromise();
	var isArrayLike_1 = require_isArrayLike();
	var isIterable_1 = require_isIterable();
	var isAsyncIterable_1 = require_isAsyncIterable();
	var throwUnobservableError_1 = require_throwUnobservableError();
	var isReadableStreamLike_1 = require_isReadableStreamLike();
	var scheduleReadableStreamLike_1 = require_scheduleReadableStreamLike();
	function scheduled(input, scheduler) {
		if (input != null) {
			if (isInteropObservable_1.isInteropObservable(input)) return scheduleObservable_1.scheduleObservable(input, scheduler);
			if (isArrayLike_1.isArrayLike(input)) return scheduleArray_1.scheduleArray(input, scheduler);
			if (isPromise_1.isPromise(input)) return schedulePromise_1.schedulePromise(input, scheduler);
			if (isAsyncIterable_1.isAsyncIterable(input)) return scheduleAsyncIterable_1.scheduleAsyncIterable(input, scheduler);
			if (isIterable_1.isIterable(input)) return scheduleIterable_1.scheduleIterable(input, scheduler);
			if (isReadableStreamLike_1.isReadableStreamLike(input)) return scheduleReadableStreamLike_1.scheduleReadableStreamLike(input, scheduler);
		}
		throw throwUnobservableError_1.createInvalidObservableTypeError(input);
	}
	exports.scheduled = scheduled;
}));
// node_modules/rxjs/dist/cjs/internal/observable/from.js
var require_from = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.from = void 0;
	var scheduled_1 = require_scheduled();
	var innerFrom_1 = require_innerFrom();
	function from(input, scheduler) {
		return scheduler ? scheduled_1.scheduled(input, scheduler) : innerFrom_1.innerFrom(input);
	}
	exports.from = from;
}));
// node_modules/rxjs/dist/cjs/internal/observable/of.js
var require_of = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.of = void 0;
	var args_1 = require_args();
	var from_1 = require_from();
	function of() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var scheduler = args_1.popScheduler(args);
		return from_1.from(args, scheduler);
	}
	exports.of = of;
}));
// node_modules/rxjs/dist/cjs/internal/observable/throwError.js
var require_throwError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.throwError = void 0;
	var Observable_1 = require_Observable();
	var isFunction_1 = require_isFunction();
	function throwError(errorOrErrorFactory, scheduler) {
		var errorFactory = isFunction_1.isFunction(errorOrErrorFactory) ? errorOrErrorFactory : function() {
			return errorOrErrorFactory;
		};
		var init = function(subscriber) {
			return subscriber.error(errorFactory());
		};
		return new Observable_1.Observable(scheduler ? function(subscriber) {
			return scheduler.schedule(init, 0, subscriber);
		} : init);
	}
	exports.throwError = throwError;
}));
// node_modules/rxjs/dist/cjs/internal/Notification.js
var require_Notification = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.observeNotification = exports.Notification = exports.NotificationKind = void 0;
	var empty_1 = require_empty();
	var of_1 = require_of();
	var throwError_1 = require_throwError();
	var isFunction_1 = require_isFunction();
	(function(NotificationKind) {
		NotificationKind["NEXT"] = "N";
		NotificationKind["ERROR"] = "E";
		NotificationKind["COMPLETE"] = "C";
	})(exports.NotificationKind || (exports.NotificationKind = {}));
	exports.Notification = function() {
		function Notification(kind, value, error) {
			this.kind = kind;
			this.value = value;
			this.error = error;
			this.hasValue = kind === "N";
		}
		Notification.prototype.observe = function(observer) {
			return observeNotification(this, observer);
		};
		Notification.prototype.do = function(nextHandler, errorHandler, completeHandler) {
			var _a = this, kind = _a.kind, value = _a.value, error = _a.error;
			return kind === "N" ? nextHandler === null || nextHandler === void 0 ? void 0 : nextHandler(value) : kind === "E" ? errorHandler === null || errorHandler === void 0 ? void 0 : errorHandler(error) : completeHandler === null || completeHandler === void 0 ? void 0 : completeHandler();
		};
		Notification.prototype.accept = function(nextOrObserver, error, complete) {
			var _a;
			return isFunction_1.isFunction((_a = nextOrObserver) === null || _a === void 0 ? void 0 : _a.next) ? this.observe(nextOrObserver) : this.do(nextOrObserver, error, complete);
		};
		Notification.prototype.toObservable = function() {
			var _a = this, kind = _a.kind, value = _a.value, error = _a.error;
			var result = kind === "N" ? of_1.of(value) : kind === "E" ? throwError_1.throwError(function() {
				return error;
			}) : kind === "C" ? empty_1.EMPTY : 0;
			if (!result) throw new TypeError("Unexpected notification kind " + kind);
			return result;
		};
		Notification.createNext = function(value) {
			return new Notification("N", value);
		};
		Notification.createError = function(err) {
			return new Notification("E", void 0, err);
		};
		Notification.createComplete = function() {
			return Notification.completeNotification;
		};
		Notification.completeNotification = new Notification("C");
		return Notification;
	}();
	function observeNotification(notification, observer) {
		var _a, _b, _c;
		var _d = notification, kind = _d.kind, value = _d.value, error = _d.error;
		if (typeof kind !== "string") throw new TypeError("Invalid notification, missing \"kind\"");
		kind === "N" ? (_a = observer.next) === null || _a === void 0 || _a.call(observer, value) : kind === "E" ? (_b = observer.error) === null || _b === void 0 || _b.call(observer, error) : (_c = observer.complete) === null || _c === void 0 || _c.call(observer);
	}
	exports.observeNotification = observeNotification;
}));
// node_modules/rxjs/dist/cjs/internal/util/isObservable.js
var require_isObservable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isObservable = void 0;
	var Observable_1 = require_Observable();
	var isFunction_1 = require_isFunction();
	function isObservable(obj) {
		return !!obj && (obj instanceof Observable_1.Observable || isFunction_1.isFunction(obj.lift) && isFunction_1.isFunction(obj.subscribe));
	}
	exports.isObservable = isObservable;
}));
// node_modules/rxjs/dist/cjs/internal/util/EmptyError.js
var require_EmptyError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.EmptyError = void 0;
	exports.EmptyError = require_createErrorClass().createErrorClass(function(_super) {
		return function EmptyErrorImpl() {
			_super(this);
			this.name = "EmptyError";
			this.message = "no elements in sequence";
		};
	});
}));
// node_modules/rxjs/dist/cjs/internal/lastValueFrom.js
var require_lastValueFrom = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.lastValueFrom = void 0;
	var EmptyError_1 = require_EmptyError();
	function lastValueFrom(source, config) {
		var hasConfig = typeof config === "object";
		return new Promise(function(resolve, reject) {
			var _hasValue = false;
			var _value;
			source.subscribe({
				next: function(value) {
					_value = value;
					_hasValue = true;
				},
				error: reject,
				complete: function() {
					if (_hasValue) resolve(_value);
					else if (hasConfig) resolve(config.defaultValue);
					else reject(new EmptyError_1.EmptyError());
				}
			});
		});
	}
	exports.lastValueFrom = lastValueFrom;
}));
// node_modules/rxjs/dist/cjs/internal/firstValueFrom.js
var require_firstValueFrom = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.firstValueFrom = void 0;
	var EmptyError_1 = require_EmptyError();
	var Subscriber_1 = require_Subscriber();
	function firstValueFrom(source, config) {
		var hasConfig = typeof config === "object";
		return new Promise(function(resolve, reject) {
			var subscriber = new Subscriber_1.SafeSubscriber({
				next: function(value) {
					resolve(value);
					subscriber.unsubscribe();
				},
				error: reject,
				complete: function() {
					if (hasConfig) resolve(config.defaultValue);
					else reject(new EmptyError_1.EmptyError());
				}
			});
			source.subscribe(subscriber);
		});
	}
	exports.firstValueFrom = firstValueFrom;
}));
// node_modules/rxjs/dist/cjs/internal/util/ArgumentOutOfRangeError.js
var require_ArgumentOutOfRangeError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ArgumentOutOfRangeError = void 0;
	exports.ArgumentOutOfRangeError = require_createErrorClass().createErrorClass(function(_super) {
		return function ArgumentOutOfRangeErrorImpl() {
			_super(this);
			this.name = "ArgumentOutOfRangeError";
			this.message = "argument out of range";
		};
	});
}));
// node_modules/rxjs/dist/cjs/internal/util/NotFoundError.js
var require_NotFoundError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NotFoundError = void 0;
	exports.NotFoundError = require_createErrorClass().createErrorClass(function(_super) {
		return function NotFoundErrorImpl(message) {
			_super(this);
			this.name = "NotFoundError";
			this.message = message;
		};
	});
}));
// node_modules/rxjs/dist/cjs/internal/util/SequenceError.js
var require_SequenceError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.SequenceError = void 0;
	exports.SequenceError = require_createErrorClass().createErrorClass(function(_super) {
		return function SequenceErrorImpl(message) {
			_super(this);
			this.name = "SequenceError";
			this.message = message;
		};
	});
}));
// node_modules/rxjs/dist/cjs/internal/util/isDate.js
var require_isDate = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isValidDate = void 0;
	function isValidDate(value) {
		return value instanceof Date && !isNaN(value);
	}
	exports.isValidDate = isValidDate;
}));
// node_modules/rxjs/dist/cjs/internal/operators/timeout.js
var require_timeout = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.timeout = exports.TimeoutError = void 0;
	var async_1 = require_async();
	var isDate_1 = require_isDate();
	var lift_1 = require_lift();
	var innerFrom_1 = require_innerFrom();
	var createErrorClass_1 = require_createErrorClass();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var executeSchedule_1 = require_executeSchedule();
	exports.TimeoutError = createErrorClass_1.createErrorClass(function(_super) {
		return function TimeoutErrorImpl(info) {
			if (info === void 0) info = null;
			_super(this);
			this.message = "Timeout has occurred";
			this.name = "TimeoutError";
			this.info = info;
		};
	});
	function timeout(config, schedulerArg) {
		var _a = isDate_1.isValidDate(config) ? { first: config } : typeof config === "number" ? { each: config } : config, first = _a.first, each = _a.each, _b = _a.with, _with = _b === void 0 ? timeoutErrorFactory : _b, _c = _a.scheduler, scheduler = _c === void 0 ? schedulerArg !== null && schedulerArg !== void 0 ? schedulerArg : async_1.asyncScheduler : _c, _d = _a.meta, meta = _d === void 0 ? null : _d;
		if (first == null && each == null) throw new TypeError("No timeout provided.");
		return lift_1.operate(function(source, subscriber) {
			var originalSourceSubscription;
			var timerSubscription;
			var lastValue = null;
			var seen = 0;
			var startTimer = function(delay) {
				timerSubscription = executeSchedule_1.executeSchedule(subscriber, scheduler, function() {
					try {
						originalSourceSubscription.unsubscribe();
						innerFrom_1.innerFrom(_with({
							meta,
							lastValue,
							seen
						})).subscribe(subscriber);
					} catch (err) {
						subscriber.error(err);
					}
				}, delay);
			};
			originalSourceSubscription = source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				timerSubscription === null || timerSubscription === void 0 || timerSubscription.unsubscribe();
				seen++;
				subscriber.next(lastValue = value);
				each > 0 && startTimer(each);
			}, void 0, void 0, function() {
				if (!(timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.closed)) timerSubscription === null || timerSubscription === void 0 || timerSubscription.unsubscribe();
				lastValue = null;
			}));
			!seen && startTimer(first != null ? typeof first === "number" ? first : +first - scheduler.now() : each);
		});
	}
	exports.timeout = timeout;
	function timeoutErrorFactory(info) {
		throw new exports.TimeoutError(info);
	}
}));
// node_modules/rxjs/dist/cjs/internal/operators/map.js
var require_map = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.map = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function map(project, thisArg) {
		return lift_1.operate(function(source, subscriber) {
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				subscriber.next(project.call(thisArg, value, index++));
			}));
		});
	}
	exports.map = map;
}));
// node_modules/rxjs/dist/cjs/internal/util/mapOneOrManyArgs.js
var require_mapOneOrManyArgs = /* @__PURE__ */ __commonJSMin(((exports, module, this$26) => {
	var __read = this$26 && this$26.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$26 && this$26.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mapOneOrManyArgs = void 0;
	var map_1 = require_map();
	var isArray = Array.isArray;
	function callOrApply(fn, args) {
		return isArray(args) ? fn.apply(void 0, __spreadArray([], __read(args))) : fn(args);
	}
	function mapOneOrManyArgs(fn) {
		return map_1.map(function(args) {
			return callOrApply(fn, args);
		});
	}
	exports.mapOneOrManyArgs = mapOneOrManyArgs;
}));
// node_modules/rxjs/dist/cjs/internal/observable/bindCallbackInternals.js
var require_bindCallbackInternals = /* @__PURE__ */ __commonJSMin(((exports, module, this$25) => {
	var __read = this$25 && this$25.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$25 && this$25.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.bindCallbackInternals = void 0;
	var isScheduler_1 = require_isScheduler();
	var Observable_1 = require_Observable();
	var subscribeOn_1 = require_subscribeOn();
	var mapOneOrManyArgs_1 = require_mapOneOrManyArgs();
	var observeOn_1 = require_observeOn();
	var AsyncSubject_1 = require_AsyncSubject();
	function bindCallbackInternals(isNodeStyle, callbackFunc, resultSelector, scheduler) {
		if (resultSelector) {
			if (isScheduler_1.isScheduler(resultSelector)) scheduler = resultSelector;
			else return function() {
				var args = [];
				for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
				return bindCallbackInternals(isNodeStyle, callbackFunc, scheduler).apply(this, args).pipe(mapOneOrManyArgs_1.mapOneOrManyArgs(resultSelector));
			};
		}
		if (scheduler) return function() {
			var args = [];
			for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
			return bindCallbackInternals(isNodeStyle, callbackFunc).apply(this, args).pipe(subscribeOn_1.subscribeOn(scheduler), observeOn_1.observeOn(scheduler));
		};
		return function() {
			var _this = this;
			var args = [];
			for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
			var subject = new AsyncSubject_1.AsyncSubject();
			var uninitialized = true;
			return new Observable_1.Observable(function(subscriber) {
				var subs = subject.subscribe(subscriber);
				if (uninitialized) {
					uninitialized = false;
					var isAsync_1 = false;
					var isComplete_1 = false;
					callbackFunc.apply(_this, __spreadArray(__spreadArray([], __read(args)), [function() {
						var results = [];
						for (var _i = 0; _i < arguments.length; _i++) results[_i] = arguments[_i];
						if (isNodeStyle) {
							var err = results.shift();
							if (err != null) {
								subject.error(err);
								return;
							}
						}
						subject.next(1 < results.length ? results : results[0]);
						isComplete_1 = true;
						if (isAsync_1) subject.complete();
					}]));
					if (isComplete_1) subject.complete();
					isAsync_1 = true;
				}
				return subs;
			});
		};
	}
	exports.bindCallbackInternals = bindCallbackInternals;
}));
// node_modules/rxjs/dist/cjs/internal/observable/bindCallback.js
var require_bindCallback = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.bindCallback = void 0;
	var bindCallbackInternals_1 = require_bindCallbackInternals();
	function bindCallback(callbackFunc, resultSelector, scheduler) {
		return bindCallbackInternals_1.bindCallbackInternals(false, callbackFunc, resultSelector, scheduler);
	}
	exports.bindCallback = bindCallback;
}));
// node_modules/rxjs/dist/cjs/internal/observable/bindNodeCallback.js
var require_bindNodeCallback = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.bindNodeCallback = void 0;
	var bindCallbackInternals_1 = require_bindCallbackInternals();
	function bindNodeCallback(callbackFunc, resultSelector, scheduler) {
		return bindCallbackInternals_1.bindCallbackInternals(true, callbackFunc, resultSelector, scheduler);
	}
	exports.bindNodeCallback = bindNodeCallback;
}));
// node_modules/rxjs/dist/cjs/internal/util/argsArgArrayOrObject.js
var require_argsArgArrayOrObject = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.argsArgArrayOrObject = void 0;
	var isArray = Array.isArray;
	var getPrototypeOf = Object.getPrototypeOf;
	var objectProto = Object.prototype;
	var getKeys = Object.keys;
	function argsArgArrayOrObject(args) {
		if (args.length === 1) {
			var first_1 = args[0];
			if (isArray(first_1)) return {
				args: first_1,
				keys: null
			};
			if (isPOJO(first_1)) {
				var keys = getKeys(first_1);
				return {
					args: keys.map(function(key) {
						return first_1[key];
					}),
					keys
				};
			}
		}
		return {
			args,
			keys: null
		};
	}
	exports.argsArgArrayOrObject = argsArgArrayOrObject;
	function isPOJO(obj) {
		return obj && typeof obj === "object" && getPrototypeOf(obj) === objectProto;
	}
}));
// node_modules/rxjs/dist/cjs/internal/util/createObject.js
var require_createObject = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createObject = void 0;
	function createObject(keys, values) {
		return keys.reduce(function(result, key, i) {
			return result[key] = values[i], result;
		}, {});
	}
	exports.createObject = createObject;
}));
// node_modules/rxjs/dist/cjs/internal/observable/combineLatest.js
var require_combineLatest$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.combineLatestInit = exports.combineLatest = void 0;
	var Observable_1 = require_Observable();
	var argsArgArrayOrObject_1 = require_argsArgArrayOrObject();
	var from_1 = require_from();
	var identity_1 = require_identity();
	var mapOneOrManyArgs_1 = require_mapOneOrManyArgs();
	var args_1 = require_args();
	var createObject_1 = require_createObject();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var executeSchedule_1 = require_executeSchedule();
	function combineLatest() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var scheduler = args_1.popScheduler(args);
		var resultSelector = args_1.popResultSelector(args);
		var _a = argsArgArrayOrObject_1.argsArgArrayOrObject(args), observables = _a.args, keys = _a.keys;
		if (observables.length === 0) return from_1.from([], scheduler);
		var result = new Observable_1.Observable(combineLatestInit(observables, scheduler, keys ? function(values) {
			return createObject_1.createObject(keys, values);
		} : identity_1.identity));
		return resultSelector ? result.pipe(mapOneOrManyArgs_1.mapOneOrManyArgs(resultSelector)) : result;
	}
	exports.combineLatest = combineLatest;
	function combineLatestInit(observables, scheduler, valueTransform) {
		if (valueTransform === void 0) valueTransform = identity_1.identity;
		return function(subscriber) {
			maybeSchedule(scheduler, function() {
				var length = observables.length;
				var values = new Array(length);
				var active = length;
				var remainingFirstValues = length;
				var _loop_1 = function(i) {
					maybeSchedule(scheduler, function() {
						var source = from_1.from(observables[i], scheduler);
						var hasFirstValue = false;
						source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
							values[i] = value;
							if (!hasFirstValue) {
								hasFirstValue = true;
								remainingFirstValues--;
							}
							if (!remainingFirstValues) subscriber.next(valueTransform(values.slice()));
						}, function() {
							if (!--active) subscriber.complete();
						}));
					}, subscriber);
				};
				for (var i = 0; i < length; i++) _loop_1(i);
			}, subscriber);
		};
	}
	exports.combineLatestInit = combineLatestInit;
	function maybeSchedule(scheduler, execute, subscription) {
		if (scheduler) executeSchedule_1.executeSchedule(subscription, scheduler, execute);
		else execute();
	}
}));
// node_modules/rxjs/dist/cjs/internal/operators/mergeInternals.js
var require_mergeInternals = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeInternals = void 0;
	var innerFrom_1 = require_innerFrom();
	var executeSchedule_1 = require_executeSchedule();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function mergeInternals(source, subscriber, project, concurrent, onBeforeNext, expand, innerSubScheduler, additionalFinalizer) {
		var buffer = [];
		var active = 0;
		var index = 0;
		var isComplete = false;
		var checkComplete = function() {
			if (isComplete && !buffer.length && !active) subscriber.complete();
		};
		var outerNext = function(value) {
			return active < concurrent ? doInnerSub(value) : buffer.push(value);
		};
		var doInnerSub = function(value) {
			expand && subscriber.next(value);
			active++;
			var innerComplete = false;
			innerFrom_1.innerFrom(project(value, index++)).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(innerValue) {
				onBeforeNext === null || onBeforeNext === void 0 || onBeforeNext(innerValue);
				if (expand) outerNext(innerValue);
				else subscriber.next(innerValue);
			}, function() {
				innerComplete = true;
			}, void 0, function() {
				if (innerComplete) try {
					active--;
					var _loop_1 = function() {
						var bufferedValue = buffer.shift();
						if (innerSubScheduler) executeSchedule_1.executeSchedule(subscriber, innerSubScheduler, function() {
							return doInnerSub(bufferedValue);
						});
						else doInnerSub(bufferedValue);
					};
					while (buffer.length && active < concurrent) _loop_1();
					checkComplete();
				} catch (err) {
					subscriber.error(err);
				}
			}));
		};
		source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, outerNext, function() {
			isComplete = true;
			checkComplete();
		}));
		return function() {
			additionalFinalizer === null || additionalFinalizer === void 0 || additionalFinalizer();
		};
	}
	exports.mergeInternals = mergeInternals;
}));
// node_modules/rxjs/dist/cjs/internal/operators/mergeMap.js
var require_mergeMap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeMap = void 0;
	var map_1 = require_map();
	var innerFrom_1 = require_innerFrom();
	var lift_1 = require_lift();
	var mergeInternals_1 = require_mergeInternals();
	var isFunction_1 = require_isFunction();
	function mergeMap(project, resultSelector, concurrent) {
		if (concurrent === void 0) concurrent = Infinity;
		if (isFunction_1.isFunction(resultSelector)) return mergeMap(function(a, i) {
			return map_1.map(function(b, ii) {
				return resultSelector(a, b, i, ii);
			})(innerFrom_1.innerFrom(project(a, i)));
		}, concurrent);
		else if (typeof resultSelector === "number") concurrent = resultSelector;
		return lift_1.operate(function(source, subscriber) {
			return mergeInternals_1.mergeInternals(source, subscriber, project, concurrent);
		});
	}
	exports.mergeMap = mergeMap;
}));
// node_modules/rxjs/dist/cjs/internal/operators/mergeAll.js
var require_mergeAll = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeAll = void 0;
	var mergeMap_1 = require_mergeMap();
	var identity_1 = require_identity();
	function mergeAll(concurrent) {
		if (concurrent === void 0) concurrent = Infinity;
		return mergeMap_1.mergeMap(identity_1.identity, concurrent);
	}
	exports.mergeAll = mergeAll;
}));
// node_modules/rxjs/dist/cjs/internal/operators/concatAll.js
var require_concatAll = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.concatAll = void 0;
	var mergeAll_1 = require_mergeAll();
	function concatAll() {
		return mergeAll_1.mergeAll(1);
	}
	exports.concatAll = concatAll;
}));
// node_modules/rxjs/dist/cjs/internal/observable/concat.js
var require_concat$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.concat = void 0;
	var concatAll_1 = require_concatAll();
	var args_1 = require_args();
	var from_1 = require_from();
	function concat() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		return concatAll_1.concatAll()(from_1.from(args, args_1.popScheduler(args)));
	}
	exports.concat = concat;
}));
// node_modules/rxjs/dist/cjs/internal/observable/defer.js
var require_defer = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.defer = void 0;
	var Observable_1 = require_Observable();
	var innerFrom_1 = require_innerFrom();
	function defer(observableFactory) {
		return new Observable_1.Observable(function(subscriber) {
			innerFrom_1.innerFrom(observableFactory()).subscribe(subscriber);
		});
	}
	exports.defer = defer;
}));
// node_modules/rxjs/dist/cjs/internal/observable/connectable.js
var require_connectable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.connectable = void 0;
	var Subject_1 = require_Subject();
	var Observable_1 = require_Observable();
	var defer_1 = require_defer();
	var DEFAULT_CONFIG = {
		connector: function() {
			return new Subject_1.Subject();
		},
		resetOnDisconnect: true
	};
	function connectable(source, config) {
		if (config === void 0) config = DEFAULT_CONFIG;
		var connection = null;
		var connector = config.connector, _a = config.resetOnDisconnect, resetOnDisconnect = _a === void 0 ? true : _a;
		var subject = connector();
		var result = new Observable_1.Observable(function(subscriber) {
			return subject.subscribe(subscriber);
		});
		result.connect = function() {
			if (!connection || connection.closed) {
				connection = defer_1.defer(function() {
					return source;
				}).subscribe(subject);
				if (resetOnDisconnect) connection.add(function() {
					return subject = connector();
				});
			}
			return connection;
		};
		return result;
	}
	exports.connectable = connectable;
}));
// node_modules/rxjs/dist/cjs/internal/observable/forkJoin.js
var require_forkJoin = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.forkJoin = void 0;
	var Observable_1 = require_Observable();
	var argsArgArrayOrObject_1 = require_argsArgArrayOrObject();
	var innerFrom_1 = require_innerFrom();
	var args_1 = require_args();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var mapOneOrManyArgs_1 = require_mapOneOrManyArgs();
	var createObject_1 = require_createObject();
	function forkJoin() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var resultSelector = args_1.popResultSelector(args);
		var _a = argsArgArrayOrObject_1.argsArgArrayOrObject(args), sources = _a.args, keys = _a.keys;
		var result = new Observable_1.Observable(function(subscriber) {
			var length = sources.length;
			if (!length) {
				subscriber.complete();
				return;
			}
			var values = new Array(length);
			var remainingCompletions = length;
			var remainingEmissions = length;
			var _loop_1 = function(sourceIndex) {
				var hasValue = false;
				innerFrom_1.innerFrom(sources[sourceIndex]).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
					if (!hasValue) {
						hasValue = true;
						remainingEmissions--;
					}
					values[sourceIndex] = value;
				}, function() {
					return remainingCompletions--;
				}, void 0, function() {
					if (!remainingCompletions || !hasValue) {
						if (!remainingEmissions) subscriber.next(keys ? createObject_1.createObject(keys, values) : values);
						subscriber.complete();
					}
				}));
			};
			for (var sourceIndex = 0; sourceIndex < length; sourceIndex++) _loop_1(sourceIndex);
		});
		return resultSelector ? result.pipe(mapOneOrManyArgs_1.mapOneOrManyArgs(resultSelector)) : result;
	}
	exports.forkJoin = forkJoin;
}));
// node_modules/rxjs/dist/cjs/internal/observable/fromEvent.js
var require_fromEvent = /* @__PURE__ */ __commonJSMin(((exports, module, this$24) => {
	var __read = this$24 && this$24.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.fromEvent = void 0;
	var innerFrom_1 = require_innerFrom();
	var Observable_1 = require_Observable();
	var mergeMap_1 = require_mergeMap();
	var isArrayLike_1 = require_isArrayLike();
	var isFunction_1 = require_isFunction();
	var mapOneOrManyArgs_1 = require_mapOneOrManyArgs();
	var nodeEventEmitterMethods = ["addListener", "removeListener"];
	var eventTargetMethods = ["addEventListener", "removeEventListener"];
	var jqueryMethods = ["on", "off"];
	function fromEvent(target, eventName, options, resultSelector) {
		if (isFunction_1.isFunction(options)) {
			resultSelector = options;
			options = void 0;
		}
		if (resultSelector) return fromEvent(target, eventName, options).pipe(mapOneOrManyArgs_1.mapOneOrManyArgs(resultSelector));
		var _a = __read(isEventTarget(target) ? eventTargetMethods.map(function(methodName) {
			return function(handler) {
				return target[methodName](eventName, handler, options);
			};
		}) : isNodeStyleEventEmitter(target) ? nodeEventEmitterMethods.map(toCommonHandlerRegistry(target, eventName)) : isJQueryStyleEventEmitter(target) ? jqueryMethods.map(toCommonHandlerRegistry(target, eventName)) : [], 2), add = _a[0], remove = _a[1];
		if (!add) {
			if (isArrayLike_1.isArrayLike(target)) return mergeMap_1.mergeMap(function(subTarget) {
				return fromEvent(subTarget, eventName, options);
			})(innerFrom_1.innerFrom(target));
		}
		if (!add) throw new TypeError("Invalid event target");
		return new Observable_1.Observable(function(subscriber) {
			var handler = function() {
				var args = [];
				for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
				return subscriber.next(1 < args.length ? args : args[0]);
			};
			add(handler);
			return function() {
				return remove(handler);
			};
		});
	}
	exports.fromEvent = fromEvent;
	function toCommonHandlerRegistry(target, eventName) {
		return function(methodName) {
			return function(handler) {
				return target[methodName](eventName, handler);
			};
		};
	}
	function isNodeStyleEventEmitter(target) {
		return isFunction_1.isFunction(target.addListener) && isFunction_1.isFunction(target.removeListener);
	}
	function isJQueryStyleEventEmitter(target) {
		return isFunction_1.isFunction(target.on) && isFunction_1.isFunction(target.off);
	}
	function isEventTarget(target) {
		return isFunction_1.isFunction(target.addEventListener) && isFunction_1.isFunction(target.removeEventListener);
	}
}));
// node_modules/rxjs/dist/cjs/internal/observable/fromEventPattern.js
var require_fromEventPattern = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.fromEventPattern = void 0;
	var Observable_1 = require_Observable();
	var isFunction_1 = require_isFunction();
	var mapOneOrManyArgs_1 = require_mapOneOrManyArgs();
	function fromEventPattern(addHandler, removeHandler, resultSelector) {
		if (resultSelector) return fromEventPattern(addHandler, removeHandler).pipe(mapOneOrManyArgs_1.mapOneOrManyArgs(resultSelector));
		return new Observable_1.Observable(function(subscriber) {
			var handler = function() {
				var e = [];
				for (var _i = 0; _i < arguments.length; _i++) e[_i] = arguments[_i];
				return subscriber.next(e.length === 1 ? e[0] : e);
			};
			var retValue = addHandler(handler);
			return isFunction_1.isFunction(removeHandler) ? function() {
				return removeHandler(handler, retValue);
			} : void 0;
		});
	}
	exports.fromEventPattern = fromEventPattern;
}));
// node_modules/rxjs/dist/cjs/internal/observable/generate.js
var require_generate = /* @__PURE__ */ __commonJSMin(((exports, module, this$23) => {
	var __generator = this$23 && this$23.__generator || function(thisArg, body) {
		var _ = {
			label: 0,
			sent: function() {
				if (t[0] & 1) throw t[1];
				return t[1];
			},
			trys: [],
			ops: []
		}, f, y, t, g = {
			next: verb(0),
			"throw": verb(1),
			"return": verb(2)
		};
		return typeof Symbol === "function" && (g[Symbol.iterator] = function() {
			return this;
		}), g;
		function verb(n) {
			return function(v) {
				return step([n, v]);
			};
		}
		function step(op) {
			if (f) throw new TypeError("Generator is already executing.");
			while (_) try {
				if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
				if (y = 0, t) op = [op[0] & 2, t.value];
				switch (op[0]) {
					case 0:
					case 1:
						t = op;
						break;
					case 4:
						_.label++;
						return {
							value: op[1],
							done: false
						};
					case 5:
						_.label++;
						y = op[1];
						op = [0];
						continue;
					case 7:
						op = _.ops.pop();
						_.trys.pop();
						continue;
					default:
						if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
							_ = 0;
							continue;
						}
						if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
							_.label = op[1];
							break;
						}
						if (op[0] === 6 && _.label < t[1]) {
							_.label = t[1];
							t = op;
							break;
						}
						if (t && _.label < t[2]) {
							_.label = t[2];
							_.ops.push(op);
							break;
						}
						if (t[2]) _.ops.pop();
						_.trys.pop();
						continue;
				}
				op = body.call(thisArg, _);
			} catch (e) {
				op = [6, e];
				y = 0;
			} finally {
				f = t = 0;
			}
			if (op[0] & 5) throw op[1];
			return {
				value: op[0] ? op[1] : void 0,
				done: true
			};
		}
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.generate = void 0;
	var identity_1 = require_identity();
	var isScheduler_1 = require_isScheduler();
	var defer_1 = require_defer();
	var scheduleIterable_1 = require_scheduleIterable();
	function generate(initialStateOrOptions, condition, iterate, resultSelectorOrScheduler, scheduler) {
		var _a, _b;
		var resultSelector;
		var initialState;
		if (arguments.length === 1) _a = initialStateOrOptions, initialState = _a.initialState, condition = _a.condition, iterate = _a.iterate, _b = _a.resultSelector, resultSelector = _b === void 0 ? identity_1.identity : _b, scheduler = _a.scheduler;
		else {
			initialState = initialStateOrOptions;
			if (!resultSelectorOrScheduler || isScheduler_1.isScheduler(resultSelectorOrScheduler)) {
				resultSelector = identity_1.identity;
				scheduler = resultSelectorOrScheduler;
			} else resultSelector = resultSelectorOrScheduler;
		}
		function gen() {
			var state;
			return __generator(this, function(_a) {
				switch (_a.label) {
					case 0:
						state = initialState;
						_a.label = 1;
					case 1:
						if (!(!condition || condition(state))) return [3, 4];
						return [4, resultSelector(state)];
					case 2:
						_a.sent();
						_a.label = 3;
					case 3:
						state = iterate(state);
						return [3, 1];
					case 4: return [2];
				}
			});
		}
		return defer_1.defer(scheduler ? function() {
			return scheduleIterable_1.scheduleIterable(gen(), scheduler);
		} : gen);
	}
	exports.generate = generate;
}));
// node_modules/rxjs/dist/cjs/internal/observable/iif.js
var require_iif = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.iif = void 0;
	var defer_1 = require_defer();
	function iif(condition, trueResult, falseResult) {
		return defer_1.defer(function() {
			return condition() ? trueResult : falseResult;
		});
	}
	exports.iif = iif;
}));
// node_modules/rxjs/dist/cjs/internal/observable/timer.js
var require_timer = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.timer = void 0;
	var Observable_1 = require_Observable();
	var async_1 = require_async();
	var isScheduler_1 = require_isScheduler();
	var isDate_1 = require_isDate();
	function timer(dueTime, intervalOrScheduler, scheduler) {
		if (dueTime === void 0) dueTime = 0;
		if (scheduler === void 0) scheduler = async_1.async;
		var intervalDuration = -1;
		if (intervalOrScheduler != null) {
			if (isScheduler_1.isScheduler(intervalOrScheduler)) scheduler = intervalOrScheduler;
			else intervalDuration = intervalOrScheduler;
		}
		return new Observable_1.Observable(function(subscriber) {
			var due = isDate_1.isValidDate(dueTime) ? +dueTime - scheduler.now() : dueTime;
			if (due < 0) due = 0;
			var n = 0;
			return scheduler.schedule(function() {
				if (!subscriber.closed) {
					subscriber.next(n++);
					if (0 <= intervalDuration) this.schedule(void 0, intervalDuration);
					else subscriber.complete();
				}
			}, due);
		});
	}
	exports.timer = timer;
}));
// node_modules/rxjs/dist/cjs/internal/observable/interval.js
var require_interval = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.interval = void 0;
	var async_1 = require_async();
	var timer_1 = require_timer();
	function interval(period, scheduler) {
		if (period === void 0) period = 0;
		if (scheduler === void 0) scheduler = async_1.asyncScheduler;
		if (period < 0) period = 0;
		return timer_1.timer(period, period, scheduler);
	}
	exports.interval = interval;
}));
// node_modules/rxjs/dist/cjs/internal/observable/merge.js
var require_merge$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.merge = void 0;
	var mergeAll_1 = require_mergeAll();
	var innerFrom_1 = require_innerFrom();
	var empty_1 = require_empty();
	var args_1 = require_args();
	var from_1 = require_from();
	function merge() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var scheduler = args_1.popScheduler(args);
		var concurrent = args_1.popNumber(args, Infinity);
		var sources = args;
		return !sources.length ? empty_1.EMPTY : sources.length === 1 ? innerFrom_1.innerFrom(sources[0]) : mergeAll_1.mergeAll(concurrent)(from_1.from(sources, scheduler));
	}
	exports.merge = merge;
}));
// node_modules/rxjs/dist/cjs/internal/observable/never.js
var require_never = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.never = exports.NEVER = void 0;
	var Observable_1 = require_Observable();
	var noop_1 = require_noop();
	exports.NEVER = new Observable_1.Observable(noop_1.noop);
	function never() {
		return exports.NEVER;
	}
	exports.never = never;
}));
// node_modules/rxjs/dist/cjs/internal/util/argsOrArgArray.js
var require_argsOrArgArray = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.argsOrArgArray = void 0;
	var isArray = Array.isArray;
	function argsOrArgArray(args) {
		return args.length === 1 && isArray(args[0]) ? args[0] : args;
	}
	exports.argsOrArgArray = argsOrArgArray;
}));
// node_modules/rxjs/dist/cjs/internal/observable/onErrorResumeNext.js
var require_onErrorResumeNext = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.onErrorResumeNext = void 0;
	var Observable_1 = require_Observable();
	var argsOrArgArray_1 = require_argsOrArgArray();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var noop_1 = require_noop();
	var innerFrom_1 = require_innerFrom();
	function onErrorResumeNext() {
		var sources = [];
		for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
		var nextSources = argsOrArgArray_1.argsOrArgArray(sources);
		return new Observable_1.Observable(function(subscriber) {
			var sourceIndex = 0;
			var subscribeNext = function() {
				if (sourceIndex < nextSources.length) {
					var nextSource = void 0;
					try {
						nextSource = innerFrom_1.innerFrom(nextSources[sourceIndex++]);
					} catch (err) {
						subscribeNext();
						return;
					}
					var innerSubscriber = new OperatorSubscriber_1.OperatorSubscriber(subscriber, void 0, noop_1.noop, noop_1.noop);
					nextSource.subscribe(innerSubscriber);
					innerSubscriber.add(subscribeNext);
				} else subscriber.complete();
			};
			subscribeNext();
		});
	}
	exports.onErrorResumeNext = onErrorResumeNext;
}));
// node_modules/rxjs/dist/cjs/internal/observable/pairs.js
var require_pairs = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.pairs = void 0;
	var from_1 = require_from();
	function pairs(obj, scheduler) {
		return from_1.from(Object.entries(obj), scheduler);
	}
	exports.pairs = pairs;
}));
// node_modules/rxjs/dist/cjs/internal/util/not.js
var require_not = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.not = void 0;
	function not(pred, thisArg) {
		return function(value, index) {
			return !pred.call(thisArg, value, index);
		};
	}
	exports.not = not;
}));
// node_modules/rxjs/dist/cjs/internal/operators/filter.js
var require_filter = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.filter = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function filter(predicate, thisArg) {
		return lift_1.operate(function(source, subscriber) {
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return predicate.call(thisArg, value, index++) && subscriber.next(value);
			}));
		});
	}
	exports.filter = filter;
}));
// node_modules/rxjs/dist/cjs/internal/observable/partition.js
var require_partition$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.partition = void 0;
	var not_1 = require_not();
	var filter_1 = require_filter();
	var innerFrom_1 = require_innerFrom();
	function partition(source, predicate, thisArg) {
		return [filter_1.filter(predicate, thisArg)(innerFrom_1.innerFrom(source)), filter_1.filter(not_1.not(predicate, thisArg))(innerFrom_1.innerFrom(source))];
	}
	exports.partition = partition;
}));
// node_modules/rxjs/dist/cjs/internal/observable/race.js
var require_race$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.raceInit = exports.race = void 0;
	var Observable_1 = require_Observable();
	var innerFrom_1 = require_innerFrom();
	var argsOrArgArray_1 = require_argsOrArgArray();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function race() {
		var sources = [];
		for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
		sources = argsOrArgArray_1.argsOrArgArray(sources);
		return sources.length === 1 ? innerFrom_1.innerFrom(sources[0]) : new Observable_1.Observable(raceInit(sources));
	}
	exports.race = race;
	function raceInit(sources) {
		return function(subscriber) {
			var subscriptions = [];
			var _loop_1 = function(i) {
				subscriptions.push(innerFrom_1.innerFrom(sources[i]).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
					if (subscriptions) {
						for (var s = 0; s < subscriptions.length; s++) s !== i && subscriptions[s].unsubscribe();
						subscriptions = null;
					}
					subscriber.next(value);
				})));
			};
			for (var i = 0; subscriptions && !subscriber.closed && i < sources.length; i++) _loop_1(i);
		};
	}
	exports.raceInit = raceInit;
}));
// node_modules/rxjs/dist/cjs/internal/observable/range.js
var require_range = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.range = void 0;
	var Observable_1 = require_Observable();
	var empty_1 = require_empty();
	function range(start, count, scheduler) {
		if (count == null) {
			count = start;
			start = 0;
		}
		if (count <= 0) return empty_1.EMPTY;
		var end = count + start;
		return new Observable_1.Observable(scheduler ? function(subscriber) {
			var n = start;
			return scheduler.schedule(function() {
				if (n < end) {
					subscriber.next(n++);
					this.schedule();
				} else subscriber.complete();
			});
		} : function(subscriber) {
			var n = start;
			while (n < end && !subscriber.closed) subscriber.next(n++);
			subscriber.complete();
		});
	}
	exports.range = range;
}));
// node_modules/rxjs/dist/cjs/internal/observable/using.js
var require_using = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.using = void 0;
	var Observable_1 = require_Observable();
	var innerFrom_1 = require_innerFrom();
	var empty_1 = require_empty();
	function using(resourceFactory, observableFactory) {
		return new Observable_1.Observable(function(subscriber) {
			var resource = resourceFactory();
			var result = observableFactory(resource);
			(result ? innerFrom_1.innerFrom(result) : empty_1.EMPTY).subscribe(subscriber);
			return function() {
				if (resource) resource.unsubscribe();
			};
		});
	}
	exports.using = using;
}));
// node_modules/rxjs/dist/cjs/internal/observable/zip.js
var require_zip$1 = /* @__PURE__ */ __commonJSMin(((exports, module, this$22) => {
	var __read = this$22 && this$22.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$22 && this$22.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.zip = void 0;
	var Observable_1 = require_Observable();
	var innerFrom_1 = require_innerFrom();
	var argsOrArgArray_1 = require_argsOrArgArray();
	var empty_1 = require_empty();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var args_1 = require_args();
	function zip() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var resultSelector = args_1.popResultSelector(args);
		var sources = argsOrArgArray_1.argsOrArgArray(args);
		return sources.length ? new Observable_1.Observable(function(subscriber) {
			var buffers = sources.map(function() {
				return [];
			});
			var completed = sources.map(function() {
				return false;
			});
			subscriber.add(function() {
				buffers = completed = null;
			});
			var _loop_1 = function(sourceIndex) {
				innerFrom_1.innerFrom(sources[sourceIndex]).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
					buffers[sourceIndex].push(value);
					if (buffers.every(function(buffer) {
						return buffer.length;
					})) {
						var result = buffers.map(function(buffer) {
							return buffer.shift();
						});
						subscriber.next(resultSelector ? resultSelector.apply(void 0, __spreadArray([], __read(result))) : result);
						if (buffers.some(function(buffer, i) {
							return !buffer.length && completed[i];
						})) subscriber.complete();
					}
				}, function() {
					completed[sourceIndex] = true;
					!buffers[sourceIndex].length && subscriber.complete();
				}));
			};
			for (var sourceIndex = 0; !subscriber.closed && sourceIndex < sources.length; sourceIndex++) _loop_1(sourceIndex);
			return function() {
				buffers = completed = null;
			};
		}) : empty_1.EMPTY;
	}
	exports.zip = zip;
}));
// node_modules/rxjs/dist/cjs/internal/types.js
var require_types = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
}));
// node_modules/rxjs/dist/cjs/internal/operators/audit.js
var require_audit = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.audit = void 0;
	var lift_1 = require_lift();
	var innerFrom_1 = require_innerFrom();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function audit(durationSelector) {
		return lift_1.operate(function(source, subscriber) {
			var hasValue = false;
			var lastValue = null;
			var durationSubscriber = null;
			var isComplete = false;
			var endDuration = function() {
				durationSubscriber === null || durationSubscriber === void 0 || durationSubscriber.unsubscribe();
				durationSubscriber = null;
				if (hasValue) {
					hasValue = false;
					var value = lastValue;
					lastValue = null;
					subscriber.next(value);
				}
				isComplete && subscriber.complete();
			};
			var cleanupDuration = function() {
				durationSubscriber = null;
				isComplete && subscriber.complete();
			};
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				hasValue = true;
				lastValue = value;
				if (!durationSubscriber) innerFrom_1.innerFrom(durationSelector(value)).subscribe(durationSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, endDuration, cleanupDuration));
			}, function() {
				isComplete = true;
				(!hasValue || !durationSubscriber || durationSubscriber.closed) && subscriber.complete();
			}));
		});
	}
	exports.audit = audit;
}));
// node_modules/rxjs/dist/cjs/internal/operators/auditTime.js
var require_auditTime = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.auditTime = void 0;
	var async_1 = require_async();
	var audit_1 = require_audit();
	var timer_1 = require_timer();
	function auditTime(duration, scheduler) {
		if (scheduler === void 0) scheduler = async_1.asyncScheduler;
		return audit_1.audit(function() {
			return timer_1.timer(duration, scheduler);
		});
	}
	exports.auditTime = auditTime;
}));
// node_modules/rxjs/dist/cjs/internal/operators/buffer.js
var require_buffer = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.buffer = void 0;
	var lift_1 = require_lift();
	var noop_1 = require_noop();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	function buffer(closingNotifier) {
		return lift_1.operate(function(source, subscriber) {
			var currentBuffer = [];
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return currentBuffer.push(value);
			}, function() {
				subscriber.next(currentBuffer);
				subscriber.complete();
			}));
			innerFrom_1.innerFrom(closingNotifier).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
				var b = currentBuffer;
				currentBuffer = [];
				subscriber.next(b);
			}, noop_1.noop));
			return function() {
				currentBuffer = null;
			};
		});
	}
	exports.buffer = buffer;
}));
// node_modules/rxjs/dist/cjs/internal/operators/bufferCount.js
var require_bufferCount = /* @__PURE__ */ __commonJSMin(((exports, module, this$21) => {
	var __values = this$21 && this$21.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.bufferCount = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var arrRemove_1 = require_arrRemove();
	function bufferCount(bufferSize, startBufferEvery) {
		if (startBufferEvery === void 0) startBufferEvery = null;
		startBufferEvery = startBufferEvery !== null && startBufferEvery !== void 0 ? startBufferEvery : bufferSize;
		return lift_1.operate(function(source, subscriber) {
			var buffers = [];
			var count = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var e_1, _a, e_2, _b;
				var toEmit = null;
				if (count++ % startBufferEvery === 0) buffers.push([]);
				try {
					for (var buffers_1 = __values(buffers), buffers_1_1 = buffers_1.next(); !buffers_1_1.done; buffers_1_1 = buffers_1.next()) {
						var buffer = buffers_1_1.value;
						buffer.push(value);
						if (bufferSize <= buffer.length) {
							toEmit = toEmit !== null && toEmit !== void 0 ? toEmit : [];
							toEmit.push(buffer);
						}
					}
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (buffers_1_1 && !buffers_1_1.done && (_a = buffers_1.return)) _a.call(buffers_1);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
				if (toEmit) try {
					for (var toEmit_1 = __values(toEmit), toEmit_1_1 = toEmit_1.next(); !toEmit_1_1.done; toEmit_1_1 = toEmit_1.next()) {
						var buffer = toEmit_1_1.value;
						arrRemove_1.arrRemove(buffers, buffer);
						subscriber.next(buffer);
					}
				} catch (e_2_1) {
					e_2 = { error: e_2_1 };
				} finally {
					try {
						if (toEmit_1_1 && !toEmit_1_1.done && (_b = toEmit_1.return)) _b.call(toEmit_1);
					} finally {
						if (e_2) throw e_2.error;
					}
				}
			}, function() {
				var e_3, _a;
				try {
					for (var buffers_2 = __values(buffers), buffers_2_1 = buffers_2.next(); !buffers_2_1.done; buffers_2_1 = buffers_2.next()) {
						var buffer = buffers_2_1.value;
						subscriber.next(buffer);
					}
				} catch (e_3_1) {
					e_3 = { error: e_3_1 };
				} finally {
					try {
						if (buffers_2_1 && !buffers_2_1.done && (_a = buffers_2.return)) _a.call(buffers_2);
					} finally {
						if (e_3) throw e_3.error;
					}
				}
				subscriber.complete();
			}, void 0, function() {
				buffers = null;
			}));
		});
	}
	exports.bufferCount = bufferCount;
}));
// node_modules/rxjs/dist/cjs/internal/operators/bufferTime.js
var require_bufferTime = /* @__PURE__ */ __commonJSMin(((exports, module, this$20) => {
	var __values = this$20 && this$20.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.bufferTime = void 0;
	var Subscription_1 = require_Subscription();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var arrRemove_1 = require_arrRemove();
	var async_1 = require_async();
	var args_1 = require_args();
	var executeSchedule_1 = require_executeSchedule();
	function bufferTime(bufferTimeSpan) {
		var _a, _b;
		var otherArgs = [];
		for (var _i = 1; _i < arguments.length; _i++) otherArgs[_i - 1] = arguments[_i];
		var scheduler = (_a = args_1.popScheduler(otherArgs)) !== null && _a !== void 0 ? _a : async_1.asyncScheduler;
		var bufferCreationInterval = (_b = otherArgs[0]) !== null && _b !== void 0 ? _b : null;
		var maxBufferSize = otherArgs[1] || Infinity;
		return lift_1.operate(function(source, subscriber) {
			var bufferRecords = [];
			var restartOnEmit = false;
			var emit = function(record) {
				var buffer = record.buffer;
				record.subs.unsubscribe();
				arrRemove_1.arrRemove(bufferRecords, record);
				subscriber.next(buffer);
				restartOnEmit && startBuffer();
			};
			var startBuffer = function() {
				if (bufferRecords) {
					var subs = new Subscription_1.Subscription();
					subscriber.add(subs);
					var record_1 = {
						buffer: [],
						subs
					};
					bufferRecords.push(record_1);
					executeSchedule_1.executeSchedule(subs, scheduler, function() {
						return emit(record_1);
					}, bufferTimeSpan);
				}
			};
			if (bufferCreationInterval !== null && bufferCreationInterval >= 0) executeSchedule_1.executeSchedule(subscriber, scheduler, startBuffer, bufferCreationInterval, true);
			else restartOnEmit = true;
			startBuffer();
			var bufferTimeSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var e_1, _a;
				var recordsCopy = bufferRecords.slice();
				try {
					for (var recordsCopy_1 = __values(recordsCopy), recordsCopy_1_1 = recordsCopy_1.next(); !recordsCopy_1_1.done; recordsCopy_1_1 = recordsCopy_1.next()) {
						var record = recordsCopy_1_1.value;
						var buffer = record.buffer;
						buffer.push(value);
						maxBufferSize <= buffer.length && emit(record);
					}
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (recordsCopy_1_1 && !recordsCopy_1_1.done && (_a = recordsCopy_1.return)) _a.call(recordsCopy_1);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
			}, function() {
				while (bufferRecords === null || bufferRecords === void 0 ? void 0 : bufferRecords.length) subscriber.next(bufferRecords.shift().buffer);
				bufferTimeSubscriber === null || bufferTimeSubscriber === void 0 || bufferTimeSubscriber.unsubscribe();
				subscriber.complete();
				subscriber.unsubscribe();
			}, void 0, function() {
				return bufferRecords = null;
			});
			source.subscribe(bufferTimeSubscriber);
		});
	}
	exports.bufferTime = bufferTime;
}));
// node_modules/rxjs/dist/cjs/internal/operators/bufferToggle.js
var require_bufferToggle = /* @__PURE__ */ __commonJSMin(((exports, module, this$19) => {
	var __values = this$19 && this$19.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.bufferToggle = void 0;
	var Subscription_1 = require_Subscription();
	var lift_1 = require_lift();
	var innerFrom_1 = require_innerFrom();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var noop_1 = require_noop();
	var arrRemove_1 = require_arrRemove();
	function bufferToggle(openings, closingSelector) {
		return lift_1.operate(function(source, subscriber) {
			var buffers = [];
			innerFrom_1.innerFrom(openings).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(openValue) {
				var buffer = [];
				buffers.push(buffer);
				var closingSubscription = new Subscription_1.Subscription();
				var emitBuffer = function() {
					arrRemove_1.arrRemove(buffers, buffer);
					subscriber.next(buffer);
					closingSubscription.unsubscribe();
				};
				closingSubscription.add(innerFrom_1.innerFrom(closingSelector(openValue)).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, emitBuffer, noop_1.noop)));
			}, noop_1.noop));
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var e_1, _a;
				try {
					for (var buffers_1 = __values(buffers), buffers_1_1 = buffers_1.next(); !buffers_1_1.done; buffers_1_1 = buffers_1.next()) buffers_1_1.value.push(value);
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (buffers_1_1 && !buffers_1_1.done && (_a = buffers_1.return)) _a.call(buffers_1);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
			}, function() {
				while (buffers.length > 0) subscriber.next(buffers.shift());
				subscriber.complete();
			}));
		});
	}
	exports.bufferToggle = bufferToggle;
}));
// node_modules/rxjs/dist/cjs/internal/operators/bufferWhen.js
var require_bufferWhen = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.bufferWhen = void 0;
	var lift_1 = require_lift();
	var noop_1 = require_noop();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	function bufferWhen(closingSelector) {
		return lift_1.operate(function(source, subscriber) {
			var buffer = null;
			var closingSubscriber = null;
			var openBuffer = function() {
				closingSubscriber === null || closingSubscriber === void 0 || closingSubscriber.unsubscribe();
				var b = buffer;
				buffer = [];
				b && subscriber.next(b);
				innerFrom_1.innerFrom(closingSelector()).subscribe(closingSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, openBuffer, noop_1.noop));
			};
			openBuffer();
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return buffer === null || buffer === void 0 ? void 0 : buffer.push(value);
			}, function() {
				buffer && subscriber.next(buffer);
				subscriber.complete();
			}, void 0, function() {
				return buffer = closingSubscriber = null;
			}));
		});
	}
	exports.bufferWhen = bufferWhen;
}));
// node_modules/rxjs/dist/cjs/internal/operators/catchError.js
var require_catchError = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.catchError = void 0;
	var innerFrom_1 = require_innerFrom();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var lift_1 = require_lift();
	function catchError(selector) {
		return lift_1.operate(function(source, subscriber) {
			var innerSub = null;
			var syncUnsub = false;
			var handledResult;
			innerSub = source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, void 0, void 0, function(err) {
				handledResult = innerFrom_1.innerFrom(selector(err, catchError(selector)(source)));
				if (innerSub) {
					innerSub.unsubscribe();
					innerSub = null;
					handledResult.subscribe(subscriber);
				} else syncUnsub = true;
			}));
			if (syncUnsub) {
				innerSub.unsubscribe();
				innerSub = null;
				handledResult.subscribe(subscriber);
			}
		});
	}
	exports.catchError = catchError;
}));
// node_modules/rxjs/dist/cjs/internal/operators/scanInternals.js
var require_scanInternals = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scanInternals = void 0;
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function scanInternals(accumulator, seed, hasSeed, emitOnNext, emitBeforeComplete) {
		return function(source, subscriber) {
			var hasState = hasSeed;
			var state = seed;
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var i = index++;
				state = hasState ? accumulator(state, value, i) : (hasState = true, value);
				emitOnNext && subscriber.next(state);
			}, emitBeforeComplete && (function() {
				hasState && subscriber.next(state);
				subscriber.complete();
			})));
		};
	}
	exports.scanInternals = scanInternals;
}));
// node_modules/rxjs/dist/cjs/internal/operators/reduce.js
var require_reduce = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.reduce = void 0;
	var scanInternals_1 = require_scanInternals();
	var lift_1 = require_lift();
	function reduce(accumulator, seed) {
		return lift_1.operate(scanInternals_1.scanInternals(accumulator, seed, arguments.length >= 2, false, true));
	}
	exports.reduce = reduce;
}));
// node_modules/rxjs/dist/cjs/internal/operators/toArray.js
var require_toArray = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.toArray = void 0;
	var reduce_1 = require_reduce();
	var lift_1 = require_lift();
	var arrReducer = function(arr, value) {
		return arr.push(value), arr;
	};
	function toArray() {
		return lift_1.operate(function(source, subscriber) {
			reduce_1.reduce(arrReducer, [])(source).subscribe(subscriber);
		});
	}
	exports.toArray = toArray;
}));
// node_modules/rxjs/dist/cjs/internal/operators/joinAllInternals.js
var require_joinAllInternals = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.joinAllInternals = void 0;
	var identity_1 = require_identity();
	var mapOneOrManyArgs_1 = require_mapOneOrManyArgs();
	var pipe_1 = require_pipe();
	var mergeMap_1 = require_mergeMap();
	var toArray_1 = require_toArray();
	function joinAllInternals(joinFn, project) {
		return pipe_1.pipe(toArray_1.toArray(), mergeMap_1.mergeMap(function(sources) {
			return joinFn(sources);
		}), project ? mapOneOrManyArgs_1.mapOneOrManyArgs(project) : identity_1.identity);
	}
	exports.joinAllInternals = joinAllInternals;
}));
// node_modules/rxjs/dist/cjs/internal/operators/combineLatestAll.js
var require_combineLatestAll = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.combineLatestAll = void 0;
	var combineLatest_1 = require_combineLatest$1();
	var joinAllInternals_1 = require_joinAllInternals();
	function combineLatestAll(project) {
		return joinAllInternals_1.joinAllInternals(combineLatest_1.combineLatest, project);
	}
	exports.combineLatestAll = combineLatestAll;
}));
// node_modules/rxjs/dist/cjs/internal/operators/combineAll.js
var require_combineAll = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.combineAll = void 0;
	exports.combineAll = require_combineLatestAll().combineLatestAll;
}));
// node_modules/rxjs/dist/cjs/internal/operators/combineLatest.js
var require_combineLatest = /* @__PURE__ */ __commonJSMin(((exports, module, this$18) => {
	var __read = this$18 && this$18.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$18 && this$18.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.combineLatest = void 0;
	var combineLatest_1 = require_combineLatest$1();
	var lift_1 = require_lift();
	var argsOrArgArray_1 = require_argsOrArgArray();
	var mapOneOrManyArgs_1 = require_mapOneOrManyArgs();
	var pipe_1 = require_pipe();
	var args_1 = require_args();
	function combineLatest() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var resultSelector = args_1.popResultSelector(args);
		return resultSelector ? pipe_1.pipe(combineLatest.apply(void 0, __spreadArray([], __read(args))), mapOneOrManyArgs_1.mapOneOrManyArgs(resultSelector)) : lift_1.operate(function(source, subscriber) {
			combineLatest_1.combineLatestInit(__spreadArray([source], __read(argsOrArgArray_1.argsOrArgArray(args))))(subscriber);
		});
	}
	exports.combineLatest = combineLatest;
}));
// node_modules/rxjs/dist/cjs/internal/operators/combineLatestWith.js
var require_combineLatestWith = /* @__PURE__ */ __commonJSMin(((exports, module, this$17) => {
	var __read = this$17 && this$17.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$17 && this$17.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.combineLatestWith = void 0;
	var combineLatest_1 = require_combineLatest();
	function combineLatestWith() {
		var otherSources = [];
		for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
		return combineLatest_1.combineLatest.apply(void 0, __spreadArray([], __read(otherSources)));
	}
	exports.combineLatestWith = combineLatestWith;
}));
// node_modules/rxjs/dist/cjs/internal/operators/concatMap.js
var require_concatMap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.concatMap = void 0;
	var mergeMap_1 = require_mergeMap();
	var isFunction_1 = require_isFunction();
	function concatMap(project, resultSelector) {
		return isFunction_1.isFunction(resultSelector) ? mergeMap_1.mergeMap(project, resultSelector, 1) : mergeMap_1.mergeMap(project, 1);
	}
	exports.concatMap = concatMap;
}));
// node_modules/rxjs/dist/cjs/internal/operators/concatMapTo.js
var require_concatMapTo = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.concatMapTo = void 0;
	var concatMap_1 = require_concatMap();
	var isFunction_1 = require_isFunction();
	function concatMapTo(innerObservable, resultSelector) {
		return isFunction_1.isFunction(resultSelector) ? concatMap_1.concatMap(function() {
			return innerObservable;
		}, resultSelector) : concatMap_1.concatMap(function() {
			return innerObservable;
		});
	}
	exports.concatMapTo = concatMapTo;
}));
// node_modules/rxjs/dist/cjs/internal/operators/concat.js
var require_concat = /* @__PURE__ */ __commonJSMin(((exports, module, this$16) => {
	var __read = this$16 && this$16.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$16 && this$16.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.concat = void 0;
	var lift_1 = require_lift();
	var concatAll_1 = require_concatAll();
	var args_1 = require_args();
	var from_1 = require_from();
	function concat() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var scheduler = args_1.popScheduler(args);
		return lift_1.operate(function(source, subscriber) {
			concatAll_1.concatAll()(from_1.from(__spreadArray([source], __read(args)), scheduler)).subscribe(subscriber);
		});
	}
	exports.concat = concat;
}));
// node_modules/rxjs/dist/cjs/internal/operators/concatWith.js
var require_concatWith = /* @__PURE__ */ __commonJSMin(((exports, module, this$15) => {
	var __read = this$15 && this$15.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$15 && this$15.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.concatWith = void 0;
	var concat_1 = require_concat();
	function concatWith() {
		var otherSources = [];
		for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
		return concat_1.concat.apply(void 0, __spreadArray([], __read(otherSources)));
	}
	exports.concatWith = concatWith;
}));
// node_modules/rxjs/dist/cjs/internal/observable/fromSubscribable.js
var require_fromSubscribable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.fromSubscribable = void 0;
	var Observable_1 = require_Observable();
	function fromSubscribable(subscribable) {
		return new Observable_1.Observable(function(subscriber) {
			return subscribable.subscribe(subscriber);
		});
	}
	exports.fromSubscribable = fromSubscribable;
}));
// node_modules/rxjs/dist/cjs/internal/operators/connect.js
var require_connect = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.connect = void 0;
	var Subject_1 = require_Subject();
	var innerFrom_1 = require_innerFrom();
	var lift_1 = require_lift();
	var fromSubscribable_1 = require_fromSubscribable();
	var DEFAULT_CONFIG = { connector: function() {
		return new Subject_1.Subject();
	} };
	function connect(selector, config) {
		if (config === void 0) config = DEFAULT_CONFIG;
		var connector = config.connector;
		return lift_1.operate(function(source, subscriber) {
			var subject = connector();
			innerFrom_1.innerFrom(selector(fromSubscribable_1.fromSubscribable(subject))).subscribe(subscriber);
			subscriber.add(source.subscribe(subject));
		});
	}
	exports.connect = connect;
}));
// node_modules/rxjs/dist/cjs/internal/operators/count.js
var require_count = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.count = void 0;
	var reduce_1 = require_reduce();
	function count(predicate) {
		return reduce_1.reduce(function(total, value, i) {
			return !predicate || predicate(value, i) ? total + 1 : total;
		}, 0);
	}
	exports.count = count;
}));
// node_modules/rxjs/dist/cjs/internal/operators/debounce.js
var require_debounce = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.debounce = void 0;
	var lift_1 = require_lift();
	var noop_1 = require_noop();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	function debounce(durationSelector) {
		return lift_1.operate(function(source, subscriber) {
			var hasValue = false;
			var lastValue = null;
			var durationSubscriber = null;
			var emit = function() {
				durationSubscriber === null || durationSubscriber === void 0 || durationSubscriber.unsubscribe();
				durationSubscriber = null;
				if (hasValue) {
					hasValue = false;
					var value = lastValue;
					lastValue = null;
					subscriber.next(value);
				}
			};
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				durationSubscriber === null || durationSubscriber === void 0 || durationSubscriber.unsubscribe();
				hasValue = true;
				lastValue = value;
				durationSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, emit, noop_1.noop);
				innerFrom_1.innerFrom(durationSelector(value)).subscribe(durationSubscriber);
			}, function() {
				emit();
				subscriber.complete();
			}, void 0, function() {
				lastValue = durationSubscriber = null;
			}));
		});
	}
	exports.debounce = debounce;
}));
// node_modules/rxjs/dist/cjs/internal/operators/debounceTime.js
var require_debounceTime = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.debounceTime = void 0;
	var async_1 = require_async();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function debounceTime(dueTime, scheduler) {
		if (scheduler === void 0) scheduler = async_1.asyncScheduler;
		return lift_1.operate(function(source, subscriber) {
			var activeTask = null;
			var lastValue = null;
			var lastTime = null;
			var emit = function() {
				if (activeTask) {
					activeTask.unsubscribe();
					activeTask = null;
					var value = lastValue;
					lastValue = null;
					subscriber.next(value);
				}
			};
			function emitWhenIdle() {
				var targetTime = lastTime + dueTime;
				var now = scheduler.now();
				if (now < targetTime) {
					activeTask = this.schedule(void 0, targetTime - now);
					subscriber.add(activeTask);
					return;
				}
				emit();
			}
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				lastValue = value;
				lastTime = scheduler.now();
				if (!activeTask) {
					activeTask = scheduler.schedule(emitWhenIdle, dueTime);
					subscriber.add(activeTask);
				}
			}, function() {
				emit();
				subscriber.complete();
			}, void 0, function() {
				lastValue = activeTask = null;
			}));
		});
	}
	exports.debounceTime = debounceTime;
}));
// node_modules/rxjs/dist/cjs/internal/operators/defaultIfEmpty.js
var require_defaultIfEmpty = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.defaultIfEmpty = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function defaultIfEmpty(defaultValue) {
		return lift_1.operate(function(source, subscriber) {
			var hasValue = false;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				hasValue = true;
				subscriber.next(value);
			}, function() {
				if (!hasValue) subscriber.next(defaultValue);
				subscriber.complete();
			}));
		});
	}
	exports.defaultIfEmpty = defaultIfEmpty;
}));
// node_modules/rxjs/dist/cjs/internal/operators/take.js
var require_take = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.take = void 0;
	var empty_1 = require_empty();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function take(count) {
		return count <= 0 ? function() {
			return empty_1.EMPTY;
		} : lift_1.operate(function(source, subscriber) {
			var seen = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				if (++seen <= count) {
					subscriber.next(value);
					if (count <= seen) subscriber.complete();
				}
			}));
		});
	}
	exports.take = take;
}));
// node_modules/rxjs/dist/cjs/internal/operators/ignoreElements.js
var require_ignoreElements = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ignoreElements = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var noop_1 = require_noop();
	function ignoreElements() {
		return lift_1.operate(function(source, subscriber) {
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, noop_1.noop));
		});
	}
	exports.ignoreElements = ignoreElements;
}));
// node_modules/rxjs/dist/cjs/internal/operators/mapTo.js
var require_mapTo = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mapTo = void 0;
	var map_1 = require_map();
	function mapTo(value) {
		return map_1.map(function() {
			return value;
		});
	}
	exports.mapTo = mapTo;
}));
// node_modules/rxjs/dist/cjs/internal/operators/delayWhen.js
var require_delayWhen = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.delayWhen = void 0;
	var concat_1 = require_concat$1();
	var take_1 = require_take();
	var ignoreElements_1 = require_ignoreElements();
	var mapTo_1 = require_mapTo();
	var mergeMap_1 = require_mergeMap();
	var innerFrom_1 = require_innerFrom();
	function delayWhen(delayDurationSelector, subscriptionDelay) {
		if (subscriptionDelay) return function(source) {
			return concat_1.concat(subscriptionDelay.pipe(take_1.take(1), ignoreElements_1.ignoreElements()), source.pipe(delayWhen(delayDurationSelector)));
		};
		return mergeMap_1.mergeMap(function(value, index) {
			return innerFrom_1.innerFrom(delayDurationSelector(value, index)).pipe(take_1.take(1), mapTo_1.mapTo(value));
		});
	}
	exports.delayWhen = delayWhen;
}));
// node_modules/rxjs/dist/cjs/internal/operators/delay.js
var require_delay = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.delay = void 0;
	var async_1 = require_async();
	var delayWhen_1 = require_delayWhen();
	var timer_1 = require_timer();
	function delay(due, scheduler) {
		if (scheduler === void 0) scheduler = async_1.asyncScheduler;
		var duration = timer_1.timer(due, scheduler);
		return delayWhen_1.delayWhen(function() {
			return duration;
		});
	}
	exports.delay = delay;
}));
// node_modules/rxjs/dist/cjs/internal/operators/dematerialize.js
var require_dematerialize = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.dematerialize = void 0;
	var Notification_1 = require_Notification();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function dematerialize() {
		return lift_1.operate(function(source, subscriber) {
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(notification) {
				return Notification_1.observeNotification(notification, subscriber);
			}));
		});
	}
	exports.dematerialize = dematerialize;
}));
// node_modules/rxjs/dist/cjs/internal/operators/distinct.js
var require_distinct = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.distinct = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var noop_1 = require_noop();
	var innerFrom_1 = require_innerFrom();
	function distinct(keySelector, flushes) {
		return lift_1.operate(function(source, subscriber) {
			var distinctKeys = /* @__PURE__ */ new Set();
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var key = keySelector ? keySelector(value) : value;
				if (!distinctKeys.has(key)) {
					distinctKeys.add(key);
					subscriber.next(value);
				}
			}));
			flushes && innerFrom_1.innerFrom(flushes).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
				return distinctKeys.clear();
			}, noop_1.noop));
		});
	}
	exports.distinct = distinct;
}));
// node_modules/rxjs/dist/cjs/internal/operators/distinctUntilChanged.js
var require_distinctUntilChanged = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.distinctUntilChanged = void 0;
	var identity_1 = require_identity();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function distinctUntilChanged(comparator, keySelector) {
		if (keySelector === void 0) keySelector = identity_1.identity;
		comparator = comparator !== null && comparator !== void 0 ? comparator : defaultCompare;
		return lift_1.operate(function(source, subscriber) {
			var previousKey;
			var first = true;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var currentKey = keySelector(value);
				if (first || !comparator(previousKey, currentKey)) {
					first = false;
					previousKey = currentKey;
					subscriber.next(value);
				}
			}));
		});
	}
	exports.distinctUntilChanged = distinctUntilChanged;
	function defaultCompare(a, b) {
		return a === b;
	}
}));
// node_modules/rxjs/dist/cjs/internal/operators/distinctUntilKeyChanged.js
var require_distinctUntilKeyChanged = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.distinctUntilKeyChanged = void 0;
	var distinctUntilChanged_1 = require_distinctUntilChanged();
	function distinctUntilKeyChanged(key, compare) {
		return distinctUntilChanged_1.distinctUntilChanged(function(x, y) {
			return compare ? compare(x[key], y[key]) : x[key] === y[key];
		});
	}
	exports.distinctUntilKeyChanged = distinctUntilKeyChanged;
}));
// node_modules/rxjs/dist/cjs/internal/operators/throwIfEmpty.js
var require_throwIfEmpty = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.throwIfEmpty = void 0;
	var EmptyError_1 = require_EmptyError();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function throwIfEmpty(errorFactory) {
		if (errorFactory === void 0) errorFactory = defaultErrorFactory;
		return lift_1.operate(function(source, subscriber) {
			var hasValue = false;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				hasValue = true;
				subscriber.next(value);
			}, function() {
				return hasValue ? subscriber.complete() : subscriber.error(errorFactory());
			}));
		});
	}
	exports.throwIfEmpty = throwIfEmpty;
	function defaultErrorFactory() {
		return new EmptyError_1.EmptyError();
	}
}));
// node_modules/rxjs/dist/cjs/internal/operators/elementAt.js
var require_elementAt = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.elementAt = void 0;
	var ArgumentOutOfRangeError_1 = require_ArgumentOutOfRangeError();
	var filter_1 = require_filter();
	var throwIfEmpty_1 = require_throwIfEmpty();
	var defaultIfEmpty_1 = require_defaultIfEmpty();
	var take_1 = require_take();
	function elementAt(index, defaultValue) {
		if (index < 0) throw new ArgumentOutOfRangeError_1.ArgumentOutOfRangeError();
		var hasDefaultValue = arguments.length >= 2;
		return function(source) {
			return source.pipe(filter_1.filter(function(v, i) {
				return i === index;
			}), take_1.take(1), hasDefaultValue ? defaultIfEmpty_1.defaultIfEmpty(defaultValue) : throwIfEmpty_1.throwIfEmpty(function() {
				return new ArgumentOutOfRangeError_1.ArgumentOutOfRangeError();
			}));
		};
	}
	exports.elementAt = elementAt;
}));
// node_modules/rxjs/dist/cjs/internal/operators/endWith.js
var require_endWith = /* @__PURE__ */ __commonJSMin(((exports, module, this$14) => {
	var __read = this$14 && this$14.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$14 && this$14.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.endWith = void 0;
	var concat_1 = require_concat$1();
	var of_1 = require_of();
	function endWith() {
		var values = [];
		for (var _i = 0; _i < arguments.length; _i++) values[_i] = arguments[_i];
		return function(source) {
			return concat_1.concat(source, of_1.of.apply(void 0, __spreadArray([], __read(values))));
		};
	}
	exports.endWith = endWith;
}));
// node_modules/rxjs/dist/cjs/internal/operators/every.js
var require_every = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.every = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function every(predicate, thisArg) {
		return lift_1.operate(function(source, subscriber) {
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				if (!predicate.call(thisArg, value, index++, source)) {
					subscriber.next(false);
					subscriber.complete();
				}
			}, function() {
				subscriber.next(true);
				subscriber.complete();
			}));
		});
	}
	exports.every = every;
}));
// node_modules/rxjs/dist/cjs/internal/operators/exhaustMap.js
var require_exhaustMap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.exhaustMap = void 0;
	var map_1 = require_map();
	var innerFrom_1 = require_innerFrom();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function exhaustMap(project, resultSelector) {
		if (resultSelector) return function(source) {
			return source.pipe(exhaustMap(function(a, i) {
				return innerFrom_1.innerFrom(project(a, i)).pipe(map_1.map(function(b, ii) {
					return resultSelector(a, b, i, ii);
				}));
			}));
		};
		return lift_1.operate(function(source, subscriber) {
			var index = 0;
			var innerSub = null;
			var isComplete = false;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(outerValue) {
				if (!innerSub) {
					innerSub = OperatorSubscriber_1.createOperatorSubscriber(subscriber, void 0, function() {
						innerSub = null;
						isComplete && subscriber.complete();
					});
					innerFrom_1.innerFrom(project(outerValue, index++)).subscribe(innerSub);
				}
			}, function() {
				isComplete = true;
				!innerSub && subscriber.complete();
			}));
		});
	}
	exports.exhaustMap = exhaustMap;
}));
// node_modules/rxjs/dist/cjs/internal/operators/exhaustAll.js
var require_exhaustAll = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.exhaustAll = void 0;
	var exhaustMap_1 = require_exhaustMap();
	var identity_1 = require_identity();
	function exhaustAll() {
		return exhaustMap_1.exhaustMap(identity_1.identity);
	}
	exports.exhaustAll = exhaustAll;
}));
// node_modules/rxjs/dist/cjs/internal/operators/exhaust.js
var require_exhaust = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.exhaust = void 0;
	exports.exhaust = require_exhaustAll().exhaustAll;
}));
// node_modules/rxjs/dist/cjs/internal/operators/expand.js
var require_expand = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.expand = void 0;
	var lift_1 = require_lift();
	var mergeInternals_1 = require_mergeInternals();
	function expand(project, concurrent, scheduler) {
		if (concurrent === void 0) concurrent = Infinity;
		concurrent = (concurrent || 0) < 1 ? Infinity : concurrent;
		return lift_1.operate(function(source, subscriber) {
			return mergeInternals_1.mergeInternals(source, subscriber, project, concurrent, void 0, true, scheduler);
		});
	}
	exports.expand = expand;
}));
// node_modules/rxjs/dist/cjs/internal/operators/finalize.js
var require_finalize = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.finalize = void 0;
	var lift_1 = require_lift();
	function finalize(callback) {
		return lift_1.operate(function(source, subscriber) {
			try {
				source.subscribe(subscriber);
			} finally {
				subscriber.add(callback);
			}
		});
	}
	exports.finalize = finalize;
}));
// node_modules/rxjs/dist/cjs/internal/operators/find.js
var require_find = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createFind = exports.find = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function find(predicate, thisArg) {
		return lift_1.operate(createFind(predicate, thisArg, "value"));
	}
	exports.find = find;
	function createFind(predicate, thisArg, emit) {
		var findIndex = emit === "index";
		return function(source, subscriber) {
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var i = index++;
				if (predicate.call(thisArg, value, i, source)) {
					subscriber.next(findIndex ? i : value);
					subscriber.complete();
				}
			}, function() {
				subscriber.next(findIndex ? -1 : void 0);
				subscriber.complete();
			}));
		};
	}
	exports.createFind = createFind;
}));
// node_modules/rxjs/dist/cjs/internal/operators/findIndex.js
var require_findIndex = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.findIndex = void 0;
	var lift_1 = require_lift();
	var find_1 = require_find();
	function findIndex(predicate, thisArg) {
		return lift_1.operate(find_1.createFind(predicate, thisArg, "index"));
	}
	exports.findIndex = findIndex;
}));
// node_modules/rxjs/dist/cjs/internal/operators/first.js
var require_first = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.first = void 0;
	var EmptyError_1 = require_EmptyError();
	var filter_1 = require_filter();
	var take_1 = require_take();
	var defaultIfEmpty_1 = require_defaultIfEmpty();
	var throwIfEmpty_1 = require_throwIfEmpty();
	var identity_1 = require_identity();
	function first(predicate, defaultValue) {
		var hasDefaultValue = arguments.length >= 2;
		return function(source) {
			return source.pipe(predicate ? filter_1.filter(function(v, i) {
				return predicate(v, i, source);
			}) : identity_1.identity, take_1.take(1), hasDefaultValue ? defaultIfEmpty_1.defaultIfEmpty(defaultValue) : throwIfEmpty_1.throwIfEmpty(function() {
				return new EmptyError_1.EmptyError();
			}));
		};
	}
	exports.first = first;
}));
// node_modules/rxjs/dist/cjs/internal/operators/groupBy.js
var require_groupBy = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.groupBy = void 0;
	var Observable_1 = require_Observable();
	var innerFrom_1 = require_innerFrom();
	var Subject_1 = require_Subject();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function groupBy(keySelector, elementOrOptions, duration, connector) {
		return lift_1.operate(function(source, subscriber) {
			var element;
			if (!elementOrOptions || typeof elementOrOptions === "function") element = elementOrOptions;
			else duration = elementOrOptions.duration, element = elementOrOptions.element, connector = elementOrOptions.connector;
			var groups = /* @__PURE__ */ new Map();
			var notify = function(cb) {
				groups.forEach(cb);
				cb(subscriber);
			};
			var handleError = function(err) {
				return notify(function(consumer) {
					return consumer.error(err);
				});
			};
			var activeGroups = 0;
			var teardownAttempted = false;
			var groupBySourceSubscriber = new OperatorSubscriber_1.OperatorSubscriber(subscriber, function(value) {
				try {
					var key_1 = keySelector(value);
					var group_1 = groups.get(key_1);
					if (!group_1) {
						groups.set(key_1, group_1 = connector ? connector() : new Subject_1.Subject());
						var grouped = createGroupedObservable(key_1, group_1);
						subscriber.next(grouped);
						if (duration) {
							var durationSubscriber_1 = OperatorSubscriber_1.createOperatorSubscriber(group_1, function() {
								group_1.complete();
								durationSubscriber_1 === null || durationSubscriber_1 === void 0 || durationSubscriber_1.unsubscribe();
							}, void 0, void 0, function() {
								return groups.delete(key_1);
							});
							groupBySourceSubscriber.add(innerFrom_1.innerFrom(duration(grouped)).subscribe(durationSubscriber_1));
						}
					}
					group_1.next(element ? element(value) : value);
				} catch (err) {
					handleError(err);
				}
			}, function() {
				return notify(function(consumer) {
					return consumer.complete();
				});
			}, handleError, function() {
				return groups.clear();
			}, function() {
				teardownAttempted = true;
				return activeGroups === 0;
			});
			source.subscribe(groupBySourceSubscriber);
			function createGroupedObservable(key, groupSubject) {
				var result = new Observable_1.Observable(function(groupSubscriber) {
					activeGroups++;
					var innerSub = groupSubject.subscribe(groupSubscriber);
					return function() {
						innerSub.unsubscribe();
						--activeGroups === 0 && teardownAttempted && groupBySourceSubscriber.unsubscribe();
					};
				});
				result.key = key;
				return result;
			}
		});
	}
	exports.groupBy = groupBy;
}));
// node_modules/rxjs/dist/cjs/internal/operators/isEmpty.js
var require_isEmpty = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isEmpty = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function isEmpty() {
		return lift_1.operate(function(source, subscriber) {
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
				subscriber.next(false);
				subscriber.complete();
			}, function() {
				subscriber.next(true);
				subscriber.complete();
			}));
		});
	}
	exports.isEmpty = isEmpty;
}));
// node_modules/rxjs/dist/cjs/internal/operators/takeLast.js
var require_takeLast = /* @__PURE__ */ __commonJSMin(((exports, module, this$13) => {
	var __values = this$13 && this$13.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.takeLast = void 0;
	var empty_1 = require_empty();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function takeLast(count) {
		return count <= 0 ? function() {
			return empty_1.EMPTY;
		} : lift_1.operate(function(source, subscriber) {
			var buffer = [];
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				buffer.push(value);
				count < buffer.length && buffer.shift();
			}, function() {
				var e_1, _a;
				try {
					for (var buffer_1 = __values(buffer), buffer_1_1 = buffer_1.next(); !buffer_1_1.done; buffer_1_1 = buffer_1.next()) {
						var value = buffer_1_1.value;
						subscriber.next(value);
					}
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (buffer_1_1 && !buffer_1_1.done && (_a = buffer_1.return)) _a.call(buffer_1);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
				subscriber.complete();
			}, void 0, function() {
				buffer = null;
			}));
		});
	}
	exports.takeLast = takeLast;
}));
// node_modules/rxjs/dist/cjs/internal/operators/last.js
var require_last = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.last = void 0;
	var EmptyError_1 = require_EmptyError();
	var filter_1 = require_filter();
	var takeLast_1 = require_takeLast();
	var throwIfEmpty_1 = require_throwIfEmpty();
	var defaultIfEmpty_1 = require_defaultIfEmpty();
	var identity_1 = require_identity();
	function last(predicate, defaultValue) {
		var hasDefaultValue = arguments.length >= 2;
		return function(source) {
			return source.pipe(predicate ? filter_1.filter(function(v, i) {
				return predicate(v, i, source);
			}) : identity_1.identity, takeLast_1.takeLast(1), hasDefaultValue ? defaultIfEmpty_1.defaultIfEmpty(defaultValue) : throwIfEmpty_1.throwIfEmpty(function() {
				return new EmptyError_1.EmptyError();
			}));
		};
	}
	exports.last = last;
}));
// node_modules/rxjs/dist/cjs/internal/operators/materialize.js
var require_materialize = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.materialize = void 0;
	var Notification_1 = require_Notification();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function materialize() {
		return lift_1.operate(function(source, subscriber) {
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				subscriber.next(Notification_1.Notification.createNext(value));
			}, function() {
				subscriber.next(Notification_1.Notification.createComplete());
				subscriber.complete();
			}, function(err) {
				subscriber.next(Notification_1.Notification.createError(err));
				subscriber.complete();
			}));
		});
	}
	exports.materialize = materialize;
}));
// node_modules/rxjs/dist/cjs/internal/operators/max.js
var require_max = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.max = void 0;
	var reduce_1 = require_reduce();
	var isFunction_1 = require_isFunction();
	function max(comparer) {
		return reduce_1.reduce(isFunction_1.isFunction(comparer) ? function(x, y) {
			return comparer(x, y) > 0 ? x : y;
		} : function(x, y) {
			return x > y ? x : y;
		});
	}
	exports.max = max;
}));
// node_modules/rxjs/dist/cjs/internal/operators/flatMap.js
var require_flatMap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.flatMap = void 0;
	exports.flatMap = require_mergeMap().mergeMap;
}));
// node_modules/rxjs/dist/cjs/internal/operators/mergeMapTo.js
var require_mergeMapTo = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeMapTo = void 0;
	var mergeMap_1 = require_mergeMap();
	var isFunction_1 = require_isFunction();
	function mergeMapTo(innerObservable, resultSelector, concurrent) {
		if (concurrent === void 0) concurrent = Infinity;
		if (isFunction_1.isFunction(resultSelector)) return mergeMap_1.mergeMap(function() {
			return innerObservable;
		}, resultSelector, concurrent);
		if (typeof resultSelector === "number") concurrent = resultSelector;
		return mergeMap_1.mergeMap(function() {
			return innerObservable;
		}, concurrent);
	}
	exports.mergeMapTo = mergeMapTo;
}));
// node_modules/rxjs/dist/cjs/internal/operators/mergeScan.js
var require_mergeScan = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeScan = void 0;
	var lift_1 = require_lift();
	var mergeInternals_1 = require_mergeInternals();
	function mergeScan(accumulator, seed, concurrent) {
		if (concurrent === void 0) concurrent = Infinity;
		return lift_1.operate(function(source, subscriber) {
			var state = seed;
			return mergeInternals_1.mergeInternals(source, subscriber, function(value, index) {
				return accumulator(state, value, index);
			}, concurrent, function(value) {
				state = value;
			}, false, void 0, function() {
				return state = null;
			});
		});
	}
	exports.mergeScan = mergeScan;
}));
// node_modules/rxjs/dist/cjs/internal/operators/merge.js
var require_merge = /* @__PURE__ */ __commonJSMin(((exports, module, this$12) => {
	var __read = this$12 && this$12.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$12 && this$12.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.merge = void 0;
	var lift_1 = require_lift();
	var mergeAll_1 = require_mergeAll();
	var args_1 = require_args();
	var from_1 = require_from();
	function merge() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var scheduler = args_1.popScheduler(args);
		var concurrent = args_1.popNumber(args, Infinity);
		return lift_1.operate(function(source, subscriber) {
			mergeAll_1.mergeAll(concurrent)(from_1.from(__spreadArray([source], __read(args)), scheduler)).subscribe(subscriber);
		});
	}
	exports.merge = merge;
}));
// node_modules/rxjs/dist/cjs/internal/operators/mergeWith.js
var require_mergeWith = /* @__PURE__ */ __commonJSMin(((exports, module, this$11) => {
	var __read = this$11 && this$11.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$11 && this$11.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeWith = void 0;
	var merge_1 = require_merge();
	function mergeWith() {
		var otherSources = [];
		for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
		return merge_1.merge.apply(void 0, __spreadArray([], __read(otherSources)));
	}
	exports.mergeWith = mergeWith;
}));
// node_modules/rxjs/dist/cjs/internal/operators/min.js
var require_min = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.min = void 0;
	var reduce_1 = require_reduce();
	var isFunction_1 = require_isFunction();
	function min(comparer) {
		return reduce_1.reduce(isFunction_1.isFunction(comparer) ? function(x, y) {
			return comparer(x, y) < 0 ? x : y;
		} : function(x, y) {
			return x < y ? x : y;
		});
	}
	exports.min = min;
}));
// node_modules/rxjs/dist/cjs/internal/operators/multicast.js
var require_multicast = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.multicast = void 0;
	var ConnectableObservable_1 = require_ConnectableObservable();
	var isFunction_1 = require_isFunction();
	var connect_1 = require_connect();
	function multicast(subjectOrSubjectFactory, selector) {
		var subjectFactory = isFunction_1.isFunction(subjectOrSubjectFactory) ? subjectOrSubjectFactory : function() {
			return subjectOrSubjectFactory;
		};
		if (isFunction_1.isFunction(selector)) return connect_1.connect(selector, { connector: subjectFactory });
		return function(source) {
			return new ConnectableObservable_1.ConnectableObservable(source, subjectFactory);
		};
	}
	exports.multicast = multicast;
}));
// node_modules/rxjs/dist/cjs/internal/operators/onErrorResumeNextWith.js
var require_onErrorResumeNextWith = /* @__PURE__ */ __commonJSMin(((exports, module, this$10) => {
	var __read = this$10 && this$10.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$10 && this$10.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.onErrorResumeNext = exports.onErrorResumeNextWith = void 0;
	var argsOrArgArray_1 = require_argsOrArgArray();
	var onErrorResumeNext_1 = require_onErrorResumeNext();
	function onErrorResumeNextWith() {
		var sources = [];
		for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
		var nextSources = argsOrArgArray_1.argsOrArgArray(sources);
		return function(source) {
			return onErrorResumeNext_1.onErrorResumeNext.apply(void 0, __spreadArray([source], __read(nextSources)));
		};
	}
	exports.onErrorResumeNextWith = onErrorResumeNextWith;
	exports.onErrorResumeNext = onErrorResumeNextWith;
}));
// node_modules/rxjs/dist/cjs/internal/operators/pairwise.js
var require_pairwise = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.pairwise = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function pairwise() {
		return lift_1.operate(function(source, subscriber) {
			var prev;
			var hasPrev = false;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var p = prev;
				prev = value;
				hasPrev && subscriber.next([p, value]);
				hasPrev = true;
			}));
		});
	}
	exports.pairwise = pairwise;
}));
// node_modules/rxjs/dist/cjs/internal/operators/pluck.js
var require_pluck = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.pluck = void 0;
	var map_1 = require_map();
	function pluck() {
		var properties = [];
		for (var _i = 0; _i < arguments.length; _i++) properties[_i] = arguments[_i];
		var length = properties.length;
		if (length === 0) throw new Error("list of properties cannot be empty.");
		return map_1.map(function(x) {
			var currentProp = x;
			for (var i = 0; i < length; i++) {
				var p = currentProp === null || currentProp === void 0 ? void 0 : currentProp[properties[i]];
				if (typeof p !== "undefined") currentProp = p;
				else return;
			}
			return currentProp;
		});
	}
	exports.pluck = pluck;
}));
// node_modules/rxjs/dist/cjs/internal/operators/publish.js
var require_publish = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.publish = void 0;
	var Subject_1 = require_Subject();
	var multicast_1 = require_multicast();
	var connect_1 = require_connect();
	function publish(selector) {
		return selector ? function(source) {
			return connect_1.connect(selector)(source);
		} : function(source) {
			return multicast_1.multicast(new Subject_1.Subject())(source);
		};
	}
	exports.publish = publish;
}));
// node_modules/rxjs/dist/cjs/internal/operators/publishBehavior.js
var require_publishBehavior = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.publishBehavior = void 0;
	var BehaviorSubject_1 = require_BehaviorSubject();
	var ConnectableObservable_1 = require_ConnectableObservable();
	function publishBehavior(initialValue) {
		return function(source) {
			var subject = new BehaviorSubject_1.BehaviorSubject(initialValue);
			return new ConnectableObservable_1.ConnectableObservable(source, function() {
				return subject;
			});
		};
	}
	exports.publishBehavior = publishBehavior;
}));
// node_modules/rxjs/dist/cjs/internal/operators/publishLast.js
var require_publishLast = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.publishLast = void 0;
	var AsyncSubject_1 = require_AsyncSubject();
	var ConnectableObservable_1 = require_ConnectableObservable();
	function publishLast() {
		return function(source) {
			var subject = new AsyncSubject_1.AsyncSubject();
			return new ConnectableObservable_1.ConnectableObservable(source, function() {
				return subject;
			});
		};
	}
	exports.publishLast = publishLast;
}));
// node_modules/rxjs/dist/cjs/internal/operators/publishReplay.js
var require_publishReplay = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.publishReplay = void 0;
	var ReplaySubject_1 = require_ReplaySubject();
	var multicast_1 = require_multicast();
	var isFunction_1 = require_isFunction();
	function publishReplay(bufferSize, windowTime, selectorOrScheduler, timestampProvider) {
		if (selectorOrScheduler && !isFunction_1.isFunction(selectorOrScheduler)) timestampProvider = selectorOrScheduler;
		var selector = isFunction_1.isFunction(selectorOrScheduler) ? selectorOrScheduler : void 0;
		return function(source) {
			return multicast_1.multicast(new ReplaySubject_1.ReplaySubject(bufferSize, windowTime, timestampProvider), selector)(source);
		};
	}
	exports.publishReplay = publishReplay;
}));
// node_modules/rxjs/dist/cjs/internal/operators/raceWith.js
var require_raceWith = /* @__PURE__ */ __commonJSMin(((exports, module, this$9) => {
	var __read = this$9 && this$9.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$9 && this$9.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.raceWith = void 0;
	var race_1 = require_race$1();
	var lift_1 = require_lift();
	var identity_1 = require_identity();
	function raceWith() {
		var otherSources = [];
		for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
		return !otherSources.length ? identity_1.identity : lift_1.operate(function(source, subscriber) {
			race_1.raceInit(__spreadArray([source], __read(otherSources)))(subscriber);
		});
	}
	exports.raceWith = raceWith;
}));
// node_modules/rxjs/dist/cjs/internal/operators/repeat.js
var require_repeat = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.repeat = void 0;
	var empty_1 = require_empty();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	var timer_1 = require_timer();
	function repeat(countOrConfig) {
		var _a;
		var count = Infinity;
		var delay;
		if (countOrConfig != null) {
			if (typeof countOrConfig === "object") _a = countOrConfig.count, count = _a === void 0 ? Infinity : _a, delay = countOrConfig.delay;
			else count = countOrConfig;
		}
		return count <= 0 ? function() {
			return empty_1.EMPTY;
		} : lift_1.operate(function(source, subscriber) {
			var soFar = 0;
			var sourceSub;
			var resubscribe = function() {
				sourceSub === null || sourceSub === void 0 || sourceSub.unsubscribe();
				sourceSub = null;
				if (delay != null) {
					var notifier = typeof delay === "number" ? timer_1.timer(delay) : innerFrom_1.innerFrom(delay(soFar));
					var notifierSubscriber_1 = OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
						notifierSubscriber_1.unsubscribe();
						subscribeToSource();
					});
					notifier.subscribe(notifierSubscriber_1);
				} else subscribeToSource();
			};
			var subscribeToSource = function() {
				var syncUnsub = false;
				sourceSub = source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, void 0, function() {
					if (++soFar < count) {
						if (sourceSub) resubscribe();
						else syncUnsub = true;
					} else subscriber.complete();
				}));
				if (syncUnsub) resubscribe();
			};
			subscribeToSource();
		});
	}
	exports.repeat = repeat;
}));
// node_modules/rxjs/dist/cjs/internal/operators/repeatWhen.js
var require_repeatWhen = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.repeatWhen = void 0;
	var innerFrom_1 = require_innerFrom();
	var Subject_1 = require_Subject();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function repeatWhen(notifier) {
		return lift_1.operate(function(source, subscriber) {
			var innerSub;
			var syncResub = false;
			var completions$;
			var isNotifierComplete = false;
			var isMainComplete = false;
			var checkComplete = function() {
				return isMainComplete && isNotifierComplete && (subscriber.complete(), true);
			};
			var getCompletionSubject = function() {
				if (!completions$) {
					completions$ = new Subject_1.Subject();
					innerFrom_1.innerFrom(notifier(completions$)).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
						if (innerSub) subscribeForRepeatWhen();
						else syncResub = true;
					}, function() {
						isNotifierComplete = true;
						checkComplete();
					}));
				}
				return completions$;
			};
			var subscribeForRepeatWhen = function() {
				isMainComplete = false;
				innerSub = source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, void 0, function() {
					isMainComplete = true;
					!checkComplete() && getCompletionSubject().next();
				}));
				if (syncResub) {
					innerSub.unsubscribe();
					innerSub = null;
					syncResub = false;
					subscribeForRepeatWhen();
				}
			};
			subscribeForRepeatWhen();
		});
	}
	exports.repeatWhen = repeatWhen;
}));
// node_modules/rxjs/dist/cjs/internal/operators/retry.js
var require_retry = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.retry = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var identity_1 = require_identity();
	var timer_1 = require_timer();
	var innerFrom_1 = require_innerFrom();
	function retry(configOrCount) {
		if (configOrCount === void 0) configOrCount = Infinity;
		var config;
		if (configOrCount && typeof configOrCount === "object") config = configOrCount;
		else config = { count: configOrCount };
		var _a = config.count, count = _a === void 0 ? Infinity : _a, delay = config.delay, _b = config.resetOnSuccess, resetOnSuccess = _b === void 0 ? false : _b;
		return count <= 0 ? identity_1.identity : lift_1.operate(function(source, subscriber) {
			var soFar = 0;
			var innerSub;
			var subscribeForRetry = function() {
				var syncUnsub = false;
				innerSub = source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
					if (resetOnSuccess) soFar = 0;
					subscriber.next(value);
				}, void 0, function(err) {
					if (soFar++ < count) {
						var resub_1 = function() {
							if (innerSub) {
								innerSub.unsubscribe();
								innerSub = null;
								subscribeForRetry();
							} else syncUnsub = true;
						};
						if (delay != null) {
							var notifier = typeof delay === "number" ? timer_1.timer(delay) : innerFrom_1.innerFrom(delay(err, soFar));
							var notifierSubscriber_1 = OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
								notifierSubscriber_1.unsubscribe();
								resub_1();
							}, function() {
								subscriber.complete();
							});
							notifier.subscribe(notifierSubscriber_1);
						} else resub_1();
					} else subscriber.error(err);
				}));
				if (syncUnsub) {
					innerSub.unsubscribe();
					innerSub = null;
					subscribeForRetry();
				}
			};
			subscribeForRetry();
		});
	}
	exports.retry = retry;
}));
// node_modules/rxjs/dist/cjs/internal/operators/retryWhen.js
var require_retryWhen = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.retryWhen = void 0;
	var innerFrom_1 = require_innerFrom();
	var Subject_1 = require_Subject();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function retryWhen(notifier) {
		return lift_1.operate(function(source, subscriber) {
			var innerSub;
			var syncResub = false;
			var errors$;
			var subscribeForRetryWhen = function() {
				innerSub = source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, void 0, void 0, function(err) {
					if (!errors$) {
						errors$ = new Subject_1.Subject();
						innerFrom_1.innerFrom(notifier(errors$)).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
							return innerSub ? subscribeForRetryWhen() : syncResub = true;
						}));
					}
					if (errors$) errors$.next(err);
				}));
				if (syncResub) {
					innerSub.unsubscribe();
					innerSub = null;
					syncResub = false;
					subscribeForRetryWhen();
				}
			};
			subscribeForRetryWhen();
		});
	}
	exports.retryWhen = retryWhen;
}));
// node_modules/rxjs/dist/cjs/internal/operators/sample.js
var require_sample = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.sample = void 0;
	var innerFrom_1 = require_innerFrom();
	var lift_1 = require_lift();
	var noop_1 = require_noop();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function sample(notifier) {
		return lift_1.operate(function(source, subscriber) {
			var hasValue = false;
			var lastValue = null;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				hasValue = true;
				lastValue = value;
			}));
			innerFrom_1.innerFrom(notifier).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
				if (hasValue) {
					hasValue = false;
					var value = lastValue;
					lastValue = null;
					subscriber.next(value);
				}
			}, noop_1.noop));
		});
	}
	exports.sample = sample;
}));
// node_modules/rxjs/dist/cjs/internal/operators/sampleTime.js
var require_sampleTime = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.sampleTime = void 0;
	var async_1 = require_async();
	var sample_1 = require_sample();
	var interval_1 = require_interval();
	function sampleTime(period, scheduler) {
		if (scheduler === void 0) scheduler = async_1.asyncScheduler;
		return sample_1.sample(interval_1.interval(period, scheduler));
	}
	exports.sampleTime = sampleTime;
}));
// node_modules/rxjs/dist/cjs/internal/operators/scan.js
var require_scan = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.scan = void 0;
	var lift_1 = require_lift();
	var scanInternals_1 = require_scanInternals();
	function scan(accumulator, seed) {
		return lift_1.operate(scanInternals_1.scanInternals(accumulator, seed, arguments.length >= 2, true));
	}
	exports.scan = scan;
}));
// node_modules/rxjs/dist/cjs/internal/operators/sequenceEqual.js
var require_sequenceEqual = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.sequenceEqual = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	function sequenceEqual(compareTo, comparator) {
		if (comparator === void 0) comparator = function(a, b) {
			return a === b;
		};
		return lift_1.operate(function(source, subscriber) {
			var aState = createState();
			var bState = createState();
			var emit = function(isEqual) {
				subscriber.next(isEqual);
				subscriber.complete();
			};
			var createSubscriber = function(selfState, otherState) {
				var sequenceEqualSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(a) {
					var buffer = otherState.buffer, complete = otherState.complete;
					if (buffer.length === 0) complete ? emit(false) : selfState.buffer.push(a);
					else !comparator(a, buffer.shift()) && emit(false);
				}, function() {
					selfState.complete = true;
					var complete = otherState.complete, buffer = otherState.buffer;
					complete && emit(buffer.length === 0);
					sequenceEqualSubscriber === null || sequenceEqualSubscriber === void 0 || sequenceEqualSubscriber.unsubscribe();
				});
				return sequenceEqualSubscriber;
			};
			source.subscribe(createSubscriber(aState, bState));
			innerFrom_1.innerFrom(compareTo).subscribe(createSubscriber(bState, aState));
		});
	}
	exports.sequenceEqual = sequenceEqual;
	function createState() {
		return {
			buffer: [],
			complete: false
		};
	}
}));
// node_modules/rxjs/dist/cjs/internal/operators/share.js
var require_share = /* @__PURE__ */ __commonJSMin(((exports, module, this$8) => {
	var __read = this$8 && this$8.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$8 && this$8.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.share = void 0;
	var innerFrom_1 = require_innerFrom();
	var Subject_1 = require_Subject();
	var Subscriber_1 = require_Subscriber();
	var lift_1 = require_lift();
	function share(options) {
		if (options === void 0) options = {};
		var _a = options.connector, connector = _a === void 0 ? function() {
			return new Subject_1.Subject();
		} : _a, _b = options.resetOnError, resetOnError = _b === void 0 ? true : _b, _c = options.resetOnComplete, resetOnComplete = _c === void 0 ? true : _c, _d = options.resetOnRefCountZero, resetOnRefCountZero = _d === void 0 ? true : _d;
		return function(wrapperSource) {
			var connection;
			var resetConnection;
			var subject;
			var refCount = 0;
			var hasCompleted = false;
			var hasErrored = false;
			var cancelReset = function() {
				resetConnection === null || resetConnection === void 0 || resetConnection.unsubscribe();
				resetConnection = void 0;
			};
			var reset = function() {
				cancelReset();
				connection = subject = void 0;
				hasCompleted = hasErrored = false;
			};
			var resetAndUnsubscribe = function() {
				var conn = connection;
				reset();
				conn === null || conn === void 0 || conn.unsubscribe();
			};
			return lift_1.operate(function(source, subscriber) {
				refCount++;
				if (!hasErrored && !hasCompleted) cancelReset();
				var dest = subject = subject !== null && subject !== void 0 ? subject : connector();
				subscriber.add(function() {
					refCount--;
					if (refCount === 0 && !hasErrored && !hasCompleted) resetConnection = handleReset(resetAndUnsubscribe, resetOnRefCountZero);
				});
				dest.subscribe(subscriber);
				if (!connection && refCount > 0) {
					connection = new Subscriber_1.SafeSubscriber({
						next: function(value) {
							return dest.next(value);
						},
						error: function(err) {
							hasErrored = true;
							cancelReset();
							resetConnection = handleReset(reset, resetOnError, err);
							dest.error(err);
						},
						complete: function() {
							hasCompleted = true;
							cancelReset();
							resetConnection = handleReset(reset, resetOnComplete);
							dest.complete();
						}
					});
					innerFrom_1.innerFrom(source).subscribe(connection);
				}
			})(wrapperSource);
		};
	}
	exports.share = share;
	function handleReset(reset, on) {
		var args = [];
		for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
		if (on === true) {
			reset();
			return;
		}
		if (on === false) return;
		var onSubscriber = new Subscriber_1.SafeSubscriber({ next: function() {
			onSubscriber.unsubscribe();
			reset();
		} });
		return innerFrom_1.innerFrom(on.apply(void 0, __spreadArray([], __read(args)))).subscribe(onSubscriber);
	}
}));
// node_modules/rxjs/dist/cjs/internal/operators/shareReplay.js
var require_shareReplay = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.shareReplay = void 0;
	var ReplaySubject_1 = require_ReplaySubject();
	var share_1 = require_share();
	function shareReplay(configOrBufferSize, windowTime, scheduler) {
		var _a, _b, _c;
		var bufferSize;
		var refCount = false;
		if (configOrBufferSize && typeof configOrBufferSize === "object") _a = configOrBufferSize.bufferSize, bufferSize = _a === void 0 ? Infinity : _a, _b = configOrBufferSize.windowTime, windowTime = _b === void 0 ? Infinity : _b, _c = configOrBufferSize.refCount, refCount = _c === void 0 ? false : _c, scheduler = configOrBufferSize.scheduler;
		else bufferSize = configOrBufferSize !== null && configOrBufferSize !== void 0 ? configOrBufferSize : Infinity;
		return share_1.share({
			connector: function() {
				return new ReplaySubject_1.ReplaySubject(bufferSize, windowTime, scheduler);
			},
			resetOnError: true,
			resetOnComplete: false,
			resetOnRefCountZero: refCount
		});
	}
	exports.shareReplay = shareReplay;
}));
// node_modules/rxjs/dist/cjs/internal/operators/single.js
var require_single = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.single = void 0;
	var EmptyError_1 = require_EmptyError();
	var SequenceError_1 = require_SequenceError();
	var NotFoundError_1 = require_NotFoundError();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function single(predicate) {
		return lift_1.operate(function(source, subscriber) {
			var hasValue = false;
			var singleValue;
			var seenValue = false;
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				seenValue = true;
				if (!predicate || predicate(value, index++, source)) {
					hasValue && subscriber.error(new SequenceError_1.SequenceError("Too many matching values"));
					hasValue = true;
					singleValue = value;
				}
			}, function() {
				if (hasValue) {
					subscriber.next(singleValue);
					subscriber.complete();
				} else subscriber.error(seenValue ? new NotFoundError_1.NotFoundError("No matching values") : new EmptyError_1.EmptyError());
			}));
		});
	}
	exports.single = single;
}));
// node_modules/rxjs/dist/cjs/internal/operators/skip.js
var require_skip = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.skip = void 0;
	var filter_1 = require_filter();
	function skip(count) {
		return filter_1.filter(function(_, index) {
			return count <= index;
		});
	}
	exports.skip = skip;
}));
// node_modules/rxjs/dist/cjs/internal/operators/skipLast.js
var require_skipLast = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.skipLast = void 0;
	var identity_1 = require_identity();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function skipLast(skipCount) {
		return skipCount <= 0 ? identity_1.identity : lift_1.operate(function(source, subscriber) {
			var ring = new Array(skipCount);
			var seen = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var valueIndex = seen++;
				if (valueIndex < skipCount) ring[valueIndex] = value;
				else {
					var index = valueIndex % skipCount;
					var oldValue = ring[index];
					ring[index] = value;
					subscriber.next(oldValue);
				}
			}));
			return function() {
				ring = null;
			};
		});
	}
	exports.skipLast = skipLast;
}));
// node_modules/rxjs/dist/cjs/internal/operators/skipUntil.js
var require_skipUntil = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.skipUntil = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	var noop_1 = require_noop();
	function skipUntil(notifier) {
		return lift_1.operate(function(source, subscriber) {
			var taking = false;
			var skipSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
				skipSubscriber === null || skipSubscriber === void 0 || skipSubscriber.unsubscribe();
				taking = true;
			}, noop_1.noop);
			innerFrom_1.innerFrom(notifier).subscribe(skipSubscriber);
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return taking && subscriber.next(value);
			}));
		});
	}
	exports.skipUntil = skipUntil;
}));
// node_modules/rxjs/dist/cjs/internal/operators/skipWhile.js
var require_skipWhile = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.skipWhile = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function skipWhile(predicate) {
		return lift_1.operate(function(source, subscriber) {
			var taking = false;
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return (taking || (taking = !predicate(value, index++))) && subscriber.next(value);
			}));
		});
	}
	exports.skipWhile = skipWhile;
}));
// node_modules/rxjs/dist/cjs/internal/operators/startWith.js
var require_startWith = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.startWith = void 0;
	var concat_1 = require_concat$1();
	var args_1 = require_args();
	var lift_1 = require_lift();
	function startWith() {
		var values = [];
		for (var _i = 0; _i < arguments.length; _i++) values[_i] = arguments[_i];
		var scheduler = args_1.popScheduler(values);
		return lift_1.operate(function(source, subscriber) {
			(scheduler ? concat_1.concat(values, source, scheduler) : concat_1.concat(values, source)).subscribe(subscriber);
		});
	}
	exports.startWith = startWith;
}));
// node_modules/rxjs/dist/cjs/internal/operators/switchMap.js
var require_switchMap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.switchMap = void 0;
	var innerFrom_1 = require_innerFrom();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function switchMap(project, resultSelector) {
		return lift_1.operate(function(source, subscriber) {
			var innerSubscriber = null;
			var index = 0;
			var isComplete = false;
			var checkComplete = function() {
				return isComplete && !innerSubscriber && subscriber.complete();
			};
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				innerSubscriber === null || innerSubscriber === void 0 || innerSubscriber.unsubscribe();
				var innerIndex = 0;
				var outerIndex = index++;
				innerFrom_1.innerFrom(project(value, outerIndex)).subscribe(innerSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(innerValue) {
					return subscriber.next(resultSelector ? resultSelector(value, innerValue, outerIndex, innerIndex++) : innerValue);
				}, function() {
					innerSubscriber = null;
					checkComplete();
				}));
			}, function() {
				isComplete = true;
				checkComplete();
			}));
		});
	}
	exports.switchMap = switchMap;
}));
// node_modules/rxjs/dist/cjs/internal/operators/switchAll.js
var require_switchAll = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.switchAll = void 0;
	var switchMap_1 = require_switchMap();
	var identity_1 = require_identity();
	function switchAll() {
		return switchMap_1.switchMap(identity_1.identity);
	}
	exports.switchAll = switchAll;
}));
// node_modules/rxjs/dist/cjs/internal/operators/switchMapTo.js
var require_switchMapTo = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.switchMapTo = void 0;
	var switchMap_1 = require_switchMap();
	var isFunction_1 = require_isFunction();
	function switchMapTo(innerObservable, resultSelector) {
		return isFunction_1.isFunction(resultSelector) ? switchMap_1.switchMap(function() {
			return innerObservable;
		}, resultSelector) : switchMap_1.switchMap(function() {
			return innerObservable;
		});
	}
	exports.switchMapTo = switchMapTo;
}));
// node_modules/rxjs/dist/cjs/internal/operators/switchScan.js
var require_switchScan = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.switchScan = void 0;
	var switchMap_1 = require_switchMap();
	var lift_1 = require_lift();
	function switchScan(accumulator, seed) {
		return lift_1.operate(function(source, subscriber) {
			var state = seed;
			switchMap_1.switchMap(function(value, index) {
				return accumulator(state, value, index);
			}, function(_, innerValue) {
				return state = innerValue, innerValue;
			})(source).subscribe(subscriber);
			return function() {
				state = null;
			};
		});
	}
	exports.switchScan = switchScan;
}));
// node_modules/rxjs/dist/cjs/internal/operators/takeUntil.js
var require_takeUntil = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.takeUntil = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	var noop_1 = require_noop();
	function takeUntil(notifier) {
		return lift_1.operate(function(source, subscriber) {
			innerFrom_1.innerFrom(notifier).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
				return subscriber.complete();
			}, noop_1.noop));
			!subscriber.closed && source.subscribe(subscriber);
		});
	}
	exports.takeUntil = takeUntil;
}));
// node_modules/rxjs/dist/cjs/internal/operators/takeWhile.js
var require_takeWhile = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.takeWhile = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function takeWhile(predicate, inclusive) {
		if (inclusive === void 0) inclusive = false;
		return lift_1.operate(function(source, subscriber) {
			var index = 0;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var result = predicate(value, index++);
				(result || inclusive) && subscriber.next(value);
				!result && subscriber.complete();
			}));
		});
	}
	exports.takeWhile = takeWhile;
}));
// node_modules/rxjs/dist/cjs/internal/operators/tap.js
var require_tap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.tap = void 0;
	var isFunction_1 = require_isFunction();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var identity_1 = require_identity();
	function tap(observerOrNext, error, complete) {
		var tapObserver = isFunction_1.isFunction(observerOrNext) || error || complete ? {
			next: observerOrNext,
			error,
			complete
		} : observerOrNext;
		return tapObserver ? lift_1.operate(function(source, subscriber) {
			var _a;
			(_a = tapObserver.subscribe) === null || _a === void 0 || _a.call(tapObserver);
			var isUnsub = true;
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var _a;
				(_a = tapObserver.next) === null || _a === void 0 || _a.call(tapObserver, value);
				subscriber.next(value);
			}, function() {
				var _a;
				isUnsub = false;
				(_a = tapObserver.complete) === null || _a === void 0 || _a.call(tapObserver);
				subscriber.complete();
			}, function(err) {
				var _a;
				isUnsub = false;
				(_a = tapObserver.error) === null || _a === void 0 || _a.call(tapObserver, err);
				subscriber.error(err);
			}, function() {
				var _a, _b;
				if (isUnsub) (_a = tapObserver.unsubscribe) === null || _a === void 0 || _a.call(tapObserver);
				(_b = tapObserver.finalize) === null || _b === void 0 || _b.call(tapObserver);
			}));
		}) : identity_1.identity;
	}
	exports.tap = tap;
}));
// node_modules/rxjs/dist/cjs/internal/operators/throttle.js
var require_throttle = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.throttle = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	function throttle(durationSelector, config) {
		return lift_1.operate(function(source, subscriber) {
			var _a = config !== null && config !== void 0 ? config : {}, _b = _a.leading, leading = _b === void 0 ? true : _b, _c = _a.trailing, trailing = _c === void 0 ? false : _c;
			var hasValue = false;
			var sendValue = null;
			var throttled = null;
			var isComplete = false;
			var endThrottling = function() {
				throttled === null || throttled === void 0 || throttled.unsubscribe();
				throttled = null;
				if (trailing) {
					send();
					isComplete && subscriber.complete();
				}
			};
			var cleanupThrottling = function() {
				throttled = null;
				isComplete && subscriber.complete();
			};
			var startThrottle = function(value) {
				return throttled = innerFrom_1.innerFrom(durationSelector(value)).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, endThrottling, cleanupThrottling));
			};
			var send = function() {
				if (hasValue) {
					hasValue = false;
					var value = sendValue;
					sendValue = null;
					subscriber.next(value);
					!isComplete && startThrottle(value);
				}
			};
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				hasValue = true;
				sendValue = value;
				(!throttled || throttled.closed) && (leading ? send() : startThrottle(value));
			}, function() {
				isComplete = true;
				!(trailing && hasValue && throttled && !throttled.closed) && subscriber.complete();
			}));
		});
	}
	exports.throttle = throttle;
}));
// node_modules/rxjs/dist/cjs/internal/operators/throttleTime.js
var require_throttleTime = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.throttleTime = void 0;
	var async_1 = require_async();
	var throttle_1 = require_throttle();
	var timer_1 = require_timer();
	function throttleTime(duration, scheduler, config) {
		if (scheduler === void 0) scheduler = async_1.asyncScheduler;
		var duration$ = timer_1.timer(duration, scheduler);
		return throttle_1.throttle(function() {
			return duration$;
		}, config);
	}
	exports.throttleTime = throttleTime;
}));
// node_modules/rxjs/dist/cjs/internal/operators/timeInterval.js
var require_timeInterval = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TimeInterval = exports.timeInterval = void 0;
	var async_1 = require_async();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function timeInterval(scheduler) {
		if (scheduler === void 0) scheduler = async_1.asyncScheduler;
		return lift_1.operate(function(source, subscriber) {
			var last = scheduler.now();
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var now = scheduler.now();
				var interval = now - last;
				last = now;
				subscriber.next(new TimeInterval(value, interval));
			}));
		});
	}
	exports.timeInterval = timeInterval;
	var TimeInterval = function() {
		function TimeInterval(value, interval) {
			this.value = value;
			this.interval = interval;
		}
		return TimeInterval;
	}();
	exports.TimeInterval = TimeInterval;
}));
// node_modules/rxjs/dist/cjs/internal/operators/timeoutWith.js
var require_timeoutWith = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.timeoutWith = void 0;
	var async_1 = require_async();
	var isDate_1 = require_isDate();
	var timeout_1 = require_timeout();
	function timeoutWith(due, withObservable, scheduler) {
		var first;
		var each;
		var _with;
		scheduler = scheduler !== null && scheduler !== void 0 ? scheduler : async_1.async;
		if (isDate_1.isValidDate(due)) first = due;
		else if (typeof due === "number") each = due;
		if (withObservable) _with = function() {
			return withObservable;
		};
		else throw new TypeError("No observable provided to switch to");
		if (first == null && each == null) throw new TypeError("No timeout provided.");
		return timeout_1.timeout({
			first,
			each,
			scheduler,
			with: _with
		});
	}
	exports.timeoutWith = timeoutWith;
}));
// node_modules/rxjs/dist/cjs/internal/operators/timestamp.js
var require_timestamp = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.timestamp = void 0;
	var dateTimestampProvider_1 = require_dateTimestampProvider();
	var map_1 = require_map();
	function timestamp(timestampProvider) {
		if (timestampProvider === void 0) timestampProvider = dateTimestampProvider_1.dateTimestampProvider;
		return map_1.map(function(value) {
			return {
				value,
				timestamp: timestampProvider.now()
			};
		});
	}
	exports.timestamp = timestamp;
}));
// node_modules/rxjs/dist/cjs/internal/operators/window.js
var require_window = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.window = void 0;
	var Subject_1 = require_Subject();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var noop_1 = require_noop();
	var innerFrom_1 = require_innerFrom();
	function window(windowBoundaries) {
		return lift_1.operate(function(source, subscriber) {
			var windowSubject = new Subject_1.Subject();
			subscriber.next(windowSubject.asObservable());
			var errorHandler = function(err) {
				windowSubject.error(err);
				subscriber.error(err);
			};
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return windowSubject === null || windowSubject === void 0 ? void 0 : windowSubject.next(value);
			}, function() {
				windowSubject.complete();
				subscriber.complete();
			}, errorHandler));
			innerFrom_1.innerFrom(windowBoundaries).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function() {
				windowSubject.complete();
				subscriber.next(windowSubject = new Subject_1.Subject());
			}, noop_1.noop, errorHandler));
			return function() {
				windowSubject === null || windowSubject === void 0 || windowSubject.unsubscribe();
				windowSubject = null;
			};
		});
	}
	exports.window = window;
}));
// node_modules/rxjs/dist/cjs/internal/operators/windowCount.js
var require_windowCount = /* @__PURE__ */ __commonJSMin(((exports, module, this$7) => {
	var __values = this$7 && this$7.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.windowCount = void 0;
	var Subject_1 = require_Subject();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	function windowCount(windowSize, startWindowEvery) {
		if (startWindowEvery === void 0) startWindowEvery = 0;
		var startEvery = startWindowEvery > 0 ? startWindowEvery : windowSize;
		return lift_1.operate(function(source, subscriber) {
			var windows = [new Subject_1.Subject()];
			var count = 0;
			subscriber.next(windows[0].asObservable());
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var e_1, _a;
				try {
					for (var windows_1 = __values(windows), windows_1_1 = windows_1.next(); !windows_1_1.done; windows_1_1 = windows_1.next()) windows_1_1.value.next(value);
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (windows_1_1 && !windows_1_1.done && (_a = windows_1.return)) _a.call(windows_1);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
				var c = count - windowSize + 1;
				if (c >= 0 && c % startEvery === 0) windows.shift().complete();
				if (++count % startEvery === 0) {
					var window_2 = new Subject_1.Subject();
					windows.push(window_2);
					subscriber.next(window_2.asObservable());
				}
			}, function() {
				while (windows.length > 0) windows.shift().complete();
				subscriber.complete();
			}, function(err) {
				while (windows.length > 0) windows.shift().error(err);
				subscriber.error(err);
			}, function() {
				windows = null;
			}));
		});
	}
	exports.windowCount = windowCount;
}));
// node_modules/rxjs/dist/cjs/internal/operators/windowTime.js
var require_windowTime = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.windowTime = void 0;
	var Subject_1 = require_Subject();
	var async_1 = require_async();
	var Subscription_1 = require_Subscription();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var arrRemove_1 = require_arrRemove();
	var args_1 = require_args();
	var executeSchedule_1 = require_executeSchedule();
	function windowTime(windowTimeSpan) {
		var _a, _b;
		var otherArgs = [];
		for (var _i = 1; _i < arguments.length; _i++) otherArgs[_i - 1] = arguments[_i];
		var scheduler = (_a = args_1.popScheduler(otherArgs)) !== null && _a !== void 0 ? _a : async_1.asyncScheduler;
		var windowCreationInterval = (_b = otherArgs[0]) !== null && _b !== void 0 ? _b : null;
		var maxWindowSize = otherArgs[1] || Infinity;
		return lift_1.operate(function(source, subscriber) {
			var windowRecords = [];
			var restartOnClose = false;
			var closeWindow = function(record) {
				var window = record.window, subs = record.subs;
				window.complete();
				subs.unsubscribe();
				arrRemove_1.arrRemove(windowRecords, record);
				restartOnClose && startWindow();
			};
			var startWindow = function() {
				if (windowRecords) {
					var subs = new Subscription_1.Subscription();
					subscriber.add(subs);
					var window_1 = new Subject_1.Subject();
					var record_1 = {
						window: window_1,
						subs,
						seen: 0
					};
					windowRecords.push(record_1);
					subscriber.next(window_1.asObservable());
					executeSchedule_1.executeSchedule(subs, scheduler, function() {
						return closeWindow(record_1);
					}, windowTimeSpan);
				}
			};
			if (windowCreationInterval !== null && windowCreationInterval >= 0) executeSchedule_1.executeSchedule(subscriber, scheduler, startWindow, windowCreationInterval, true);
			else restartOnClose = true;
			startWindow();
			var loop = function(cb) {
				return windowRecords.slice().forEach(cb);
			};
			var terminate = function(cb) {
				loop(function(_a) {
					var window = _a.window;
					return cb(window);
				});
				cb(subscriber);
				subscriber.unsubscribe();
			};
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				loop(function(record) {
					record.window.next(value);
					maxWindowSize <= ++record.seen && closeWindow(record);
				});
			}, function() {
				return terminate(function(consumer) {
					return consumer.complete();
				});
			}, function(err) {
				return terminate(function(consumer) {
					return consumer.error(err);
				});
			}));
			return function() {
				windowRecords = null;
			};
		});
	}
	exports.windowTime = windowTime;
}));
// node_modules/rxjs/dist/cjs/internal/operators/windowToggle.js
var require_windowToggle = /* @__PURE__ */ __commonJSMin(((exports, module, this$6) => {
	var __values = this$6 && this$6.__values || function(o) {
		var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
		if (m) return m.call(o);
		if (o && typeof o.length === "number") return { next: function() {
			if (o && i >= o.length) o = void 0;
			return {
				value: o && o[i++],
				done: !o
			};
		} };
		throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.windowToggle = void 0;
	var Subject_1 = require_Subject();
	var Subscription_1 = require_Subscription();
	var lift_1 = require_lift();
	var innerFrom_1 = require_innerFrom();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var noop_1 = require_noop();
	var arrRemove_1 = require_arrRemove();
	function windowToggle(openings, closingSelector) {
		return lift_1.operate(function(source, subscriber) {
			var windows = [];
			var handleError = function(err) {
				while (0 < windows.length) windows.shift().error(err);
				subscriber.error(err);
			};
			innerFrom_1.innerFrom(openings).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(openValue) {
				var window = new Subject_1.Subject();
				windows.push(window);
				var closingSubscription = new Subscription_1.Subscription();
				var closeWindow = function() {
					arrRemove_1.arrRemove(windows, window);
					window.complete();
					closingSubscription.unsubscribe();
				};
				var closingNotifier;
				try {
					closingNotifier = innerFrom_1.innerFrom(closingSelector(openValue));
				} catch (err) {
					handleError(err);
					return;
				}
				subscriber.next(window.asObservable());
				closingSubscription.add(closingNotifier.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, closeWindow, noop_1.noop, handleError)));
			}, noop_1.noop));
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				var e_1, _a;
				var windowsCopy = windows.slice();
				try {
					for (var windowsCopy_1 = __values(windowsCopy), windowsCopy_1_1 = windowsCopy_1.next(); !windowsCopy_1_1.done; windowsCopy_1_1 = windowsCopy_1.next()) windowsCopy_1_1.value.next(value);
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (windowsCopy_1_1 && !windowsCopy_1_1.done && (_a = windowsCopy_1.return)) _a.call(windowsCopy_1);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
			}, function() {
				while (0 < windows.length) windows.shift().complete();
				subscriber.complete();
			}, handleError, function() {
				while (0 < windows.length) windows.shift().unsubscribe();
			}));
		});
	}
	exports.windowToggle = windowToggle;
}));
// node_modules/rxjs/dist/cjs/internal/operators/windowWhen.js
var require_windowWhen = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.windowWhen = void 0;
	var Subject_1 = require_Subject();
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	function windowWhen(closingSelector) {
		return lift_1.operate(function(source, subscriber) {
			var window;
			var closingSubscriber;
			var handleError = function(err) {
				window.error(err);
				subscriber.error(err);
			};
			var openWindow = function() {
				closingSubscriber === null || closingSubscriber === void 0 || closingSubscriber.unsubscribe();
				window === null || window === void 0 || window.complete();
				window = new Subject_1.Subject();
				subscriber.next(window.asObservable());
				var closingNotifier;
				try {
					closingNotifier = innerFrom_1.innerFrom(closingSelector());
				} catch (err) {
					handleError(err);
					return;
				}
				closingNotifier.subscribe(closingSubscriber = OperatorSubscriber_1.createOperatorSubscriber(subscriber, openWindow, openWindow, handleError));
			};
			openWindow();
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				return window.next(value);
			}, function() {
				window.complete();
				subscriber.complete();
			}, handleError, function() {
				closingSubscriber === null || closingSubscriber === void 0 || closingSubscriber.unsubscribe();
				window = null;
			}));
		});
	}
	exports.windowWhen = windowWhen;
}));
// node_modules/rxjs/dist/cjs/internal/operators/withLatestFrom.js
var require_withLatestFrom = /* @__PURE__ */ __commonJSMin(((exports, module, this$5) => {
	var __read = this$5 && this$5.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$5 && this$5.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.withLatestFrom = void 0;
	var lift_1 = require_lift();
	var OperatorSubscriber_1 = require_OperatorSubscriber();
	var innerFrom_1 = require_innerFrom();
	var identity_1 = require_identity();
	var noop_1 = require_noop();
	var args_1 = require_args();
	function withLatestFrom() {
		var inputs = [];
		for (var _i = 0; _i < arguments.length; _i++) inputs[_i] = arguments[_i];
		var project = args_1.popResultSelector(inputs);
		return lift_1.operate(function(source, subscriber) {
			var len = inputs.length;
			var otherValues = new Array(len);
			var hasValue = inputs.map(function() {
				return false;
			});
			var ready = false;
			var _loop_1 = function(i) {
				innerFrom_1.innerFrom(inputs[i]).subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
					otherValues[i] = value;
					if (!ready && !hasValue[i]) {
						hasValue[i] = true;
						(ready = hasValue.every(identity_1.identity)) && (hasValue = null);
					}
				}, noop_1.noop));
			};
			for (var i = 0; i < len; i++) _loop_1(i);
			source.subscribe(OperatorSubscriber_1.createOperatorSubscriber(subscriber, function(value) {
				if (ready) {
					var values = __spreadArray([value], __read(otherValues));
					subscriber.next(project ? project.apply(void 0, __spreadArray([], __read(values))) : values);
				}
			}));
		});
	}
	exports.withLatestFrom = withLatestFrom;
}));
// node_modules/rxjs/dist/cjs/internal/operators/zipAll.js
var require_zipAll = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.zipAll = void 0;
	var zip_1 = require_zip$1();
	var joinAllInternals_1 = require_joinAllInternals();
	function zipAll(project) {
		return joinAllInternals_1.joinAllInternals(zip_1.zip, project);
	}
	exports.zipAll = zipAll;
}));
// node_modules/rxjs/dist/cjs/internal/operators/zip.js
var require_zip = /* @__PURE__ */ __commonJSMin(((exports, module, this$4) => {
	var __read = this$4 && this$4.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$4 && this$4.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.zip = void 0;
	var zip_1 = require_zip$1();
	var lift_1 = require_lift();
	function zip() {
		var sources = [];
		for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
		return lift_1.operate(function(source, subscriber) {
			zip_1.zip.apply(void 0, __spreadArray([source], __read(sources))).subscribe(subscriber);
		});
	}
	exports.zip = zip;
}));
// node_modules/rxjs/dist/cjs/internal/operators/zipWith.js
var require_zipWith = /* @__PURE__ */ __commonJSMin(((exports, module, this$3) => {
	var __read = this$3 && this$3.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$3 && this$3.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.zipWith = void 0;
	var zip_1 = require_zip();
	function zipWith() {
		var otherInputs = [];
		for (var _i = 0; _i < arguments.length; _i++) otherInputs[_i] = arguments[_i];
		return zip_1.zip.apply(void 0, __spreadArray([], __read(otherInputs)));
	}
	exports.zipWith = zipWith;
}));
// node_modules/rxjs/dist/cjs/index.js
var require_cjs = /* @__PURE__ */ __commonJSMin(((exports, module, this$2) => {
	var __createBinding = this$2 && this$2.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		Object.defineProperty(o, k2, {
			enumerable: true,
			get: function() {
				return m[k];
			}
		});
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __exportStar = this$2 && this$2.__exportStar || function(m, exports) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.interval = exports.iif = exports.generate = exports.fromEventPattern = exports.fromEvent = exports.from = exports.forkJoin = exports.empty = exports.defer = exports.connectable = exports.concat = exports.combineLatest = exports.bindNodeCallback = exports.bindCallback = exports.UnsubscriptionError = exports.TimeoutError = exports.SequenceError = exports.ObjectUnsubscribedError = exports.NotFoundError = exports.EmptyError = exports.ArgumentOutOfRangeError = exports.firstValueFrom = exports.lastValueFrom = exports.isObservable = exports.identity = exports.noop = exports.pipe = exports.NotificationKind = exports.Notification = exports.Subscriber = exports.Subscription = exports.Scheduler = exports.VirtualAction = exports.VirtualTimeScheduler = exports.animationFrameScheduler = exports.animationFrame = exports.queueScheduler = exports.queue = exports.asyncScheduler = exports.async = exports.asapScheduler = exports.asap = exports.AsyncSubject = exports.ReplaySubject = exports.BehaviorSubject = exports.Subject = exports.animationFrames = exports.observable = exports.ConnectableObservable = exports.Observable = void 0;
	exports.filter = exports.expand = exports.exhaustMap = exports.exhaustAll = exports.exhaust = exports.every = exports.endWith = exports.elementAt = exports.distinctUntilKeyChanged = exports.distinctUntilChanged = exports.distinct = exports.dematerialize = exports.delayWhen = exports.delay = exports.defaultIfEmpty = exports.debounceTime = exports.debounce = exports.count = exports.connect = exports.concatWith = exports.concatMapTo = exports.concatMap = exports.concatAll = exports.combineLatestWith = exports.combineLatestAll = exports.combineAll = exports.catchError = exports.bufferWhen = exports.bufferToggle = exports.bufferTime = exports.bufferCount = exports.buffer = exports.auditTime = exports.audit = exports.config = exports.NEVER = exports.EMPTY = exports.scheduled = exports.zip = exports.using = exports.timer = exports.throwError = exports.range = exports.race = exports.partition = exports.pairs = exports.onErrorResumeNext = exports.of = exports.never = exports.merge = void 0;
	exports.switchMap = exports.switchAll = exports.subscribeOn = exports.startWith = exports.skipWhile = exports.skipUntil = exports.skipLast = exports.skip = exports.single = exports.shareReplay = exports.share = exports.sequenceEqual = exports.scan = exports.sampleTime = exports.sample = exports.refCount = exports.retryWhen = exports.retry = exports.repeatWhen = exports.repeat = exports.reduce = exports.raceWith = exports.publishReplay = exports.publishLast = exports.publishBehavior = exports.publish = exports.pluck = exports.pairwise = exports.onErrorResumeNextWith = exports.observeOn = exports.multicast = exports.min = exports.mergeWith = exports.mergeScan = exports.mergeMapTo = exports.mergeMap = exports.flatMap = exports.mergeAll = exports.max = exports.materialize = exports.mapTo = exports.map = exports.last = exports.isEmpty = exports.ignoreElements = exports.groupBy = exports.first = exports.findIndex = exports.find = exports.finalize = void 0;
	exports.zipWith = exports.zipAll = exports.withLatestFrom = exports.windowWhen = exports.windowToggle = exports.windowTime = exports.windowCount = exports.window = exports.toArray = exports.timestamp = exports.timeoutWith = exports.timeout = exports.timeInterval = exports.throwIfEmpty = exports.throttleTime = exports.throttle = exports.tap = exports.takeWhile = exports.takeUntil = exports.takeLast = exports.take = exports.switchScan = exports.switchMapTo = void 0;
	var Observable_1 = require_Observable();
	Object.defineProperty(exports, "Observable", {
		enumerable: true,
		get: function() {
			return Observable_1.Observable;
		}
	});
	var ConnectableObservable_1 = require_ConnectableObservable();
	Object.defineProperty(exports, "ConnectableObservable", {
		enumerable: true,
		get: function() {
			return ConnectableObservable_1.ConnectableObservable;
		}
	});
	var observable_1 = require_observable();
	Object.defineProperty(exports, "observable", {
		enumerable: true,
		get: function() {
			return observable_1.observable;
		}
	});
	var animationFrames_1 = require_animationFrames();
	Object.defineProperty(exports, "animationFrames", {
		enumerable: true,
		get: function() {
			return animationFrames_1.animationFrames;
		}
	});
	var Subject_1 = require_Subject();
	Object.defineProperty(exports, "Subject", {
		enumerable: true,
		get: function() {
			return Subject_1.Subject;
		}
	});
	var BehaviorSubject_1 = require_BehaviorSubject();
	Object.defineProperty(exports, "BehaviorSubject", {
		enumerable: true,
		get: function() {
			return BehaviorSubject_1.BehaviorSubject;
		}
	});
	var ReplaySubject_1 = require_ReplaySubject();
	Object.defineProperty(exports, "ReplaySubject", {
		enumerable: true,
		get: function() {
			return ReplaySubject_1.ReplaySubject;
		}
	});
	var AsyncSubject_1 = require_AsyncSubject();
	Object.defineProperty(exports, "AsyncSubject", {
		enumerable: true,
		get: function() {
			return AsyncSubject_1.AsyncSubject;
		}
	});
	var asap_1 = require_asap();
	Object.defineProperty(exports, "asap", {
		enumerable: true,
		get: function() {
			return asap_1.asap;
		}
	});
	Object.defineProperty(exports, "asapScheduler", {
		enumerable: true,
		get: function() {
			return asap_1.asapScheduler;
		}
	});
	var async_1 = require_async();
	Object.defineProperty(exports, "async", {
		enumerable: true,
		get: function() {
			return async_1.async;
		}
	});
	Object.defineProperty(exports, "asyncScheduler", {
		enumerable: true,
		get: function() {
			return async_1.asyncScheduler;
		}
	});
	var queue_1 = require_queue();
	Object.defineProperty(exports, "queue", {
		enumerable: true,
		get: function() {
			return queue_1.queue;
		}
	});
	Object.defineProperty(exports, "queueScheduler", {
		enumerable: true,
		get: function() {
			return queue_1.queueScheduler;
		}
	});
	var animationFrame_1 = require_animationFrame();
	Object.defineProperty(exports, "animationFrame", {
		enumerable: true,
		get: function() {
			return animationFrame_1.animationFrame;
		}
	});
	Object.defineProperty(exports, "animationFrameScheduler", {
		enumerable: true,
		get: function() {
			return animationFrame_1.animationFrameScheduler;
		}
	});
	var VirtualTimeScheduler_1 = require_VirtualTimeScheduler();
	Object.defineProperty(exports, "VirtualTimeScheduler", {
		enumerable: true,
		get: function() {
			return VirtualTimeScheduler_1.VirtualTimeScheduler;
		}
	});
	Object.defineProperty(exports, "VirtualAction", {
		enumerable: true,
		get: function() {
			return VirtualTimeScheduler_1.VirtualAction;
		}
	});
	var Scheduler_1 = require_Scheduler();
	Object.defineProperty(exports, "Scheduler", {
		enumerable: true,
		get: function() {
			return Scheduler_1.Scheduler;
		}
	});
	var Subscription_1 = require_Subscription();
	Object.defineProperty(exports, "Subscription", {
		enumerable: true,
		get: function() {
			return Subscription_1.Subscription;
		}
	});
	var Subscriber_1 = require_Subscriber();
	Object.defineProperty(exports, "Subscriber", {
		enumerable: true,
		get: function() {
			return Subscriber_1.Subscriber;
		}
	});
	var Notification_1 = require_Notification();
	Object.defineProperty(exports, "Notification", {
		enumerable: true,
		get: function() {
			return Notification_1.Notification;
		}
	});
	Object.defineProperty(exports, "NotificationKind", {
		enumerable: true,
		get: function() {
			return Notification_1.NotificationKind;
		}
	});
	var pipe_1 = require_pipe();
	Object.defineProperty(exports, "pipe", {
		enumerable: true,
		get: function() {
			return pipe_1.pipe;
		}
	});
	var noop_1 = require_noop();
	Object.defineProperty(exports, "noop", {
		enumerable: true,
		get: function() {
			return noop_1.noop;
		}
	});
	var identity_1 = require_identity();
	Object.defineProperty(exports, "identity", {
		enumerable: true,
		get: function() {
			return identity_1.identity;
		}
	});
	var isObservable_1 = require_isObservable();
	Object.defineProperty(exports, "isObservable", {
		enumerable: true,
		get: function() {
			return isObservable_1.isObservable;
		}
	});
	var lastValueFrom_1 = require_lastValueFrom();
	Object.defineProperty(exports, "lastValueFrom", {
		enumerable: true,
		get: function() {
			return lastValueFrom_1.lastValueFrom;
		}
	});
	var firstValueFrom_1 = require_firstValueFrom();
	Object.defineProperty(exports, "firstValueFrom", {
		enumerable: true,
		get: function() {
			return firstValueFrom_1.firstValueFrom;
		}
	});
	var ArgumentOutOfRangeError_1 = require_ArgumentOutOfRangeError();
	Object.defineProperty(exports, "ArgumentOutOfRangeError", {
		enumerable: true,
		get: function() {
			return ArgumentOutOfRangeError_1.ArgumentOutOfRangeError;
		}
	});
	var EmptyError_1 = require_EmptyError();
	Object.defineProperty(exports, "EmptyError", {
		enumerable: true,
		get: function() {
			return EmptyError_1.EmptyError;
		}
	});
	var NotFoundError_1 = require_NotFoundError();
	Object.defineProperty(exports, "NotFoundError", {
		enumerable: true,
		get: function() {
			return NotFoundError_1.NotFoundError;
		}
	});
	var ObjectUnsubscribedError_1 = require_ObjectUnsubscribedError();
	Object.defineProperty(exports, "ObjectUnsubscribedError", {
		enumerable: true,
		get: function() {
			return ObjectUnsubscribedError_1.ObjectUnsubscribedError;
		}
	});
	var SequenceError_1 = require_SequenceError();
	Object.defineProperty(exports, "SequenceError", {
		enumerable: true,
		get: function() {
			return SequenceError_1.SequenceError;
		}
	});
	var timeout_1 = require_timeout();
	Object.defineProperty(exports, "TimeoutError", {
		enumerable: true,
		get: function() {
			return timeout_1.TimeoutError;
		}
	});
	var UnsubscriptionError_1 = require_UnsubscriptionError();
	Object.defineProperty(exports, "UnsubscriptionError", {
		enumerable: true,
		get: function() {
			return UnsubscriptionError_1.UnsubscriptionError;
		}
	});
	var bindCallback_1 = require_bindCallback();
	Object.defineProperty(exports, "bindCallback", {
		enumerable: true,
		get: function() {
			return bindCallback_1.bindCallback;
		}
	});
	var bindNodeCallback_1 = require_bindNodeCallback();
	Object.defineProperty(exports, "bindNodeCallback", {
		enumerable: true,
		get: function() {
			return bindNodeCallback_1.bindNodeCallback;
		}
	});
	var combineLatest_1 = require_combineLatest$1();
	Object.defineProperty(exports, "combineLatest", {
		enumerable: true,
		get: function() {
			return combineLatest_1.combineLatest;
		}
	});
	var concat_1 = require_concat$1();
	Object.defineProperty(exports, "concat", {
		enumerable: true,
		get: function() {
			return concat_1.concat;
		}
	});
	var connectable_1 = require_connectable();
	Object.defineProperty(exports, "connectable", {
		enumerable: true,
		get: function() {
			return connectable_1.connectable;
		}
	});
	var defer_1 = require_defer();
	Object.defineProperty(exports, "defer", {
		enumerable: true,
		get: function() {
			return defer_1.defer;
		}
	});
	var empty_1 = require_empty();
	Object.defineProperty(exports, "empty", {
		enumerable: true,
		get: function() {
			return empty_1.empty;
		}
	});
	var forkJoin_1 = require_forkJoin();
	Object.defineProperty(exports, "forkJoin", {
		enumerable: true,
		get: function() {
			return forkJoin_1.forkJoin;
		}
	});
	var from_1 = require_from();
	Object.defineProperty(exports, "from", {
		enumerable: true,
		get: function() {
			return from_1.from;
		}
	});
	var fromEvent_1 = require_fromEvent();
	Object.defineProperty(exports, "fromEvent", {
		enumerable: true,
		get: function() {
			return fromEvent_1.fromEvent;
		}
	});
	var fromEventPattern_1 = require_fromEventPattern();
	Object.defineProperty(exports, "fromEventPattern", {
		enumerable: true,
		get: function() {
			return fromEventPattern_1.fromEventPattern;
		}
	});
	var generate_1 = require_generate();
	Object.defineProperty(exports, "generate", {
		enumerable: true,
		get: function() {
			return generate_1.generate;
		}
	});
	var iif_1 = require_iif();
	Object.defineProperty(exports, "iif", {
		enumerable: true,
		get: function() {
			return iif_1.iif;
		}
	});
	var interval_1 = require_interval();
	Object.defineProperty(exports, "interval", {
		enumerable: true,
		get: function() {
			return interval_1.interval;
		}
	});
	var merge_1 = require_merge$1();
	Object.defineProperty(exports, "merge", {
		enumerable: true,
		get: function() {
			return merge_1.merge;
		}
	});
	var never_1 = require_never();
	Object.defineProperty(exports, "never", {
		enumerable: true,
		get: function() {
			return never_1.never;
		}
	});
	var of_1 = require_of();
	Object.defineProperty(exports, "of", {
		enumerable: true,
		get: function() {
			return of_1.of;
		}
	});
	var onErrorResumeNext_1 = require_onErrorResumeNext();
	Object.defineProperty(exports, "onErrorResumeNext", {
		enumerable: true,
		get: function() {
			return onErrorResumeNext_1.onErrorResumeNext;
		}
	});
	var pairs_1 = require_pairs();
	Object.defineProperty(exports, "pairs", {
		enumerable: true,
		get: function() {
			return pairs_1.pairs;
		}
	});
	var partition_1 = require_partition$1();
	Object.defineProperty(exports, "partition", {
		enumerable: true,
		get: function() {
			return partition_1.partition;
		}
	});
	var race_1 = require_race$1();
	Object.defineProperty(exports, "race", {
		enumerable: true,
		get: function() {
			return race_1.race;
		}
	});
	var range_1 = require_range();
	Object.defineProperty(exports, "range", {
		enumerable: true,
		get: function() {
			return range_1.range;
		}
	});
	var throwError_1 = require_throwError();
	Object.defineProperty(exports, "throwError", {
		enumerable: true,
		get: function() {
			return throwError_1.throwError;
		}
	});
	var timer_1 = require_timer();
	Object.defineProperty(exports, "timer", {
		enumerable: true,
		get: function() {
			return timer_1.timer;
		}
	});
	var using_1 = require_using();
	Object.defineProperty(exports, "using", {
		enumerable: true,
		get: function() {
			return using_1.using;
		}
	});
	var zip_1 = require_zip$1();
	Object.defineProperty(exports, "zip", {
		enumerable: true,
		get: function() {
			return zip_1.zip;
		}
	});
	var scheduled_1 = require_scheduled();
	Object.defineProperty(exports, "scheduled", {
		enumerable: true,
		get: function() {
			return scheduled_1.scheduled;
		}
	});
	var empty_2 = require_empty();
	Object.defineProperty(exports, "EMPTY", {
		enumerable: true,
		get: function() {
			return empty_2.EMPTY;
		}
	});
	var never_2 = require_never();
	Object.defineProperty(exports, "NEVER", {
		enumerable: true,
		get: function() {
			return never_2.NEVER;
		}
	});
	__exportStar(require_types(), exports);
	var config_1 = require_config();
	Object.defineProperty(exports, "config", {
		enumerable: true,
		get: function() {
			return config_1.config;
		}
	});
	var audit_1 = require_audit();
	Object.defineProperty(exports, "audit", {
		enumerable: true,
		get: function() {
			return audit_1.audit;
		}
	});
	var auditTime_1 = require_auditTime();
	Object.defineProperty(exports, "auditTime", {
		enumerable: true,
		get: function() {
			return auditTime_1.auditTime;
		}
	});
	var buffer_1 = require_buffer();
	Object.defineProperty(exports, "buffer", {
		enumerable: true,
		get: function() {
			return buffer_1.buffer;
		}
	});
	var bufferCount_1 = require_bufferCount();
	Object.defineProperty(exports, "bufferCount", {
		enumerable: true,
		get: function() {
			return bufferCount_1.bufferCount;
		}
	});
	var bufferTime_1 = require_bufferTime();
	Object.defineProperty(exports, "bufferTime", {
		enumerable: true,
		get: function() {
			return bufferTime_1.bufferTime;
		}
	});
	var bufferToggle_1 = require_bufferToggle();
	Object.defineProperty(exports, "bufferToggle", {
		enumerable: true,
		get: function() {
			return bufferToggle_1.bufferToggle;
		}
	});
	var bufferWhen_1 = require_bufferWhen();
	Object.defineProperty(exports, "bufferWhen", {
		enumerable: true,
		get: function() {
			return bufferWhen_1.bufferWhen;
		}
	});
	var catchError_1 = require_catchError();
	Object.defineProperty(exports, "catchError", {
		enumerable: true,
		get: function() {
			return catchError_1.catchError;
		}
	});
	var combineAll_1 = require_combineAll();
	Object.defineProperty(exports, "combineAll", {
		enumerable: true,
		get: function() {
			return combineAll_1.combineAll;
		}
	});
	var combineLatestAll_1 = require_combineLatestAll();
	Object.defineProperty(exports, "combineLatestAll", {
		enumerable: true,
		get: function() {
			return combineLatestAll_1.combineLatestAll;
		}
	});
	var combineLatestWith_1 = require_combineLatestWith();
	Object.defineProperty(exports, "combineLatestWith", {
		enumerable: true,
		get: function() {
			return combineLatestWith_1.combineLatestWith;
		}
	});
	var concatAll_1 = require_concatAll();
	Object.defineProperty(exports, "concatAll", {
		enumerable: true,
		get: function() {
			return concatAll_1.concatAll;
		}
	});
	var concatMap_1 = require_concatMap();
	Object.defineProperty(exports, "concatMap", {
		enumerable: true,
		get: function() {
			return concatMap_1.concatMap;
		}
	});
	var concatMapTo_1 = require_concatMapTo();
	Object.defineProperty(exports, "concatMapTo", {
		enumerable: true,
		get: function() {
			return concatMapTo_1.concatMapTo;
		}
	});
	var concatWith_1 = require_concatWith();
	Object.defineProperty(exports, "concatWith", {
		enumerable: true,
		get: function() {
			return concatWith_1.concatWith;
		}
	});
	var connect_1 = require_connect();
	Object.defineProperty(exports, "connect", {
		enumerable: true,
		get: function() {
			return connect_1.connect;
		}
	});
	var count_1 = require_count();
	Object.defineProperty(exports, "count", {
		enumerable: true,
		get: function() {
			return count_1.count;
		}
	});
	var debounce_1 = require_debounce();
	Object.defineProperty(exports, "debounce", {
		enumerable: true,
		get: function() {
			return debounce_1.debounce;
		}
	});
	var debounceTime_1 = require_debounceTime();
	Object.defineProperty(exports, "debounceTime", {
		enumerable: true,
		get: function() {
			return debounceTime_1.debounceTime;
		}
	});
	var defaultIfEmpty_1 = require_defaultIfEmpty();
	Object.defineProperty(exports, "defaultIfEmpty", {
		enumerable: true,
		get: function() {
			return defaultIfEmpty_1.defaultIfEmpty;
		}
	});
	var delay_1 = require_delay();
	Object.defineProperty(exports, "delay", {
		enumerable: true,
		get: function() {
			return delay_1.delay;
		}
	});
	var delayWhen_1 = require_delayWhen();
	Object.defineProperty(exports, "delayWhen", {
		enumerable: true,
		get: function() {
			return delayWhen_1.delayWhen;
		}
	});
	var dematerialize_1 = require_dematerialize();
	Object.defineProperty(exports, "dematerialize", {
		enumerable: true,
		get: function() {
			return dematerialize_1.dematerialize;
		}
	});
	var distinct_1 = require_distinct();
	Object.defineProperty(exports, "distinct", {
		enumerable: true,
		get: function() {
			return distinct_1.distinct;
		}
	});
	var distinctUntilChanged_1 = require_distinctUntilChanged();
	Object.defineProperty(exports, "distinctUntilChanged", {
		enumerable: true,
		get: function() {
			return distinctUntilChanged_1.distinctUntilChanged;
		}
	});
	var distinctUntilKeyChanged_1 = require_distinctUntilKeyChanged();
	Object.defineProperty(exports, "distinctUntilKeyChanged", {
		enumerable: true,
		get: function() {
			return distinctUntilKeyChanged_1.distinctUntilKeyChanged;
		}
	});
	var elementAt_1 = require_elementAt();
	Object.defineProperty(exports, "elementAt", {
		enumerable: true,
		get: function() {
			return elementAt_1.elementAt;
		}
	});
	var endWith_1 = require_endWith();
	Object.defineProperty(exports, "endWith", {
		enumerable: true,
		get: function() {
			return endWith_1.endWith;
		}
	});
	var every_1 = require_every();
	Object.defineProperty(exports, "every", {
		enumerable: true,
		get: function() {
			return every_1.every;
		}
	});
	var exhaust_1 = require_exhaust();
	Object.defineProperty(exports, "exhaust", {
		enumerable: true,
		get: function() {
			return exhaust_1.exhaust;
		}
	});
	var exhaustAll_1 = require_exhaustAll();
	Object.defineProperty(exports, "exhaustAll", {
		enumerable: true,
		get: function() {
			return exhaustAll_1.exhaustAll;
		}
	});
	var exhaustMap_1 = require_exhaustMap();
	Object.defineProperty(exports, "exhaustMap", {
		enumerable: true,
		get: function() {
			return exhaustMap_1.exhaustMap;
		}
	});
	var expand_1 = require_expand();
	Object.defineProperty(exports, "expand", {
		enumerable: true,
		get: function() {
			return expand_1.expand;
		}
	});
	var filter_1 = require_filter();
	Object.defineProperty(exports, "filter", {
		enumerable: true,
		get: function() {
			return filter_1.filter;
		}
	});
	var finalize_1 = require_finalize();
	Object.defineProperty(exports, "finalize", {
		enumerable: true,
		get: function() {
			return finalize_1.finalize;
		}
	});
	var find_1 = require_find();
	Object.defineProperty(exports, "find", {
		enumerable: true,
		get: function() {
			return find_1.find;
		}
	});
	var findIndex_1 = require_findIndex();
	Object.defineProperty(exports, "findIndex", {
		enumerable: true,
		get: function() {
			return findIndex_1.findIndex;
		}
	});
	var first_1 = require_first();
	Object.defineProperty(exports, "first", {
		enumerable: true,
		get: function() {
			return first_1.first;
		}
	});
	var groupBy_1 = require_groupBy();
	Object.defineProperty(exports, "groupBy", {
		enumerable: true,
		get: function() {
			return groupBy_1.groupBy;
		}
	});
	var ignoreElements_1 = require_ignoreElements();
	Object.defineProperty(exports, "ignoreElements", {
		enumerable: true,
		get: function() {
			return ignoreElements_1.ignoreElements;
		}
	});
	var isEmpty_1 = require_isEmpty();
	Object.defineProperty(exports, "isEmpty", {
		enumerable: true,
		get: function() {
			return isEmpty_1.isEmpty;
		}
	});
	var last_1 = require_last();
	Object.defineProperty(exports, "last", {
		enumerable: true,
		get: function() {
			return last_1.last;
		}
	});
	var map_1 = require_map();
	Object.defineProperty(exports, "map", {
		enumerable: true,
		get: function() {
			return map_1.map;
		}
	});
	var mapTo_1 = require_mapTo();
	Object.defineProperty(exports, "mapTo", {
		enumerable: true,
		get: function() {
			return mapTo_1.mapTo;
		}
	});
	var materialize_1 = require_materialize();
	Object.defineProperty(exports, "materialize", {
		enumerable: true,
		get: function() {
			return materialize_1.materialize;
		}
	});
	var max_1 = require_max();
	Object.defineProperty(exports, "max", {
		enumerable: true,
		get: function() {
			return max_1.max;
		}
	});
	var mergeAll_1 = require_mergeAll();
	Object.defineProperty(exports, "mergeAll", {
		enumerable: true,
		get: function() {
			return mergeAll_1.mergeAll;
		}
	});
	var flatMap_1 = require_flatMap();
	Object.defineProperty(exports, "flatMap", {
		enumerable: true,
		get: function() {
			return flatMap_1.flatMap;
		}
	});
	var mergeMap_1 = require_mergeMap();
	Object.defineProperty(exports, "mergeMap", {
		enumerable: true,
		get: function() {
			return mergeMap_1.mergeMap;
		}
	});
	var mergeMapTo_1 = require_mergeMapTo();
	Object.defineProperty(exports, "mergeMapTo", {
		enumerable: true,
		get: function() {
			return mergeMapTo_1.mergeMapTo;
		}
	});
	var mergeScan_1 = require_mergeScan();
	Object.defineProperty(exports, "mergeScan", {
		enumerable: true,
		get: function() {
			return mergeScan_1.mergeScan;
		}
	});
	var mergeWith_1 = require_mergeWith();
	Object.defineProperty(exports, "mergeWith", {
		enumerable: true,
		get: function() {
			return mergeWith_1.mergeWith;
		}
	});
	var min_1 = require_min();
	Object.defineProperty(exports, "min", {
		enumerable: true,
		get: function() {
			return min_1.min;
		}
	});
	var multicast_1 = require_multicast();
	Object.defineProperty(exports, "multicast", {
		enumerable: true,
		get: function() {
			return multicast_1.multicast;
		}
	});
	var observeOn_1 = require_observeOn();
	Object.defineProperty(exports, "observeOn", {
		enumerable: true,
		get: function() {
			return observeOn_1.observeOn;
		}
	});
	var onErrorResumeNextWith_1 = require_onErrorResumeNextWith();
	Object.defineProperty(exports, "onErrorResumeNextWith", {
		enumerable: true,
		get: function() {
			return onErrorResumeNextWith_1.onErrorResumeNextWith;
		}
	});
	var pairwise_1 = require_pairwise();
	Object.defineProperty(exports, "pairwise", {
		enumerable: true,
		get: function() {
			return pairwise_1.pairwise;
		}
	});
	var pluck_1 = require_pluck();
	Object.defineProperty(exports, "pluck", {
		enumerable: true,
		get: function() {
			return pluck_1.pluck;
		}
	});
	var publish_1 = require_publish();
	Object.defineProperty(exports, "publish", {
		enumerable: true,
		get: function() {
			return publish_1.publish;
		}
	});
	var publishBehavior_1 = require_publishBehavior();
	Object.defineProperty(exports, "publishBehavior", {
		enumerable: true,
		get: function() {
			return publishBehavior_1.publishBehavior;
		}
	});
	var publishLast_1 = require_publishLast();
	Object.defineProperty(exports, "publishLast", {
		enumerable: true,
		get: function() {
			return publishLast_1.publishLast;
		}
	});
	var publishReplay_1 = require_publishReplay();
	Object.defineProperty(exports, "publishReplay", {
		enumerable: true,
		get: function() {
			return publishReplay_1.publishReplay;
		}
	});
	var raceWith_1 = require_raceWith();
	Object.defineProperty(exports, "raceWith", {
		enumerable: true,
		get: function() {
			return raceWith_1.raceWith;
		}
	});
	var reduce_1 = require_reduce();
	Object.defineProperty(exports, "reduce", {
		enumerable: true,
		get: function() {
			return reduce_1.reduce;
		}
	});
	var repeat_1 = require_repeat();
	Object.defineProperty(exports, "repeat", {
		enumerable: true,
		get: function() {
			return repeat_1.repeat;
		}
	});
	var repeatWhen_1 = require_repeatWhen();
	Object.defineProperty(exports, "repeatWhen", {
		enumerable: true,
		get: function() {
			return repeatWhen_1.repeatWhen;
		}
	});
	var retry_1 = require_retry();
	Object.defineProperty(exports, "retry", {
		enumerable: true,
		get: function() {
			return retry_1.retry;
		}
	});
	var retryWhen_1 = require_retryWhen();
	Object.defineProperty(exports, "retryWhen", {
		enumerable: true,
		get: function() {
			return retryWhen_1.retryWhen;
		}
	});
	var refCount_1 = require_refCount();
	Object.defineProperty(exports, "refCount", {
		enumerable: true,
		get: function() {
			return refCount_1.refCount;
		}
	});
	var sample_1 = require_sample();
	Object.defineProperty(exports, "sample", {
		enumerable: true,
		get: function() {
			return sample_1.sample;
		}
	});
	var sampleTime_1 = require_sampleTime();
	Object.defineProperty(exports, "sampleTime", {
		enumerable: true,
		get: function() {
			return sampleTime_1.sampleTime;
		}
	});
	var scan_1 = require_scan();
	Object.defineProperty(exports, "scan", {
		enumerable: true,
		get: function() {
			return scan_1.scan;
		}
	});
	var sequenceEqual_1 = require_sequenceEqual();
	Object.defineProperty(exports, "sequenceEqual", {
		enumerable: true,
		get: function() {
			return sequenceEqual_1.sequenceEqual;
		}
	});
	var share_1 = require_share();
	Object.defineProperty(exports, "share", {
		enumerable: true,
		get: function() {
			return share_1.share;
		}
	});
	var shareReplay_1 = require_shareReplay();
	Object.defineProperty(exports, "shareReplay", {
		enumerable: true,
		get: function() {
			return shareReplay_1.shareReplay;
		}
	});
	var single_1 = require_single();
	Object.defineProperty(exports, "single", {
		enumerable: true,
		get: function() {
			return single_1.single;
		}
	});
	var skip_1 = require_skip();
	Object.defineProperty(exports, "skip", {
		enumerable: true,
		get: function() {
			return skip_1.skip;
		}
	});
	var skipLast_1 = require_skipLast();
	Object.defineProperty(exports, "skipLast", {
		enumerable: true,
		get: function() {
			return skipLast_1.skipLast;
		}
	});
	var skipUntil_1 = require_skipUntil();
	Object.defineProperty(exports, "skipUntil", {
		enumerable: true,
		get: function() {
			return skipUntil_1.skipUntil;
		}
	});
	var skipWhile_1 = require_skipWhile();
	Object.defineProperty(exports, "skipWhile", {
		enumerable: true,
		get: function() {
			return skipWhile_1.skipWhile;
		}
	});
	var startWith_1 = require_startWith();
	Object.defineProperty(exports, "startWith", {
		enumerable: true,
		get: function() {
			return startWith_1.startWith;
		}
	});
	var subscribeOn_1 = require_subscribeOn();
	Object.defineProperty(exports, "subscribeOn", {
		enumerable: true,
		get: function() {
			return subscribeOn_1.subscribeOn;
		}
	});
	var switchAll_1 = require_switchAll();
	Object.defineProperty(exports, "switchAll", {
		enumerable: true,
		get: function() {
			return switchAll_1.switchAll;
		}
	});
	var switchMap_1 = require_switchMap();
	Object.defineProperty(exports, "switchMap", {
		enumerable: true,
		get: function() {
			return switchMap_1.switchMap;
		}
	});
	var switchMapTo_1 = require_switchMapTo();
	Object.defineProperty(exports, "switchMapTo", {
		enumerable: true,
		get: function() {
			return switchMapTo_1.switchMapTo;
		}
	});
	var switchScan_1 = require_switchScan();
	Object.defineProperty(exports, "switchScan", {
		enumerable: true,
		get: function() {
			return switchScan_1.switchScan;
		}
	});
	var take_1 = require_take();
	Object.defineProperty(exports, "take", {
		enumerable: true,
		get: function() {
			return take_1.take;
		}
	});
	var takeLast_1 = require_takeLast();
	Object.defineProperty(exports, "takeLast", {
		enumerable: true,
		get: function() {
			return takeLast_1.takeLast;
		}
	});
	var takeUntil_1 = require_takeUntil();
	Object.defineProperty(exports, "takeUntil", {
		enumerable: true,
		get: function() {
			return takeUntil_1.takeUntil;
		}
	});
	var takeWhile_1 = require_takeWhile();
	Object.defineProperty(exports, "takeWhile", {
		enumerable: true,
		get: function() {
			return takeWhile_1.takeWhile;
		}
	});
	var tap_1 = require_tap();
	Object.defineProperty(exports, "tap", {
		enumerable: true,
		get: function() {
			return tap_1.tap;
		}
	});
	var throttle_1 = require_throttle();
	Object.defineProperty(exports, "throttle", {
		enumerable: true,
		get: function() {
			return throttle_1.throttle;
		}
	});
	var throttleTime_1 = require_throttleTime();
	Object.defineProperty(exports, "throttleTime", {
		enumerable: true,
		get: function() {
			return throttleTime_1.throttleTime;
		}
	});
	var throwIfEmpty_1 = require_throwIfEmpty();
	Object.defineProperty(exports, "throwIfEmpty", {
		enumerable: true,
		get: function() {
			return throwIfEmpty_1.throwIfEmpty;
		}
	});
	var timeInterval_1 = require_timeInterval();
	Object.defineProperty(exports, "timeInterval", {
		enumerable: true,
		get: function() {
			return timeInterval_1.timeInterval;
		}
	});
	var timeout_2 = require_timeout();
	Object.defineProperty(exports, "timeout", {
		enumerable: true,
		get: function() {
			return timeout_2.timeout;
		}
	});
	var timeoutWith_1 = require_timeoutWith();
	Object.defineProperty(exports, "timeoutWith", {
		enumerable: true,
		get: function() {
			return timeoutWith_1.timeoutWith;
		}
	});
	var timestamp_1 = require_timestamp();
	Object.defineProperty(exports, "timestamp", {
		enumerable: true,
		get: function() {
			return timestamp_1.timestamp;
		}
	});
	var toArray_1 = require_toArray();
	Object.defineProperty(exports, "toArray", {
		enumerable: true,
		get: function() {
			return toArray_1.toArray;
		}
	});
	var window_1 = require_window();
	Object.defineProperty(exports, "window", {
		enumerable: true,
		get: function() {
			return window_1.window;
		}
	});
	var windowCount_1 = require_windowCount();
	Object.defineProperty(exports, "windowCount", {
		enumerable: true,
		get: function() {
			return windowCount_1.windowCount;
		}
	});
	var windowTime_1 = require_windowTime();
	Object.defineProperty(exports, "windowTime", {
		enumerable: true,
		get: function() {
			return windowTime_1.windowTime;
		}
	});
	var windowToggle_1 = require_windowToggle();
	Object.defineProperty(exports, "windowToggle", {
		enumerable: true,
		get: function() {
			return windowToggle_1.windowToggle;
		}
	});
	var windowWhen_1 = require_windowWhen();
	Object.defineProperty(exports, "windowWhen", {
		enumerable: true,
		get: function() {
			return windowWhen_1.windowWhen;
		}
	});
	var withLatestFrom_1 = require_withLatestFrom();
	Object.defineProperty(exports, "withLatestFrom", {
		enumerable: true,
		get: function() {
			return withLatestFrom_1.withLatestFrom;
		}
	});
	var zipAll_1 = require_zipAll();
	Object.defineProperty(exports, "zipAll", {
		enumerable: true,
		get: function() {
			return zipAll_1.zipAll;
		}
	});
	var zipWith_1 = require_zipWith();
	Object.defineProperty(exports, "zipWith", {
		enumerable: true,
		get: function() {
			return zipWith_1.zipWith;
		}
	});
}));
// node_modules/@angular/core/fesm2022/_pending_tasks-chunk.mjs
/**
* @license Angular v22.2.5
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var import_cjs = require_cjs();
var Version = class {
	full;
	major;
	minor;
	patch;
	constructor(full) {
		this.full = full;
		const parts = full.split(".");
		this.major = parts[0];
		this.minor = parts[1];
		this.patch = parts.slice(2).join(".");
	}
};
var VERSION = /* @__PURE__ */ new Version("22.2.5");
var DOC_PAGE_BASE_URL = (() => {
	const full = VERSION.full;
	return `https://${full.includes("-next") || full.includes("-rc") || full === "0.0.0-PLACEHOLDER" ? "next" : `v${VERSION.major}`}.angular.dev`;
})();
var ERROR_DETAILS_PAGE_BASE_URL = (() => {
	return `${DOC_PAGE_BASE_URL}/errors`;
})();
var XSS_SECURITY_URL = "https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss";
var RuntimeError = class extends Error {
	code;
	constructor(code, message) {
		super(formatRuntimeError(code, message));
		this.code = code;
	}
};
function formatRuntimeErrorCode(code) {
	return `NG0${Math.abs(code)}`;
}
function formatRuntimeError(code, message) {
	const fullCode = formatRuntimeErrorCode(code);
	let errorMessage = `${fullCode}${message ? ": " + message : ""}`;
	if (ngDevMode && code < 0) {
		const separator = !errorMessage.match(/[.,;!?\n]$/) ? "." : "";
		errorMessage = `${errorMessage}${separator} Find more at ${ERROR_DETAILS_PAGE_BASE_URL}/${fullCode}`;
	}
	return errorMessage;
}
function getClosureSafeProperty(objWithPropertyToExtract) {
	for (let key in objWithPropertyToExtract) if (objWithPropertyToExtract[key] === getClosureSafeProperty) return key;
	throw Error(typeof ngDevMode !== "undefined" && ngDevMode ? "Could not find renamed property on target object." : "");
}
function fillProperties(target, source) {
	for (const key in source) if (Object.hasOwn(source, key) && !Object.hasOwn(target, key)) target[key] = source[key];
}
function stringify(token) {
	if (typeof token === "string") return token;
	if (Array.isArray(token)) return `[${token.map(stringify).join(", ")}]`;
	if (token == null) return "" + token;
	const name = token.overriddenName || token.name;
	if (name) return `${name}`;
	const result = token.toString();
	if (result == null) return "" + result;
	const newLineIndex = result.indexOf("\n");
	return newLineIndex >= 0 ? result.slice(0, newLineIndex) : result;
}
function concatStringsWithSpace(before, after) {
	if (!before) return after || "";
	if (!after) return before;
	return `${before} ${after}`;
}
function truncateMiddle(str, maxLength = 100) {
	if (!str || maxLength < 1 || str.length <= maxLength) return str;
	if (maxLength == 1) return str.substring(0, 1) + "...";
	const halfLimit = Math.round(maxLength / 2);
	return str.substring(0, halfLimit) + "..." + str.substring(str.length - halfLimit);
}
var __forward_ref__ = getClosureSafeProperty({ __forward_ref__: getClosureSafeProperty });
function forwardRef(forwardRefFn) {
	forwardRefFn.__forward_ref__ = forwardRef;
	if (ngDevMode) forwardRefFn.toString = function() {
		return stringify(this());
	};
	return forwardRefFn;
}
function resolveForwardRef(type) {
	return isForwardRef(type) ? type() : type;
}
function isForwardRef(fn) {
	return typeof fn === "function" && Object.hasOwn(fn, __forward_ref__) && fn.__forward_ref__ === forwardRef;
}
function assertNumber(actual, msg) {
	if (!(typeof actual === "number")) throwError(msg, typeof actual, "number", "===");
}
function assertNumberInRange(actual, minInclusive, maxInclusive) {
	assertNumber(actual, "Expected a number");
	assertLessThanOrEqual(actual, maxInclusive, "Expected number to be less than or equal to");
	assertGreaterThanOrEqual(actual, minInclusive, "Expected number to be greater than or equal to");
}
function assertString(actual, msg) {
	if (!(typeof actual === "string")) throwError(msg, actual === null ? "null" : typeof actual, "string", "===");
}
function assertFunction(actual, msg) {
	if (!(typeof actual === "function")) throwError(msg, actual === null ? "null" : typeof actual, "function", "===");
}
function assertEqual(actual, expected, msg) {
	if (!(actual == expected)) throwError(msg, actual, expected, "==");
}
function assertNotEqual(actual, expected, msg) {
	if (!(actual != expected)) throwError(msg, actual, expected, "!=");
}
function assertSame(actual, expected, msg) {
	if (!(actual === expected)) throwError(msg, actual, expected, "===");
}
function assertNotSame(actual, expected, msg) {
	if (!(actual !== expected)) throwError(msg, actual, expected, "!==");
}
function assertLessThan(actual, expected, msg) {
	if (!(actual < expected)) throwError(msg, actual, expected, "<");
}
function assertLessThanOrEqual(actual, expected, msg) {
	if (!(actual <= expected)) throwError(msg, actual, expected, "<=");
}
function assertGreaterThan(actual, expected, msg) {
	if (!(actual > expected)) throwError(msg, actual, expected, ">");
}
function assertGreaterThanOrEqual(actual, expected, msg) {
	if (!(actual >= expected)) throwError(msg, actual, expected, ">=");
}
function assertNotDefined(actual, msg) {
	if (actual != null) throwError(msg, actual, null, "==");
}
function assertDefined(actual, msg) {
	if (actual == null) throwError(msg, actual, null, "!=");
}
function throwError(msg, actual, expected, comparison) {
	throw new Error(`ASSERTION ERROR: ${msg}` + (comparison == null ? "" : ` [Expected=> ${expected} ${comparison} ${actual} <=Actual]`));
}
function assertDomNode(node) {
	if (!(node instanceof Node)) throwError(`The provided value must be an instance of a DOM Node but got ${stringify(node)}`);
}
function assertElement(node) {
	if (!(node instanceof Element)) throwError(`The provided value must be an element but got ${stringify(node)}`);
}
function assertIndexInRange(arr, index) {
	assertDefined(arr, "Array must be defined.");
	const maxLen = arr.length;
	if (index < 0 || index >= maxLen) throwError(`Index expected to be less than ${maxLen} but got ${index}`);
}
function assertOneOf(value, ...validValues) {
	if (validValues.indexOf(value) !== -1) return true;
	throwError(`Expected value to be one of ${JSON.stringify(validValues)} but was ${JSON.stringify(value)}.`);
}
function assertNotReactive(fn) {
	if (getActiveConsumer() !== null) throwError(`${fn}() should never be called in a reactive context.`);
}
function ɵɵdefineInjectable(opts) {
	return {
		token: opts.token,
		providedIn: opts.providedIn || null,
		factory: opts.factory,
		value: void 0
	};
}
function ɵɵdefineInjector(options) {
	return {
		providers: options.providers || [],
		imports: options.imports || []
	};
}
function getInjectableDef(type) {
	return getOwnDefinition(type, NG_PROV_DEF);
}
function isInjectable(type) {
	return getInjectableDef(type) !== null;
}
function getOwnDefinition(type, field) {
	return Object.hasOwn(type, field) && type[field] || null;
}
function getInheritedInjectableDef(type) {
	const def = type?.[NG_PROV_DEF] ?? null;
	if (def) {
		ngDevMode && console.warn(`DEPRECATED: DI is instantiating a token "${type.name}" that inherits its @Injectable decorator but does not provide one itself.\nThis will become an error in a future version of Angular. Please add @Injectable() to the "${type.name}" class.`);
		return def;
	} else return null;
}
function getInjectorDef(type) {
	return type && Object.hasOwn(type, NG_INJ_DEF) ? type[NG_INJ_DEF] : null;
}
var NG_PROV_DEF = getClosureSafeProperty({ ɵprov: getClosureSafeProperty });
var NG_INJ_DEF = getClosureSafeProperty({ ɵinj: getClosureSafeProperty });
var InjectionToken = class {
	_desc;
	ngMetadataName = "InjectionToken";
	ɵprov;
	constructor(_desc, options) {
		this._desc = _desc;
		this.ɵprov = void 0;
		if (typeof options == "number") {
			(typeof ngDevMode === "undefined" || ngDevMode) && assertLessThan(options, 0, "Only negative numbers are supported here");
			this.__NG_ELEMENT_ID__ = options;
		} else if (options !== void 0) this.ɵprov = ɵɵdefineInjectable({
			token: this,
			providedIn: options.providedIn || "root",
			factory: options.factory
		});
	}
	get multi() {
		return this;
	}
	toString() {
		return `InjectionToken ${this._desc}`;
	}
};
var _injectorProfilerContext;
function getInjectorProfilerContext() {
	!ngDevMode && throwError("getInjectorProfilerContext should never be called in production mode");
	return _injectorProfilerContext;
}
function setInjectorProfilerContext(context) {
	!ngDevMode && throwError("setInjectorProfilerContext should never be called in production mode");
	const previous = _injectorProfilerContext;
	_injectorProfilerContext = context;
	return previous;
}
var injectorProfilerCallbacks = [];
var NOOP_PROFILER_REMOVAL = () => {};
function removeProfiler(profiler) {
	const profilerIdx = injectorProfilerCallbacks.indexOf(profiler);
	if (profilerIdx !== -1) injectorProfilerCallbacks.splice(profilerIdx, 1);
}
function setInjectorProfiler(injectorProfiler) {
	!ngDevMode && throwError("setInjectorProfiler should never be called in production mode");
	if (injectorProfiler !== null) {
		if (!injectorProfilerCallbacks.includes(injectorProfiler)) injectorProfilerCallbacks.push(injectorProfiler);
		return () => removeProfiler(injectorProfiler);
	} else {
		injectorProfilerCallbacks.length = 0;
		return NOOP_PROFILER_REMOVAL;
	}
}
function injectorProfiler(event) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	for (let i = 0; i < injectorProfilerCallbacks.length; i++) {
		const injectorProfilerCallback = injectorProfilerCallbacks[i];
		injectorProfilerCallback(event);
	}
}
function emitProviderConfiguredEvent(eventProvider, isViewProvider = false) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	let token;
	if (typeof eventProvider === "function") token = eventProvider;
	else if (eventProvider instanceof InjectionToken) token = eventProvider;
	else token = resolveForwardRef(eventProvider.provide);
	let provider = eventProvider;
	if (eventProvider instanceof InjectionToken) provider = eventProvider.ɵprov || eventProvider;
	injectorProfiler({
		type: 2,
		context: getInjectorProfilerContext(),
		providerRecord: {
			token,
			provider,
			isViewProvider
		}
	});
}
function emitInjectorToCreateInstanceEvent(token) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 5,
		context: getInjectorProfilerContext(),
		token
	});
}
function emitInstanceCreatedByInjectorEvent(instance) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 1,
		context: getInjectorProfilerContext(),
		instance: { value: instance }
	});
}
function emitInjectEvent(token, value, flags) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 0,
		context: getInjectorProfilerContext(),
		service: {
			token,
			value,
			flags
		}
	});
}
function emitEffectCreatedEvent(effect) {
	!ngDevMode && throwError("Injector profiler should never be called in production mode");
	injectorProfiler({
		type: 3,
		context: getInjectorProfilerContext(),
		effect
	});
}
function runInInjectorProfilerContext(injector, token, callback) {
	!ngDevMode && throwError("runInInjectorProfilerContext should never be called in production mode");
	const prevInjectContext = setInjectorProfilerContext({
		injector,
		token
	});
	try {
		callback();
	} finally {
		setInjectorProfilerContext(prevInjectContext);
	}
}
function isEnvironmentProviders(value) {
	return value && !!value.ɵproviders;
}
var NG_COMP_DEF = getClosureSafeProperty({ ɵcmp: getClosureSafeProperty });
var NG_DIR_DEF = getClosureSafeProperty({ ɵdir: getClosureSafeProperty });
var NG_PIPE_DEF = getClosureSafeProperty({ ɵpipe: getClosureSafeProperty });
var NG_MOD_DEF = getClosureSafeProperty({ ɵmod: getClosureSafeProperty });
var NG_FACTORY_DEF = getClosureSafeProperty({ ɵfac: getClosureSafeProperty });
var NG_ELEMENT_ID = getClosureSafeProperty({ __NG_ELEMENT_ID__: getClosureSafeProperty });
var NG_ENV_ID = getClosureSafeProperty({ __NG_ENV_ID__: getClosureSafeProperty });
function getNgModuleDef(type) {
	assertTypeDefined(type, "@NgModule");
	return type[NG_MOD_DEF] || null;
}
function getNgModuleDefOrThrow(type) {
	const ngModuleDef = getNgModuleDef(type);
	if (!ngModuleDef) throw new RuntimeError(915, (typeof ngDevMode === "undefined" || ngDevMode) && `Type ${stringify(type)} does not have 'ɵmod' property.`);
	return ngModuleDef;
}
function getComponentDef(type) {
	assertTypeDefined(type, "@Component");
	return type[NG_COMP_DEF] || null;
}
function getDirectiveDefOrThrow(type) {
	const def = getDirectiveDef(type);
	if (!def) throw new RuntimeError(916, (typeof ngDevMode === "undefined" || ngDevMode) && `Type ${stringify(type)} does not have 'ɵdir' property.`);
	return def;
}
function getDirectiveDef(type) {
	assertTypeDefined(type, "@Directive");
	return type[NG_DIR_DEF] || null;
}
function getPipeDef(type) {
	assertTypeDefined(type, "@Pipe");
	return type[NG_PIPE_DEF] || null;
}
function assertTypeDefined(type, symbolType) {
	if (type == null) throw new RuntimeError(-919, (typeof ngDevMode === "undefined" || ngDevMode) && `Cannot read ${symbolType} metadata. This can indicate a runtime circular dependency in your app that needs to be resolved.`);
}
function isStandalone(type) {
	const def = getComponentDef(type) || getDirectiveDef(type) || getPipeDef(type);
	return def !== null && def.standalone;
}
function renderStringify(value) {
	if (typeof value === "string") return value;
	if (value == null) return "";
	return String(value);
}
function stringifyForError(value) {
	if (typeof value === "function") return value.name || value.toString();
	if (typeof value === "object" && value != null && typeof value.type === "function") return value.type.name || value.type.toString();
	return renderStringify(value);
}
function debugStringifyTypeForError(type) {
	const componentDef = getComponentDef(type);
	if (componentDef !== null && componentDef.debugInfo) return stringifyTypeFromDebugInfo(componentDef.debugInfo);
	return stringifyForError(type);
}
function stringifyTypeFromDebugInfo(debugInfo) {
	if (!debugInfo.filePath || !debugInfo.lineNumber) return debugInfo.className;
	else return `${debugInfo.className} (at ${debugInfo.filePath}:${debugInfo.lineNumber})`;
}
var NG_RUNTIME_ERROR_CODE = getClosureSafeProperty({ "ngErrorCode": getClosureSafeProperty });
var NG_RUNTIME_ERROR_MESSAGE = getClosureSafeProperty({ "ngErrorMessage": getClosureSafeProperty });
var NG_TOKEN_PATH = getClosureSafeProperty({ "ngTokenPath": getClosureSafeProperty });
function cyclicDependencyError(token, path) {
	return createRuntimeError(ngDevMode ? `Circular dependency detected for \`${token}\`.` : "", -200, path);
}
function cyclicDependencyErrorWithDetails(token, path) {
	return augmentRuntimeError(cyclicDependencyError(token, path), null);
}
function throwMixedMultiProviderError() {
	throw new Error(`Cannot mix multi providers and regular providers`);
}
function throwInvalidProviderError(ngModuleType, providers, provider) {
	if (ngModuleType && providers) {
		const providerDetail = providers.map((v) => v == provider ? "?" + provider + "?" : "...");
		throw new Error(`Invalid provider for the NgModule '${stringify(ngModuleType)}' - only instances of Provider and Type are allowed, got: [${providerDetail.join(", ")}]`);
	} else if (isEnvironmentProviders(provider)) {
		if (provider.ɵfromNgModule) throw new RuntimeError(-207, `Invalid providers from 'importProvidersFrom' present in a non-environment injector. 'importProvidersFrom' can't be used for component providers.`);
		else throw new RuntimeError(-207, `Invalid providers present in a non-environment injector. 'EnvironmentProviders' can't be used for component providers.`);
	} else throw new Error("Invalid provider");
}
function throwProviderNotFoundError(token, injectorName) {
	throw new RuntimeError(-201, ngDevMode && `No provider for ${stringifyForError(token)} found${injectorName ? ` in ${injectorName}` : ""}`);
}
function prependTokenToDependencyPath(error, token) {
	error[NG_TOKEN_PATH] ??= [];
	const currentPath = error[NG_TOKEN_PATH];
	let pathStr;
	if (typeof token === "object" && "multi" in token && token?.multi === true) {
		assertDefined(token.provide, "Token with multi: true should have a provide property");
		pathStr = stringifyForError(token.provide);
	} else pathStr = stringifyForError(token);
	if (currentPath[0] !== pathStr) error[NG_TOKEN_PATH].unshift(pathStr);
}
function augmentRuntimeError(error, source) {
	const tokenPath = error[NG_TOKEN_PATH];
	const errorCode = error[NG_RUNTIME_ERROR_CODE];
	error.message = formatErrorMessage(error[NG_RUNTIME_ERROR_MESSAGE] || error.message, errorCode, tokenPath, source);
	return error;
}
function createRuntimeError(message, code, path) {
	const error = new RuntimeError(code, message);
	error[NG_RUNTIME_ERROR_CODE] = code;
	error[NG_RUNTIME_ERROR_MESSAGE] = message;
	if (path) error[NG_TOKEN_PATH] = path;
	return error;
}
function getRuntimeErrorCode(error) {
	return error[NG_RUNTIME_ERROR_CODE];
}
function formatErrorMessage(text, code, path = [], source = null) {
	let pathDetails = "";
	if (path && path.length > 1) pathDetails = ` Path: ${path.join(" -> ")}.`;
	return formatRuntimeError(code, `${text}${source ? ` Source: ${source}.` : ""}${pathDetails}`);
}
var _injectImplementation;
function getInjectImplementation() {
	return _injectImplementation;
}
function setInjectImplementation(impl) {
	const previous = _injectImplementation;
	_injectImplementation = impl;
	return previous;
}
function injectRootLimpMode(token, notFoundValue, flags) {
	const injectableDef = getInjectableDef(token);
	if (injectableDef && injectableDef.providedIn == "root") return injectableDef.value === void 0 ? injectableDef.value = injectableDef.factory() : injectableDef.value;
	if (flags & 8) return null;
	if (notFoundValue !== void 0) return notFoundValue;
	throwProviderNotFoundError(token, typeof ngDevMode !== "undefined" && ngDevMode ? "Injector" : "");
}
function assertInjectImplementationNotEqual(fn) {
	ngDevMode && assertNotEqual(_injectImplementation, fn, "Calling ɵɵinject would cause infinite recursion");
}
var _global = globalThis;
function ngDevModeResetPerfCounters() {
	const locationString = typeof location !== "undefined" ? location.toString() : "";
	const newCounters = {
		hydratedNodes: 0,
		hydratedComponents: 0,
		dehydratedViewsRemoved: 0,
		dehydratedViewsCleanupRuns: 0,
		componentsSkippedHydration: 0,
		deferBlocksWithIncrementalHydration: 0
	};
	if (!(locationString.indexOf("ngDevMode=false") === -1)) _global["ngDevMode"] = false;
	else {
		if (typeof _global["ngDevMode"] !== "object") _global["ngDevMode"] = {};
		Object.assign(_global["ngDevMode"], newCounters);
	}
	return newCounters;
}
function initNgDevMode() {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		if (typeof ngDevMode !== "object" || Object.keys(ngDevMode).length === 0) ngDevModeResetPerfCounters();
		return typeof ngDevMode !== "undefined" && !!ngDevMode;
	}
	return false;
}
var THROW_IF_NOT_FOUND = {};
var DI_DECORATOR_FLAG = "__NG_DI_FLAG__";
var RetrievingInjector = class {
	injector;
	constructor(injector) {
		this.injector = injector;
	}
	retrieve(token, options) {
		const flags = convertToBitFlags(options) || 0;
		try {
			return this.injector.get(token, flags & 8 ? null : THROW_IF_NOT_FOUND, flags);
		} catch (e) {
			if (isNotFound(e)) return e;
			throw e;
		}
	}
};
function injectInjectorOnly(token, flags = 0) {
	const currentInjector = getCurrentInjector();
	if (currentInjector === void 0) throw new RuntimeError(-203, ngDevMode && `The \`${stringify(token)}\` token injection failed. \`inject()\` function must be called from an injection context such as a constructor, a factory function, a field initializer, or a function used with \`runInInjectionContext\`.`);
	else if (currentInjector === null) return injectRootLimpMode(token, void 0, flags);
	else {
		const options = convertToInjectOptions(flags);
		const value = currentInjector.retrieve(token, options);
		ngDevMode && emitInjectEvent(token, value, flags);
		if (isNotFound(value)) {
			if (options.optional) return null;
			throw value;
		}
		return value;
	}
}
function ɵɵinject(token, flags = 0) {
	return (getInjectImplementation() || injectInjectorOnly)(resolveForwardRef(token), flags);
}
function ɵɵinvalidFactoryDep(index) {
	throw new RuntimeError(202, ngDevMode && `This constructor is not compatible with Angular Dependency Injection because its dependency at index ${index} of the parameter list is invalid.
This can happen if the dependency type is a primitive like a string or if an ancestor of this class is missing an Angular decorator.

Please check that 1) the type for the parameter at index ${index} is correct and 2) the correct Angular decorators are defined for this class and its ancestors.`);
}
function inject(token, options) {
	return ɵɵinject(token, convertToBitFlags(options));
}
function convertToBitFlags(flags) {
	if (typeof flags === "undefined" || typeof flags === "number") return flags;
	return 0 | (flags.optional && 8) | (flags.host && 1) | (flags.self && 2) | (flags.skipSelf && 4);
}
function convertToInjectOptions(flags) {
	return {
		optional: !!(flags & 8),
		host: !!(flags & 1),
		self: !!(flags & 2),
		skipSelf: !!(flags & 4)
	};
}
function injectArgs(types) {
	const args = [];
	for (let i = 0; i < types.length; i++) {
		const arg = resolveForwardRef(types[i]);
		if (Array.isArray(arg)) {
			if (arg.length === 0) throw new RuntimeError(900, ngDevMode && "Arguments array must have arguments.");
			let type = void 0;
			let flags = 0;
			for (let j = 0; j < arg.length; j++) {
				const meta = arg[j];
				const flag = getInjectFlag(meta);
				if (typeof flag === "number") {
					if (flag === -1) type = meta.token;
					else flags |= flag;
				} else type = meta;
			}
			args.push(ɵɵinject(type, flags));
		} else args.push(ɵɵinject(arg));
	}
	return args;
}
function attachInjectFlag(decorator, flag) {
	decorator[DI_DECORATOR_FLAG] = flag;
	decorator.prototype[DI_DECORATOR_FLAG] = flag;
	return decorator;
}
function getInjectFlag(token) {
	return token[DI_DECORATOR_FLAG];
}
function getFactoryDef(type, throwNotFound) {
	const hasFactoryDef = Object.hasOwn(type, NG_FACTORY_DEF);
	if (!hasFactoryDef && throwNotFound === true && ngDevMode) throw new Error(`Type ${stringify(type)} does not have 'ɵfac' property.`);
	return hasFactoryDef ? type[NG_FACTORY_DEF] : null;
}
function arrayEquals(a, b, identityAccessor) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) {
		let valueA = a[i];
		let valueB = b[i];
		if (identityAccessor) {
			valueA = identityAccessor(valueA);
			valueB = identityAccessor(valueB);
		}
		if (valueB !== valueA) return false;
	}
	return true;
}
function flatten(list) {
	return list.flat(Number.POSITIVE_INFINITY);
}
function deepForEach(input, fn) {
	input.forEach((value) => Array.isArray(value) ? deepForEach(value, fn) : fn(value));
}
function addToArray(arr, index, value) {
	if (index >= arr.length) arr.push(value);
	else arr.splice(index, 0, value);
}
function removeFromArray(arr, index) {
	if (index >= arr.length - 1) return arr.pop();
	else return arr.splice(index, 1)[0];
}
function newArray(size, value) {
	const list = [];
	for (let i = 0; i < size; i++) list.push(value);
	return list;
}
function arraySplice(array, index, count) {
	const length = array.length - count;
	while (index < length) {
		array[index] = array[index + count];
		index++;
	}
	while (count--) array.pop();
}
function arrayInsert2(array, index, value1, value2) {
	ngDevMode && assertLessThanOrEqual(index, array.length, "Can't insert past array end.");
	let end = array.length;
	if (end == index) array.push(value1, value2);
	else if (end === 1) {
		array.push(value2, array[0]);
		array[0] = value1;
	} else {
		end--;
		array.push(array[end - 1], array[end]);
		while (end > index) {
			const previousEnd = end - 2;
			array[end] = array[previousEnd];
			end--;
		}
		array[index] = value1;
		array[index + 1] = value2;
	}
}
function keyValueArraySet(keyValueArray, key, value) {
	let index = keyValueArrayIndexOf(keyValueArray, key);
	if (index >= 0) keyValueArray[index | 1] = value;
	else {
		index = ~index;
		arrayInsert2(keyValueArray, index, key, value);
	}
	return index;
}
function keyValueArrayGet(keyValueArray, key) {
	const index = keyValueArrayIndexOf(keyValueArray, key);
	if (index >= 0) return keyValueArray[index | 1];
}
function keyValueArrayIndexOf(keyValueArray, key) {
	return _arrayIndexOfSorted(keyValueArray, key, 1);
}
function _arrayIndexOfSorted(array, value, shift) {
	ngDevMode && assertEqual(Array.isArray(array), true, "Expecting an array");
	let start = 0;
	let end = array.length >> shift;
	while (end !== start) {
		const middle = start + (end - start >> 1);
		const current = array[middle << shift];
		if (value === current) return middle << shift;
		else if (current > value) end = middle;
		else start = middle + 1;
	}
	return ~(end << shift);
}
var EMPTY_OBJ = {};
var EMPTY_ARRAY = [];
if ((typeof ngDevMode === "undefined" || ngDevMode) && initNgDevMode()) {
	Object.freeze(EMPTY_OBJ);
	Object.freeze(EMPTY_ARRAY);
}
var ENVIRONMENT_INITIALIZER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ENVIRONMENT_INITIALIZER" : "");
var INJECTOR$1 = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "INJECTOR" : "", -1);
var INJECTOR_DEF_TYPES = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "INJECTOR_DEF_TYPES" : "");
var NullInjector = class {
	get(token, notFoundValue = THROW_IF_NOT_FOUND) {
		if (notFoundValue === THROW_IF_NOT_FOUND) {
			const error = createRuntimeError(ngDevMode ? `No provider found for \`${stringify(token)}\`.` : "", -201);
			error.name = "ɵNotFound";
			throw error;
		}
		return notFoundValue;
	}
};
function makeEnvironmentProviders(providers) {
	return { ɵproviders: providers };
}
function provideEnvironmentInitializer(initializerFn) {
	return makeEnvironmentProviders([{
		provide: ENVIRONMENT_INITIALIZER,
		multi: true,
		useValue: initializerFn
	}]);
}
function importProvidersFrom(...sources) {
	return {
		ɵproviders: internalImportProvidersFrom(true, sources),
		ɵfromNgModule: true
	};
}
function internalImportProvidersFrom(checkForStandaloneCmp, ...sources) {
	const providersOut = [];
	const dedup = /* @__PURE__ */ new Set();
	let injectorTypesWithProviders;
	const collectProviders = (provider) => {
		providersOut.push(provider);
	};
	deepForEach(sources, (source) => {
		if ((typeof ngDevMode === "undefined" || ngDevMode) && checkForStandaloneCmp) {
			if (getComponentDef(source)?.standalone) throw new RuntimeError(800, `Importing providers supports NgModule or ModuleWithProviders but got a standalone component "${stringifyForError(source)}"`);
		}
		const internalSource = source;
		if (walkProviderTree(internalSource, collectProviders, [], dedup)) {
			injectorTypesWithProviders ||= [];
			injectorTypesWithProviders.push(internalSource);
		}
	});
	if (injectorTypesWithProviders !== void 0) processInjectorTypesWithProviders(injectorTypesWithProviders, collectProviders);
	return providersOut;
}
function processInjectorTypesWithProviders(typesWithProviders, visitor) {
	for (let i = 0; i < typesWithProviders.length; i++) {
		const { ngModule, providers } = typesWithProviders[i];
		deepForEachProvider(providers, (provider) => {
			ngDevMode && validateProvider(provider, providers || EMPTY_ARRAY, ngModule);
			visitor(provider, ngModule);
		});
	}
}
function walkProviderTree(container, visitor, parents, dedup) {
	container = resolveForwardRef(container);
	if (!container) return false;
	let defType = null;
	let injDef = getInjectorDef(container);
	const cmpDef = !injDef && getComponentDef(container);
	if (!injDef && !cmpDef) {
		const ngModule = container.ngModule;
		injDef = getInjectorDef(ngModule);
		if (injDef) defType = ngModule;
		else return false;
	} else if (cmpDef && !cmpDef.standalone) return false;
	else defType = container;
	if (ngDevMode && parents.indexOf(defType) !== -1) {
		const defName = stringify(defType);
		throw cyclicDependencyErrorWithDetails(defName, parents.map(stringify).concat(defName));
	}
	const isDuplicate = dedup.has(defType);
	if (cmpDef) {
		if (isDuplicate) return false;
		dedup.add(defType);
		if (cmpDef.dependencies) {
			const deps = typeof cmpDef.dependencies === "function" ? cmpDef.dependencies() : cmpDef.dependencies;
			for (const dep of deps) walkProviderTree(dep, visitor, parents, dedup);
		}
	} else if (injDef) {
		if (injDef.imports != null && !isDuplicate) {
			ngDevMode && parents.push(defType);
			dedup.add(defType);
			let importTypesWithProviders;
			try {
				deepForEach(injDef.imports, (imported) => {
					if (walkProviderTree(imported, visitor, parents, dedup)) {
						importTypesWithProviders ||= [];
						importTypesWithProviders.push(imported);
					}
				});
			} finally {
				ngDevMode && parents.pop();
			}
			if (importTypesWithProviders !== void 0) processInjectorTypesWithProviders(importTypesWithProviders, visitor);
		}
		if (!isDuplicate) {
			const factory = getFactoryDef(defType) || (() => new defType());
			visitor({
				provide: defType,
				useFactory: factory,
				deps: EMPTY_ARRAY
			}, defType);
			visitor({
				provide: INJECTOR_DEF_TYPES,
				useValue: defType,
				multi: true
			}, defType);
			visitor({
				provide: ENVIRONMENT_INITIALIZER,
				useValue: () => ɵɵinject(defType),
				multi: true
			}, defType);
		}
		const defProviders = injDef.providers;
		if (defProviders != null && !isDuplicate) {
			const injectorType = container;
			deepForEachProvider(defProviders, (provider) => {
				ngDevMode && validateProvider(provider, defProviders, injectorType);
				visitor(provider, injectorType);
			});
		}
	} else return false;
	return defType !== container && container.providers !== void 0;
}
function validateProvider(provider, providers, containerType) {
	if (isTypeProvider(provider) || isValueProvider(provider) || isFactoryProvider(provider) || isExistingProvider(provider)) return;
	if (!resolveForwardRef(provider && (provider.useClass || provider.provide))) throwInvalidProviderError(containerType, providers, provider);
}
function deepForEachProvider(providers, fn) {
	for (let provider of providers) {
		if (isEnvironmentProviders(provider)) provider = provider.ɵproviders;
		if (Array.isArray(provider)) deepForEachProvider(provider, fn);
		else fn(provider);
	}
}
var USE_VALUE = getClosureSafeProperty({
	provide: String,
	useValue: getClosureSafeProperty
});
function isValueProvider(value) {
	return value !== null && typeof value == "object" && USE_VALUE in value;
}
function isExistingProvider(value) {
	return !!(value && value.useExisting);
}
function isFactoryProvider(value) {
	return !!(value && value.useFactory);
}
function isTypeProvider(value) {
	return typeof value === "function";
}
function isClassProvider(value) {
	return !!value.useClass;
}
var INJECTOR_SCOPE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Set Injector scope." : "");
var NOT_YET = {};
var CIRCULAR = {};
var NULL_INJECTOR = void 0;
function getNullInjector() {
	if (NULL_INJECTOR === void 0) NULL_INJECTOR = new NullInjector();
	return NULL_INJECTOR;
}
var EnvironmentInjector = class {};
var R3Injector = class extends EnvironmentInjector {
	parent;
	source;
	scopes;
	records = /* @__PURE__ */ new Map();
	_ngOnDestroyHooks = /* @__PURE__ */ new Set();
	_onDestroyHooks = [];
	get destroyed() {
		return this._destroyed;
	}
	_destroyed = false;
	injectorDefTypes;
	constructor(providers, parent, source, scopes) {
		super();
		this.parent = parent;
		this.source = source;
		this.scopes = scopes;
		forEachSingleProvider(providers, (provider) => this.processProvider(provider));
		this.records.set(INJECTOR$1, makeRecord(void 0, this));
		if (scopes.has("environment")) this.records.set(EnvironmentInjector, makeRecord(void 0, this));
		const record = this.records.get(INJECTOR_SCOPE);
		if (record != null && typeof record.value === "string") this.scopes.add(record.value);
		this.injectorDefTypes = new Set(this.get(INJECTOR_DEF_TYPES, EMPTY_ARRAY, { self: true }));
	}
	retrieve(token, options) {
		const flags = convertToBitFlags(options) || 0;
		try {
			return this.get(token, THROW_IF_NOT_FOUND, flags);
		} catch (e) {
			if (isNotFound(e)) return e;
			throw e;
		}
	}
	destroy() {
		assertNotDestroyed(this);
		this._destroyed = true;
		const prevConsumer = setActiveConsumer(null);
		try {
			for (const service of this._ngOnDestroyHooks) service.ngOnDestroy();
			const onDestroyHooks = this._onDestroyHooks;
			this._onDestroyHooks = [];
			for (const hook of onDestroyHooks) hook();
		} finally {
			this.records.clear();
			this._ngOnDestroyHooks.clear();
			this.injectorDefTypes.clear();
			setActiveConsumer(prevConsumer);
		}
	}
	onDestroy(callback) {
		assertNotDestroyed(this);
		this._onDestroyHooks.push(callback);
		return () => this.removeOnDestroy(callback);
	}
	runInContext(fn) {
		assertNotDestroyed(this);
		const previousInjector = setCurrentInjector(this);
		const previousInjectImplementation = setInjectImplementation(void 0);
		let prevInjectContext;
		if (ngDevMode) prevInjectContext = setInjectorProfilerContext({
			injector: this,
			token: null
		});
		try {
			return fn();
		} finally {
			setCurrentInjector(previousInjector);
			setInjectImplementation(previousInjectImplementation);
			ngDevMode && setInjectorProfilerContext(prevInjectContext);
		}
	}
	get(token, notFoundValue = THROW_IF_NOT_FOUND, options) {
		assertNotDestroyed(this);
		if (Object.hasOwn(token, NG_ENV_ID)) return token[NG_ENV_ID](this);
		const flags = convertToBitFlags(options);
		let prevInjectContext;
		if (ngDevMode) prevInjectContext = setInjectorProfilerContext({
			injector: this,
			token
		});
		const previousInjector = setCurrentInjector(this);
		const previousInjectImplementation = setInjectImplementation(void 0);
		try {
			if (!(flags & 4)) {
				let record = this.records.get(token);
				if (record === void 0) {
					const def = couldBeInjectableType(token) && getInjectableDef(token);
					if (def && this.injectableDefInScope(def)) {
						if (ngDevMode) runInInjectorProfilerContext(this, token, () => {
							emitProviderConfiguredEvent(token);
						});
						record = makeRecord(injectableDefOrInjectorDefFactory(token), NOT_YET);
					} else record = null;
					this.records.set(token, record);
				}
				if (record != null) return this.hydrate(token, record, flags);
			}
			const nextInjector = !(flags & 2) ? this.parent : getNullInjector();
			notFoundValue = flags & 8 && notFoundValue === THROW_IF_NOT_FOUND ? null : notFoundValue;
			return nextInjector.get(token, notFoundValue);
		} catch (error) {
			const errorCode = getRuntimeErrorCode(error);
			if (errorCode === -200 || errorCode === -201) {
				if (ngDevMode) {
					prependTokenToDependencyPath(error, token);
					if (previousInjector) throw error;
					else throw augmentRuntimeError(error, this.source);
				} else throw new RuntimeError(errorCode, null);
			} else throw error;
		} finally {
			setInjectImplementation(previousInjectImplementation);
			setCurrentInjector(previousInjector);
			ngDevMode && setInjectorProfilerContext(prevInjectContext);
		}
	}
	resolveInjectorInitializers() {
		const prevConsumer = setActiveConsumer(null);
		const previousInjector = setCurrentInjector(this);
		const previousInjectImplementation = setInjectImplementation(void 0);
		let prevInjectContext;
		if (ngDevMode) prevInjectContext = setInjectorProfilerContext({
			injector: this,
			token: null
		});
		try {
			const initializers = this.get(ENVIRONMENT_INITIALIZER, EMPTY_ARRAY, { self: true });
			if (ngDevMode && !Array.isArray(initializers)) throw new RuntimeError(-209, `Unexpected type of the \`ENVIRONMENT_INITIALIZER\` token value (expected an array, but got ${typeof initializers}). Please check that the \`ENVIRONMENT_INITIALIZER\` token is configured as a \`multi: true\` provider.`);
			for (const initializer of initializers) initializer();
		} finally {
			setCurrentInjector(previousInjector);
			setInjectImplementation(previousInjectImplementation);
			ngDevMode && setInjectorProfilerContext(prevInjectContext);
			setActiveConsumer(prevConsumer);
		}
	}
	toString() {
		if (ngDevMode) {
			const tokens = [];
			const records = this.records;
			for (const token of records.keys()) tokens.push(stringify(token));
			return `R3Injector[${tokens.join(", ")}]`;
		}
		return "R3Injector[...]";
	}
	processProvider(provider) {
		provider = resolveForwardRef(provider);
		let token = isTypeProvider(provider) ? provider : resolveForwardRef(provider && provider.provide);
		const record = providerToRecord(provider);
		if (ngDevMode) runInInjectorProfilerContext(this, token, () => {
			if (isValueProvider(provider)) {
				emitInjectorToCreateInstanceEvent(token);
				emitInstanceCreatedByInjectorEvent(provider.useValue);
			}
			emitProviderConfiguredEvent(provider);
		});
		if (!isTypeProvider(provider) && provider.multi === true) {
			let multiRecord = this.records.get(token);
			if (multiRecord) {
				if (ngDevMode && multiRecord.multi === void 0) throwMixedMultiProviderError();
			} else {
				multiRecord = makeRecord(void 0, NOT_YET, true);
				multiRecord.factory = () => injectArgs(multiRecord.multi);
				this.records.set(token, multiRecord);
			}
			token = provider;
			multiRecord.multi.push(provider);
		} else if (ngDevMode) {
			const existing = this.records.get(token);
			if (existing && existing.multi !== void 0) throwMixedMultiProviderError();
		}
		this.records.set(token, record);
	}
	hydrate(token, record, flags) {
		const prevConsumer = setActiveConsumer(null);
		try {
			if (record.value === CIRCULAR) throw cyclicDependencyError(ngDevMode ? stringify(token) : "");
			else if (record.value === NOT_YET) {
				record.value = CIRCULAR;
				if (ngDevMode) runInInjectorProfilerContext(this, token, () => {
					emitInjectorToCreateInstanceEvent(token);
					record.value = record.factory(void 0, flags);
					emitInstanceCreatedByInjectorEvent(record.value);
				});
				else record.value = record.factory(void 0, flags);
			}
			if (typeof record.value === "object" && record.value && hasOnDestroy(record.value)) this._ngOnDestroyHooks.add(record.value);
			return record.value;
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
	injectableDefInScope(def) {
		if (!def.providedIn) return false;
		const providedIn = resolveForwardRef(def.providedIn);
		if (typeof providedIn === "string") return providedIn === "any" || this.scopes.has(providedIn);
		else return this.injectorDefTypes.has(providedIn);
	}
	removeOnDestroy(callback) {
		const destroyCBIdx = this._onDestroyHooks.indexOf(callback);
		if (destroyCBIdx !== -1) this._onDestroyHooks.splice(destroyCBIdx, 1);
	}
};
function injectableDefOrInjectorDefFactory(token) {
	const injectableDef = getInjectableDef(token);
	const factory = injectableDef !== null ? injectableDef.factory : getFactoryDef(token);
	if (factory !== null) return factory;
	if (token instanceof InjectionToken) throw new RuntimeError(-204, ngDevMode && `Token ${stringify(token)} is missing a ɵprov definition.`);
	if (token instanceof Function) return getUndecoratedInjectableFactory(token);
	throw new RuntimeError(-204, ngDevMode && "unreachable");
}
function getUndecoratedInjectableFactory(token) {
	const paramLength = token.length;
	if (paramLength > 0) throw new RuntimeError(-204, ngDevMode && `Can't resolve all parameters for ${stringify(token)}: (${newArray(paramLength, "?").join(", ")}).`);
	const inheritedInjectableDef = getInheritedInjectableDef(token);
	if (inheritedInjectableDef !== null) return () => inheritedInjectableDef.factory(token);
	else return () => new token();
}
function providerToRecord(provider) {
	if (isValueProvider(provider)) return makeRecord(void 0, provider.useValue);
	else return makeRecord(providerToFactory(provider), NOT_YET);
}
function providerToFactory(provider, ngModuleType, providers) {
	let factory = void 0;
	if (ngDevMode && isEnvironmentProviders(provider)) throwInvalidProviderError(void 0, providers, provider);
	if (isTypeProvider(provider)) {
		const unwrappedProvider = resolveForwardRef(provider);
		return getFactoryDef(unwrappedProvider) || injectableDefOrInjectorDefFactory(unwrappedProvider);
	} else if (isValueProvider(provider)) factory = () => resolveForwardRef(provider.useValue);
	else if (isFactoryProvider(provider)) factory = () => provider.useFactory(...injectArgs(provider.deps || []));
	else if (isExistingProvider(provider)) factory = (_, flags) => ɵɵinject(resolveForwardRef(provider.useExisting), flags !== void 0 && flags & 8 ? 8 : void 0);
	else {
		const classRef = resolveForwardRef(provider && (provider.useClass || provider.provide));
		if (ngDevMode && !classRef) throwInvalidProviderError(ngModuleType, providers, provider);
		if (hasDeps(provider)) factory = () => new classRef(...injectArgs(provider.deps));
		else return getFactoryDef(classRef) || injectableDefOrInjectorDefFactory(classRef);
	}
	return factory;
}
function assertNotDestroyed(injector) {
	if (injector.destroyed) throw new RuntimeError(-205, ngDevMode && "Injector has already been destroyed.");
}
function makeRecord(factory, value, multi = false) {
	return {
		factory,
		value,
		multi: multi ? [] : void 0
	};
}
function hasDeps(value) {
	return !!value.deps;
}
function hasOnDestroy(value) {
	return value !== null && typeof value === "object" && typeof value.ngOnDestroy === "function";
}
function couldBeInjectableType(value) {
	return typeof value === "function" || typeof value === "object" && value.ngMetadataName === "InjectionToken";
}
function forEachSingleProvider(providers, fn) {
	for (const provider of providers) if (Array.isArray(provider)) forEachSingleProvider(provider, fn);
	else if (provider && isEnvironmentProviders(provider)) forEachSingleProvider(provider.ɵproviders, fn);
	else fn(provider);
}
function runInInjectionContext(injector, fn) {
	let internalInjector;
	if (injector instanceof R3Injector) {
		assertNotDestroyed(injector);
		internalInjector = injector;
	} else internalInjector = new RetrievingInjector(injector);
	let prevInjectorProfilerContext;
	if (ngDevMode) prevInjectorProfilerContext = setInjectorProfilerContext({
		injector,
		token: null
	});
	const prevInjector = setCurrentInjector(internalInjector);
	const previousInjectImplementation = setInjectImplementation(void 0);
	try {
		return fn();
	} finally {
		setCurrentInjector(prevInjector);
		ngDevMode && setInjectorProfilerContext(prevInjectorProfilerContext);
		setInjectImplementation(previousInjectImplementation);
	}
}
function isInInjectionContext() {
	return getInjectImplementation() !== void 0 || getCurrentInjector() != null;
}
function assertInInjectionContext(debugFn) {
	if (!isInInjectionContext()) throw new RuntimeError(-203, ngDevMode && debugFn.name + "() can only be used within an injection context such as a constructor, a factory function, a field initializer, or a function used with `runInInjectionContext`");
}
var TYPE = 1;
var CONTAINER_HEADER_OFFSET = 10;
function isLView(value) {
	return Array.isArray(value) && typeof value[TYPE] === "object";
}
function isLContainer(value) {
	return Array.isArray(value) && value[TYPE] === true;
}
function isContentQueryHost(tNode) {
	return (tNode.flags & 4) !== 0;
}
function isComponentHost(tNode) {
	return tNode.componentOffset > -1;
}
function isDirectiveHost(tNode) {
	return (tNode.flags & 1) === 1;
}
function isComponentDef(def) {
	return !!def.template;
}
function isRootView(target) {
	return (target[2] & 512) !== 0;
}
function isProjectionTNode(tNode) {
	return (tNode.type & 16) === 16;
}
function hasI18n(lView) {
	return (lView[2] & 32) === 32;
}
function isDestroyed(lView) {
	return (lView[2] & 256) === 256;
}
function assertTNodeForLView(tNode, lView) {
	assertTNodeForTView(tNode, lView[1]);
}
function assertTNodeCreationIndex(lView, index) {
	const adjustedIndex = index + 28;
	assertIndexInRange(lView, adjustedIndex);
	assertLessThan(adjustedIndex, lView[1].bindingStartIndex, "TNodes should be created before any bindings");
}
function assertTNodeForTView(tNode, tView) {
	assertTNode(tNode);
	const tData = tView.data;
	for (let i = 28; i < tData.length; i++) if (tData[i] === tNode) return;
	throwError("This TNode does not belong to this TView.");
}
function assertTNode(tNode) {
	assertDefined(tNode, "TNode must be defined");
	if (!(tNode && typeof tNode === "object" && Object.hasOwn(tNode, "directiveStylingLast"))) throwError("Not of type TNode, got: " + tNode);
}
function assertTIcu(tIcu) {
	assertDefined(tIcu, "Expected TIcu to be defined");
	if (!(typeof tIcu.currentCaseLViewIndex === "number")) throwError("Object is not of TIcu type.");
}
function assertNgModuleType(actual, msg = "Type passed in is not NgModuleType, it does not have 'ɵmod' property.") {
	if (!getNgModuleDef(actual)) throwError(msg);
}
function assertHasParent(tNode) {
	assertDefined(tNode, "currentTNode should exist!");
	assertDefined(tNode.parent, "currentTNode should have a parent");
}
function assertLContainer(value) {
	assertDefined(value, "LContainer must be defined");
	assertEqual(isLContainer(value), true, "Expecting LContainer");
}
function assertLViewOrUndefined(value) {
	value && assertEqual(isLView(value), true, "Expecting LView or undefined or null");
}
function assertLView(value) {
	assertDefined(value, "LView must be defined");
	assertEqual(isLView(value), true, "Expecting LView");
}
function assertFirstCreatePass(tView, errMessage) {
	assertEqual(tView.firstCreatePass, true, errMessage || "Should only be called in first create pass.");
}
function assertFirstUpdatePass(tView, errMessage) {
	assertEqual(tView.firstUpdatePass, true, "Should only be called in first update pass.");
}
function assertDirectiveDef(obj) {
	if (obj.type === void 0 || obj.selectors == void 0 || obj.inputs === void 0) throwError(`Expected a DirectiveDef/ComponentDef and this object does not seem to have the expected shape.`);
}
function assertIndexInDeclRange(tView, index) {
	assertBetween(28, tView.bindingStartIndex, index);
}
function assertIndexInExpandoRange(lView, index) {
	const tView = lView[1];
	assertBetween(tView.expandoStartIndex, lView.length, index);
}
function assertBetween(lower, upper, index) {
	if (!(lower <= index && index < upper)) throwError(`Index out of range (expecting ${lower} <= ${index} < ${upper})`);
}
function assertProjectionSlots(lView, errMessage) {
	assertDefined(lView[15], "Component views should exist.");
	assertDefined(lView[15][5].projection, "Components with projection nodes (<ng-content>) must have projection slots defined.");
}
function assertParentView(lView, errMessage) {
	assertDefined(lView, "Component views should always have a parent view (component's host view)");
}
function assertNodeInjector(lView, injectorIndex) {
	assertIndexInExpandoRange(lView, injectorIndex);
	assertIndexInExpandoRange(lView, injectorIndex + 8);
	assertNumber(lView[injectorIndex + 0], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 1], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 2], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 3], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 4], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 5], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 6], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 7], "injectorIndex should point to a bloom filter");
	assertNumber(lView[injectorIndex + 8], "injectorIndex should point to parent injector");
}
var SecurityContext;
(function(SecurityContext) {
	SecurityContext[SecurityContext["NONE"] = 0] = "NONE";
	SecurityContext[SecurityContext["HTML"] = 1] = "HTML";
	SecurityContext[SecurityContext["STYLE"] = 2] = "STYLE";
	SecurityContext[SecurityContext["SCRIPT"] = 3] = "SCRIPT";
	SecurityContext[SecurityContext["URL"] = 4] = "URL";
	SecurityContext[SecurityContext["RESOURCE_URL"] = 5] = "RESOURCE_URL";
	SecurityContext[SecurityContext["ATTRIBUTE_NO_BINDING"] = 6] = "ATTRIBUTE_NO_BINDING";
})(SecurityContext || (SecurityContext = {}));
var _SECURITY_SCHEMA;
var MATH_ML_NAMESPACE = "math";
var NO_NAMESPACE = "";
var MATCH_ALL_ELEMENTS = "*";
var createNullObj = () => Object.create(null);
function SECURITY_SCHEMA() {
	if (_SECURITY_SCHEMA) return _SECURITY_SCHEMA;
	_SECURITY_SCHEMA = createNullObj();
	registerContext(SecurityContext.HTML, void 0, [["iframe", ["srcdoc"]], ["*", ["innerHTML", "outerHTML"]]]);
	registerContext(SecurityContext.STYLE, void 0, [["*", ["style"]]]);
	registerContext(SecurityContext.URL, void 0, [
		["*", ["formAction"]],
		["area", ["href"]],
		["a", ["href", "xlink:href"]],
		["form", ["action"]]
	]);
	registerContext(SecurityContext.URL, MATH_ML_NAMESPACE, [["*", ["href", "xlink:href"]]]);
	registerContext(SecurityContext.RESOURCE_URL, void 0, [
		["base", ["href"]],
		["embed", ["src"]],
		["frame", ["src"]],
		["iframe", ["src"]],
		["link", ["href"]],
		["object", ["codebase", "data"]]
	]);
	registerContext(SecurityContext.URL, "svg", [["a", ["href", "xlink:href"]]]);
	registerContext(SecurityContext.ATTRIBUTE_NO_BINDING, "svg", [
		["animate", [
			"attributeName",
			"values",
			"to",
			"from"
		]],
		["set", ["to", "attributeName"]],
		["animateMotion", ["attributeName"]],
		["animateTransform", ["attributeName"]]
	]);
	registerContext(SecurityContext.ATTRIBUTE_NO_BINDING, void 0, [["unknown", [
		"attributeName",
		"values",
		"to",
		"from",
		"sandbox",
		"allow",
		"allowFullscreen",
		"referrerPolicy",
		"csp",
		"fetchPriority",
		"credentialless"
	]], ["iframe", [
		"sandbox",
		"allow",
		"allowFullscreen",
		"referrerPolicy",
		"csp",
		"fetchPriority",
		"credentialless"
	]]]);
	return _SECURITY_SCHEMA;
}
function registerContext(ctx, namespace, specs) {
	const nsKey = namespace ?? NO_NAMESPACE;
	for (const [element, attributeNames] of specs) {
		const tagName = element.toLowerCase();
		for (const attr of attributeNames) {
			const attrLower = attr.toLowerCase();
			const attrSchema = _SECURITY_SCHEMA[attrLower] ??= createNullObj();
			const nsSchema = attrSchema[nsKey] ??= createNullObj();
			nsSchema[tagName] = ctx;
		}
	}
}
function checkSecurityContext(tagName, propName, namespace) {
	const attrSchema = SECURITY_SCHEMA()[propName.toLowerCase()];
	if (!attrSchema) return SecurityContext.NONE;
	const tagLower = tagName.toLowerCase();
	let context;
	if (namespace) {
		const nsSchema = attrSchema[namespace];
		if (nsSchema) context = nsSchema[tagLower] ?? nsSchema[MATCH_ALL_ELEMENTS];
	}
	if (context === void 0) {
		const defaultSchema = attrSchema[NO_NAMESPACE];
		if (defaultSchema) context = defaultSchema[tagLower] ?? defaultSchema[MATCH_ALL_ELEMENTS];
	}
	if (context === void 0 && (!namespace || namespace === NO_NAMESPACE)) {
		const svgSchema = attrSchema["svg"];
		if (svgSchema) context = svgSchema[tagLower];
	}
	return context ?? SecurityContext.NONE;
}
function unwrapRNode(value) {
	while (Array.isArray(value)) value = value[0];
	return value;
}
function unwrapLView(value) {
	while (Array.isArray(value)) {
		if (typeof value[TYPE] === "object") return value;
		value = value[0];
	}
	return null;
}
function getNativeByIndex(index, lView) {
	ngDevMode && assertIndexInRange(lView, index);
	ngDevMode && assertGreaterThanOrEqual(index, 28, "Expected to be past HEADER_OFFSET");
	return unwrapRNode(lView[index]);
}
function getNativeByTNode(tNode, lView) {
	ngDevMode && assertTNodeForLView(tNode, lView);
	ngDevMode && assertIndexInRange(lView, tNode.index);
	return unwrapRNode(lView[tNode.index]);
}
function getNativeByTNodeOrNull(tNode, lView) {
	const index = tNode === null ? -1 : tNode.index;
	if (index !== -1) {
		ngDevMode && assertTNodeForLView(tNode, lView);
		return unwrapRNode(lView[index]);
	}
	return null;
}
function getTNode(tView, index) {
	ngDevMode && assertGreaterThan(index, -1, "wrong index for TNode");
	ngDevMode && assertLessThan(index, tView.data.length, "wrong index for TNode");
	const tNode = tView.data[index];
	ngDevMode && tNode !== null && assertTNode(tNode);
	return tNode;
}
function load(view, index) {
	ngDevMode && assertIndexInRange(view, index);
	return view[index];
}
function store(tView, lView, index, value) {
	if (index >= tView.data.length) {
		tView.data[index] = null;
		tView.blueprint[index] = null;
	}
	lView[index] = value;
}
function getComponentLViewByIndex(nodeIndex, hostView) {
	ngDevMode && assertIndexInRange(hostView, nodeIndex);
	const slotValue = hostView[nodeIndex];
	return isLView(slotValue) ? slotValue : slotValue[0];
}
function isCreationMode(view) {
	return (view[2] & 4) === 4;
}
function viewAttachedToChangeDetector(view) {
	return (view[2] & 128) === 128;
}
function viewAttachedToContainer(view) {
	return isLContainer(view[3]);
}
function getConstant(consts, index) {
	if (index === null || index === void 0) return null;
	ngDevMode && assertIndexInRange(consts, index);
	return consts[index];
}
function resetPreOrderHookFlags(lView) {
	lView[17] = 0;
}
function markViewForRefresh(lView) {
	if (lView[2] & 1024) return;
	lView[2] |= 1024;
	if (viewAttachedToChangeDetector(lView)) markAncestorsForTraversal(lView);
}
function walkUpViews(nestingLevel, currentView) {
	while (nestingLevel > 0) {
		ngDevMode && assertDefined(currentView[14], "Declaration view should be defined if nesting level is greater than 0.");
		currentView = currentView[14];
		nestingLevel--;
	}
	return currentView;
}
function requiresRefreshOrTraversal(lView) {
	return !!(lView[2] & 9216 || lView[24]?.dirty);
}
function updateAncestorTraversalFlagsOnAttach(lView) {
	lView[10].changeDetectionScheduler?.notify(8);
	if (lView[2] & 64) lView[2] |= 1024;
	if (requiresRefreshOrTraversal(lView)) markAncestorsForTraversal(lView);
}
function markAncestorsForTraversal(lView) {
	lView[10].changeDetectionScheduler?.notify(0);
	let parent = getLViewParent(lView);
	while (parent !== null) {
		if (parent[2] & 8192) break;
		parent[2] |= 8192;
		if (!viewAttachedToChangeDetector(parent)) break;
		parent = getLViewParent(parent);
	}
}
function storeLViewOnDestroy(lView, onDestroyCallback) {
	if (isDestroyed(lView)) throw new RuntimeError(911, ngDevMode && "View has already been destroyed.");
	if (lView[21] === null) lView[21] = [];
	lView[21].push(onDestroyCallback);
}
function removeLViewOnDestroy(lView, onDestroyCallback) {
	if (lView[21] === null) return;
	const destroyCBIdx = lView[21].indexOf(onDestroyCallback);
	if (destroyCBIdx !== -1) lView[21].splice(destroyCBIdx, 1);
}
function getLViewParent(lView) {
	ngDevMode && assertLView(lView);
	const parent = lView[3];
	return isLContainer(parent) ? parent[3] : parent;
}
function getOrCreateLViewCleanup(view) {
	return view[7] ??= [];
}
function getOrCreateTViewCleanup(tView) {
	return tView.cleanup ??= [];
}
function storeCleanupWithContext(tView, lView, context, cleanupFn) {
	const lCleanup = getOrCreateLViewCleanup(lView);
	ngDevMode && assertDefined(context, "Cleanup context is mandatory when registering framework-level destroy hooks");
	lCleanup.push(context);
	if (tView.firstCreatePass) getOrCreateTViewCleanup(tView).push(cleanupFn, lCleanup.length - 1);
	else if (ngDevMode) Object.freeze(getOrCreateTViewCleanup(tView));
}
var instructionState = {
	lFrame: createLFrame(null),
	bindingsEnabled: true,
	skipHydrationRootTNode: null
};
var CheckNoChangesMode;
(function(CheckNoChangesMode) {
	CheckNoChangesMode[CheckNoChangesMode["Off"] = 0] = "Off";
	CheckNoChangesMode[CheckNoChangesMode["Exhaustive"] = 1] = "Exhaustive";
	CheckNoChangesMode[CheckNoChangesMode["OnlyDirtyViews"] = 2] = "OnlyDirtyViews";
})(CheckNoChangesMode || (CheckNoChangesMode = {}));
var _checkNoChangesMode = 0;
var _isRefreshingViews = false;
function getElementDepthCount() {
	return instructionState.lFrame.elementDepthCount;
}
function increaseElementDepthCount() {
	instructionState.lFrame.elementDepthCount++;
}
function decreaseElementDepthCount() {
	instructionState.lFrame.elementDepthCount--;
}
function getBindingsEnabled() {
	return instructionState.bindingsEnabled;
}
function isInSkipHydrationBlock() {
	return instructionState.skipHydrationRootTNode !== null;
}
function isSkipHydrationRootTNode(tNode) {
	return instructionState.skipHydrationRootTNode === tNode;
}
function ɵɵenableBindings() {
	instructionState.bindingsEnabled = true;
}
function ɵɵdisableBindings() {
	instructionState.bindingsEnabled = false;
}
function leaveSkipHydrationBlock() {
	instructionState.skipHydrationRootTNode = null;
}
function getLView() {
	return instructionState.lFrame.lView;
}
function getTView() {
	return instructionState.lFrame.tView;
}
function ɵɵrestoreView(viewToRestore) {
	instructionState.lFrame.contextLView = viewToRestore;
	return viewToRestore[8];
}
function ɵɵresetView(value) {
	instructionState.lFrame.contextLView = null;
	return value;
}
function getCurrentTNode() {
	let currentTNode = getCurrentTNodePlaceholderOk();
	while (currentTNode !== null && currentTNode.type === 64) currentTNode = currentTNode.parent;
	return currentTNode;
}
function getCurrentTNodePlaceholderOk() {
	return instructionState.lFrame.currentTNode;
}
function getCurrentParentTNode() {
	const lFrame = instructionState.lFrame;
	const currentTNode = lFrame.currentTNode;
	return lFrame.isParent ? currentTNode : currentTNode.parent;
}
function setCurrentTNode(tNode, isParent) {
	ngDevMode && tNode && assertTNodeForTView(tNode, instructionState.lFrame.tView);
	const lFrame = instructionState.lFrame;
	lFrame.currentTNode = tNode;
	lFrame.isParent = isParent;
}
function isCurrentTNodeParent() {
	return instructionState.lFrame.isParent;
}
function setCurrentTNodeAsNotParent() {
	instructionState.lFrame.isParent = false;
}
function getContextLView() {
	const contextLView = instructionState.lFrame.contextLView;
	ngDevMode && assertDefined(contextLView, "contextLView must be defined.");
	return contextLView;
}
function isInCheckNoChangesMode() {
	!ngDevMode && throwError("Must never be called in production mode");
	return _checkNoChangesMode !== CheckNoChangesMode.Off;
}
function isExhaustiveCheckNoChanges() {
	!ngDevMode && throwError("Must never be called in production mode");
	return _checkNoChangesMode === CheckNoChangesMode.Exhaustive;
}
function setIsInCheckNoChangesMode(mode) {
	!ngDevMode && throwError("Must never be called in production mode");
	_checkNoChangesMode = mode;
}
function isRefreshingViews() {
	return _isRefreshingViews;
}
function setIsRefreshingViews(mode) {
	const prev = _isRefreshingViews;
	_isRefreshingViews = mode;
	return prev;
}
function getBindingRoot() {
	const lFrame = instructionState.lFrame;
	let index = lFrame.bindingRootIndex;
	if (index === -1) index = lFrame.bindingRootIndex = lFrame.tView.bindingStartIndex;
	return index;
}
function getBindingIndex() {
	return instructionState.lFrame.bindingIndex;
}
function setBindingIndex(value) {
	return instructionState.lFrame.bindingIndex = value;
}
function nextBindingIndex() {
	return instructionState.lFrame.bindingIndex++;
}
function incrementBindingIndex(count) {
	const lFrame = instructionState.lFrame;
	const index = lFrame.bindingIndex;
	lFrame.bindingIndex = lFrame.bindingIndex + count;
	return index;
}
function isInI18nBlock() {
	return instructionState.lFrame.inI18n;
}
function setInI18nBlock(isInI18nBlock) {
	instructionState.lFrame.inI18n = isInI18nBlock;
}
function setBindingRootForHostBindings(bindingRootIndex, currentDirectiveIndex) {
	const lFrame = instructionState.lFrame;
	lFrame.bindingIndex = lFrame.bindingRootIndex = bindingRootIndex;
	setCurrentDirectiveIndex(currentDirectiveIndex);
}
function getCurrentDirectiveIndex() {
	return instructionState.lFrame.currentDirectiveIndex;
}
function setCurrentDirectiveIndex(currentDirectiveIndex) {
	instructionState.lFrame.currentDirectiveIndex = currentDirectiveIndex;
}
function getCurrentDirectiveDef(tData) {
	const currentDirectiveIndex = instructionState.lFrame.currentDirectiveIndex;
	return currentDirectiveIndex === -1 ? null : tData[currentDirectiveIndex];
}
function getCurrentQueryIndex() {
	return instructionState.lFrame.currentQueryIndex;
}
function setCurrentQueryIndex(value) {
	instructionState.lFrame.currentQueryIndex = value;
}
function getDeclarationTNode(lView) {
	const tView = lView[1];
	if (tView.type === 2) {
		ngDevMode && assertDefined(tView.declTNode, "Embedded TNodes should have declaration parents.");
		return tView.declTNode;
	}
	if (tView.type === 1) return lView[5];
	return null;
}
function enterDI(lView, tNode, flags) {
	ngDevMode && assertLViewOrUndefined(lView);
	if (flags & 4) {
		ngDevMode && assertTNodeForTView(tNode, lView[1]);
		let parentTNode = tNode;
		let parentLView = lView;
		while (true) {
			ngDevMode && assertDefined(parentTNode, "Parent TNode should be defined");
			parentTNode = parentTNode.parent;
			if (parentTNode === null && !(flags & 1)) {
				parentTNode = getDeclarationTNode(parentLView);
				if (parentTNode === null) break;
				ngDevMode && assertDefined(parentLView, "Parent LView should be defined");
				parentLView = parentLView[14];
				if (parentTNode.type & 10) break;
			} else break;
		}
		if (parentTNode === null) return false;
		else {
			tNode = parentTNode;
			lView = parentLView;
		}
	}
	ngDevMode && assertTNodeForLView(tNode, lView);
	const lFrame = instructionState.lFrame = allocLFrame();
	lFrame.currentTNode = tNode;
	lFrame.lView = lView;
	return true;
}
function enterView(newView) {
	ngDevMode && assertNotEqual(newView[0], newView[1], "????");
	ngDevMode && assertLViewOrUndefined(newView);
	const newLFrame = allocLFrame();
	if (ngDevMode) {
		assertEqual(newLFrame.isParent, true, "Expected clean LFrame");
		assertEqual(newLFrame.lView, null, "Expected clean LFrame");
		assertEqual(newLFrame.tView, null, "Expected clean LFrame");
		assertEqual(newLFrame.selectedIndex, -1, "Expected clean LFrame");
		assertEqual(newLFrame.elementDepthCount, 0, "Expected clean LFrame");
		assertEqual(newLFrame.currentDirectiveIndex, -1, "Expected clean LFrame");
		assertEqual(newLFrame.currentNamespace, null, "Expected clean LFrame");
		assertEqual(newLFrame.bindingRootIndex, -1, "Expected clean LFrame");
		assertEqual(newLFrame.currentQueryIndex, 0, "Expected clean LFrame");
	}
	const tView = newView[1];
	instructionState.lFrame = newLFrame;
	ngDevMode && tView.firstChild && assertTNodeForTView(tView.firstChild, tView);
	newLFrame.currentTNode = tView.firstChild;
	newLFrame.lView = newView;
	newLFrame.tView = tView;
	newLFrame.contextLView = newView;
	newLFrame.bindingIndex = tView.bindingStartIndex;
	newLFrame.inI18n = false;
}
function allocLFrame() {
	const currentLFrame = instructionState.lFrame;
	const childLFrame = currentLFrame === null ? null : currentLFrame.child;
	return childLFrame === null ? createLFrame(currentLFrame) : childLFrame;
}
function createLFrame(parent) {
	const lFrame = {
		currentTNode: null,
		isParent: true,
		lView: null,
		tView: null,
		selectedIndex: -1,
		contextLView: null,
		elementDepthCount: 0,
		currentNamespace: null,
		currentDirectiveIndex: -1,
		bindingRootIndex: -1,
		bindingIndex: -1,
		currentQueryIndex: 0,
		parent,
		child: null,
		inI18n: false
	};
	parent !== null && (parent.child = lFrame);
	return lFrame;
}
function leaveViewLight() {
	const oldLFrame = instructionState.lFrame;
	instructionState.lFrame = oldLFrame.parent;
	oldLFrame.currentTNode = null;
	oldLFrame.lView = null;
	return oldLFrame;
}
var leaveDI = leaveViewLight;
function leaveView() {
	const oldLFrame = leaveViewLight();
	oldLFrame.isParent = true;
	oldLFrame.tView = null;
	oldLFrame.selectedIndex = -1;
	oldLFrame.contextLView = null;
	oldLFrame.elementDepthCount = 0;
	oldLFrame.currentDirectiveIndex = -1;
	oldLFrame.currentNamespace = null;
	oldLFrame.bindingRootIndex = -1;
	oldLFrame.bindingIndex = -1;
	oldLFrame.currentQueryIndex = 0;
}
function nextContextImpl(level) {
	return (instructionState.lFrame.contextLView = walkUpViews(level, instructionState.lFrame.contextLView))[8];
}
function getSelectedIndex() {
	return instructionState.lFrame.selectedIndex;
}
function setSelectedIndex(index) {
	ngDevMode && index !== -1 && assertGreaterThanOrEqual(index, 28, "Index must be past HEADER_OFFSET (or -1).");
	ngDevMode && assertLessThan(index, instructionState.lFrame.lView.length, "Can't set index passed end of LView");
	instructionState.lFrame.selectedIndex = index;
}
function getSelectedTNode() {
	const lFrame = instructionState.lFrame;
	return getTNode(lFrame.tView, lFrame.selectedIndex);
}
function ɵɵnamespaceSVG() {
	instructionState.lFrame.currentNamespace = "svg";
}
function ɵɵnamespaceMathML() {
	instructionState.lFrame.currentNamespace = MATH_ML_NAMESPACE;
}
function ɵɵnamespaceHTML() {
	namespaceHTMLInternal();
}
function namespaceHTMLInternal() {
	instructionState.lFrame.currentNamespace = null;
}
function getNamespace() {
	return instructionState.lFrame.currentNamespace;
}
var _wasLastNodeCreated = true;
function wasLastNodeCreated() {
	return _wasLastNodeCreated;
}
function lastNodeWasCreated(flag) {
	_wasLastNodeCreated = flag;
}
function promiseWithResolvers() {
	let resolve;
	let reject;
	return {
		promise: new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		}),
		resolve,
		reject
	};
}
function createInjector(defType, parent = null, additionalProviders = null, name) {
	const injector = createInjectorWithoutInjectorInstances(defType, parent, additionalProviders, name);
	injector.resolveInjectorInitializers();
	return injector;
}
function createInjectorWithoutInjectorInstances(defType, parent = null, additionalProviders = null, name, scopes = /* @__PURE__ */ new Set()) {
	const providers = [additionalProviders || EMPTY_ARRAY, importProvidersFrom(defType)];
	let source = void 0;
	if (ngDevMode) source = name || (typeof defType === "object" ? void 0 : stringify(defType));
	return new R3Injector(providers, parent || getNullInjector(), source || null, scopes);
}
var specialProviders = /* @__PURE__ */ new Set();
function registerSpecialProvider(clazz) {
	if (typeof ngDevMode !== "undefined" && ngDevMode) specialProviders.add(clazz);
}
function getAllSpecialProviders() {
	return specialProviders;
}
var Injector = class Injector {
	static THROW_IF_NOT_FOUND = THROW_IF_NOT_FOUND;
	static NULL = new NullInjector();
	static create(options, parent) {
		if (Array.isArray(options)) return createInjector({ name: "" }, parent, options, "");
		else {
			const name = options.name ?? "";
			return createInjector({ name }, options.parent, options.providers, name);
		}
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: Injector,
		providedIn: "any",
		factory: () => ɵɵinject(INJECTOR$1)
	});
	static __NG_ELEMENT_ID__ = -1;
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(Injector);
var DOCUMENT = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DocumentToken" : "");
var DestroyRef = class {
	static __NG_ELEMENT_ID__ = injectDestroyRef;
	static __NG_ENV_ID__ = (injector) => injector;
};
if (typeof ngDevMode === "undefined" || ngDevMode) registerSpecialProvider(DestroyRef);
var NodeInjectorDestroyRef = class extends DestroyRef {
	_lView;
	constructor(_lView) {
		super();
		this._lView = _lView;
	}
	get destroyed() {
		return isDestroyed(this._lView);
	}
	onDestroy(callback) {
		const lView = this._lView;
		storeLViewOnDestroy(lView, callback);
		return () => removeLViewOnDestroy(lView, callback);
	}
};
function injectDestroyRef() {
	return new NodeInjectorDestroyRef(getLView());
}
var DEBUG_TASK_TRACKER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DEBUG_TASK_TRACKER" : "");
var PendingTasksInternal = class PendingTasksInternal {
	taskId = 0;
	pendingTasks = /* @__PURE__ */ new Set();
	destroyed = false;
	pendingTask = new import_cjs.BehaviorSubject(false);
	debugTaskTracker = inject(DEBUG_TASK_TRACKER, { optional: true });
	get hasPendingTasks() {
		return this.destroyed ? false : this.pendingTask.value;
	}
	get hasPendingTasksObservable() {
		if (this.destroyed) return new import_cjs.Observable((subscriber) => {
			subscriber.next(false);
			subscriber.complete();
		});
		return this.pendingTask;
	}
	add() {
		if (!this.hasPendingTasks && !this.destroyed) this.pendingTask.next(true);
		const taskId = this.taskId++;
		this.pendingTasks.add(taskId);
		this.debugTaskTracker?.add(taskId);
		return taskId;
	}
	has(taskId) {
		return this.pendingTasks.has(taskId);
	}
	remove(taskId) {
		this.pendingTasks.delete(taskId);
		this.debugTaskTracker?.remove(taskId);
		if (this.pendingTasks.size === 0 && this.hasPendingTasks) this.pendingTask.next(false);
	}
	ngOnDestroy() {
		this.pendingTasks.clear();
		if (this.hasPendingTasks) this.pendingTask.next(false);
		this.destroyed = true;
		this.pendingTask.unsubscribe();
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: PendingTasksInternal,
		providedIn: "root",
		factory: () => new PendingTasksInternal()
	});
};
var EventEmitter_ = class extends import_cjs.Subject {
	__isAsync;
	destroyRef = void 0;
	pendingTasks = void 0;
	constructor(isAsync = false) {
		super();
		this.__isAsync = isAsync;
		if (isInInjectionContext()) {
			this.destroyRef = inject(DestroyRef, { optional: true }) ?? void 0;
			this.pendingTasks = inject(PendingTasksInternal, { optional: true }) ?? void 0;
		}
	}
	emit(value) {
		const prevConsumer = setActiveConsumer(null);
		try {
			super.next(value);
		} finally {
			setActiveConsumer(prevConsumer);
		}
	}
	subscribe(observerOrNext, error, complete) {
		let nextFn = observerOrNext;
		let errorFn = error || (() => null);
		let completeFn = complete;
		if (observerOrNext && typeof observerOrNext === "object") {
			const observer = observerOrNext;
			nextFn = observer.next?.bind(observer);
			errorFn = observer.error?.bind(observer);
			completeFn = observer.complete?.bind(observer);
		}
		if (this.__isAsync) {
			errorFn = this.wrapInTimeout(errorFn);
			if (nextFn) nextFn = this.wrapInTimeout(nextFn);
			if (completeFn) completeFn = this.wrapInTimeout(completeFn);
		}
		const sink = super.subscribe({
			next: nextFn,
			error: errorFn,
			complete: completeFn
		});
		if (observerOrNext instanceof import_cjs.Subscription) observerOrNext.add(sink);
		return sink;
	}
	wrapInTimeout(fn) {
		return (value) => {
			const taskId = this.pendingTasks?.add();
			setTimeout(() => {
				try {
					fn(value);
				} finally {
					if (taskId !== void 0) this.pendingTasks?.remove(taskId);
				}
			});
		};
	}
};
var EventEmitter = EventEmitter_;
function noop(...args) {}
function scheduleCallbackWithRafRace(callback) {
	let timeoutId;
	let animationFrameId;
	function cleanup() {
		callback = noop;
		try {
			if (animationFrameId !== void 0 && typeof cancelAnimationFrame === "function") cancelAnimationFrame(animationFrameId);
			if (timeoutId !== void 0) clearTimeout(timeoutId);
		} catch {}
	}
	timeoutId = setTimeout(() => {
		callback();
		cleanup();
	});
	if (typeof requestAnimationFrame === "function") animationFrameId = requestAnimationFrame(() => {
		callback();
		cleanup();
	});
	return () => cleanup();
}
function scheduleCallbackWithMicrotask(callback) {
	queueMicrotask(() => callback());
	return () => {
		callback = noop;
	};
}
var AsyncStackTaggingZoneSpec = class {
	createTask;
	constructor(namePrefix, consoleAsyncStackTaggingImpl = console) {
		this.name = "asyncStackTagging for " + namePrefix;
		this.createTask = consoleAsyncStackTaggingImpl?.createTask ?? (() => null);
	}
	name;
	onScheduleTask(delegate, _current, target, task) {
		task.consoleTask = this.createTask(`Zone - ${task.source || task.type}`);
		return delegate.scheduleTask(target, task);
	}
	onInvokeTask(delegate, _currentZone, targetZone, task, applyThis, applyArgs) {
		let ret;
		if (task.consoleTask) ret = task.consoleTask.run(() => delegate.invokeTask(targetZone, task, applyThis, applyArgs));
		else ret = delegate.invokeTask(targetZone, task, applyThis, applyArgs);
		return ret;
	}
};
var isAngularZoneProperty = "isAngularZone";
var angularZoneInstanceIdProperty = "isAngularZone_ID";
var ngZoneInstanceId = 0;
var NgZone = class NgZone {
	hasPendingMacrotasks = false;
	hasPendingMicrotasks = false;
	isStable = true;
	onUnstable = new EventEmitter(false);
	onMicrotaskEmpty = new EventEmitter(false);
	onStable = new EventEmitter(false);
	onError = new EventEmitter(false);
	constructor(options) {
		const { enableLongStackTrace = false, shouldCoalesceEventChangeDetection = false, shouldCoalesceRunChangeDetection = false, scheduleInRootZone = false } = options;
		if (typeof Zone == "undefined") throw new RuntimeError(908, ngDevMode && `In this configuration Angular requires Zone.js`);
		Zone.assertZonePatched();
		const self = this;
		self._nesting = 0;
		self._outer = self._inner = Zone.current;
		if (ngDevMode) self._inner = self._inner.fork(new AsyncStackTaggingZoneSpec("Angular"));
		if (Zone["TaskTrackingZoneSpec"]) self._inner = self._inner.fork(new Zone["TaskTrackingZoneSpec"]());
		if (enableLongStackTrace && Zone["longStackTraceZoneSpec"]) self._inner = self._inner.fork(Zone["longStackTraceZoneSpec"]);
		self.shouldCoalesceEventChangeDetection = !shouldCoalesceRunChangeDetection && shouldCoalesceEventChangeDetection;
		self.shouldCoalesceRunChangeDetection = shouldCoalesceRunChangeDetection;
		self.callbackScheduled = false;
		self.scheduleInRootZone = scheduleInRootZone;
		forkInnerZoneWithAngularBehavior(self);
	}
	static isInAngularZone() {
		return typeof Zone !== "undefined" && Zone.current.get(isAngularZoneProperty) === true;
	}
	static assertInAngularZone() {
		if (!NgZone.isInAngularZone()) throw new RuntimeError(909, ngDevMode && "Expected to be in Angular Zone, but it is not!");
	}
	static assertNotInAngularZone() {
		if (NgZone.isInAngularZone()) throw new RuntimeError(909, ngDevMode && "Expected to not be in Angular Zone, but it is!");
	}
	run(fn, applyThis, applyArgs) {
		return this._inner.run(fn, applyThis, applyArgs);
	}
	runTask(fn, applyThis, applyArgs, name) {
		const zone = this._inner;
		const task = zone.scheduleEventTask("NgZoneEvent: " + name, fn, EMPTY_PAYLOAD, noop, noop);
		try {
			return zone.runTask(task, applyThis, applyArgs);
		} finally {
			zone.cancelTask(task);
		}
	}
	runGuarded(fn, applyThis, applyArgs) {
		return this._inner.runGuarded(fn, applyThis, applyArgs);
	}
	runOutsideAngular(fn) {
		return this._outer.run(fn);
	}
};
var EMPTY_PAYLOAD = {};
function checkStable(zone) {
	if (zone._nesting == 0 && !zone.hasPendingMicrotasks && !zone.isStable) try {
		zone._nesting++;
		zone.onMicrotaskEmpty.emit(null);
	} finally {
		zone._nesting--;
		if (!zone.hasPendingMicrotasks) try {
			zone.runOutsideAngular(() => zone.onStable.emit(null));
		} finally {
			zone.isStable = true;
		}
	}
}
function delayChangeDetectionForEvents(zone) {
	if (zone.isCheckStableRunning || zone.callbackScheduled) return;
	zone.callbackScheduled = true;
	function scheduleCheckStable() {
		scheduleCallbackWithRafRace(() => {
			zone.callbackScheduled = false;
			updateMicroTaskStatus(zone);
			zone.isCheckStableRunning = true;
			checkStable(zone);
			zone.isCheckStableRunning = false;
		});
	}
	if (zone.scheduleInRootZone) Zone.root.run(() => {
		scheduleCheckStable();
	});
	else zone._outer.run(() => {
		scheduleCheckStable();
	});
	updateMicroTaskStatus(zone);
}
function forkInnerZoneWithAngularBehavior(zone) {
	const delayChangeDetectionForEventsDelegate = () => {
		delayChangeDetectionForEvents(zone);
	};
	const instanceId = ngZoneInstanceId++;
	zone._inner = zone._inner.fork({
		name: "angular",
		properties: {
			[isAngularZoneProperty]: true,
			[angularZoneInstanceIdProperty]: instanceId,
			[angularZoneInstanceIdProperty + instanceId]: true
		},
		onInvokeTask: (delegate, current, target, task, applyThis, applyArgs) => {
			if (shouldBeIgnoredByZone(applyArgs)) return delegate.invokeTask(target, task, applyThis, applyArgs);
			try {
				onEnter(zone);
				return delegate.invokeTask(target, task, applyThis, applyArgs);
			} finally {
				if (zone.shouldCoalesceEventChangeDetection && task.type === "eventTask" || zone.shouldCoalesceRunChangeDetection) delayChangeDetectionForEventsDelegate();
				onLeave(zone);
			}
		},
		onInvoke: (delegate, current, target, callback, applyThis, applyArgs, source) => {
			try {
				onEnter(zone);
				return delegate.invoke(target, callback, applyThis, applyArgs, source);
			} finally {
				if (zone.shouldCoalesceRunChangeDetection && !zone.callbackScheduled && !isSchedulerTick(applyArgs)) delayChangeDetectionForEventsDelegate();
				onLeave(zone);
			}
		},
		onHasTask: (delegate, current, target, hasTaskState) => {
			delegate.hasTask(target, hasTaskState);
			if (current === target) {
				if (hasTaskState.change == "microTask") {
					zone._hasPendingMicrotasks = hasTaskState.microTask;
					updateMicroTaskStatus(zone);
					checkStable(zone);
				} else if (hasTaskState.change == "macroTask") zone.hasPendingMacrotasks = hasTaskState.macroTask;
			}
		},
		onHandleError: (delegate, current, target, error) => {
			delegate.handleError(target, error);
			zone.runOutsideAngular(() => zone.onError.emit(error));
			return false;
		}
	});
}
function updateMicroTaskStatus(zone) {
	if (zone._hasPendingMicrotasks || (zone.shouldCoalesceEventChangeDetection || zone.shouldCoalesceRunChangeDetection) && zone.callbackScheduled === true) zone.hasPendingMicrotasks = true;
	else zone.hasPendingMicrotasks = false;
}
function onEnter(zone) {
	zone._nesting++;
	if (zone.isStable) {
		zone.isStable = false;
		zone.onUnstable.emit(null);
	}
}
function onLeave(zone) {
	zone._nesting--;
	checkStable(zone);
}
var NoopNgZone = class {
	hasPendingMicrotasks = false;
	hasPendingMacrotasks = false;
	isStable = true;
	onUnstable = new EventEmitter();
	onMicrotaskEmpty = new EventEmitter();
	onStable = new EventEmitter();
	onError = new EventEmitter();
	run(fn, applyThis, applyArgs) {
		return fn.apply(applyThis, applyArgs);
	}
	runGuarded(fn, applyThis, applyArgs) {
		return fn.apply(applyThis, applyArgs);
	}
	runOutsideAngular(fn) {
		return fn();
	}
	runTask(fn, applyThis, applyArgs, name) {
		return fn.apply(applyThis, applyArgs);
	}
};
function shouldBeIgnoredByZone(applyArgs) {
	return hasApplyArgsData(applyArgs, "__ignore_ng_zone__");
}
function isSchedulerTick(applyArgs) {
	return hasApplyArgsData(applyArgs, "__scheduler_tick__");
}
function hasApplyArgsData(applyArgs, key) {
	if (!Array.isArray(applyArgs)) return false;
	if (applyArgs.length !== 1) return false;
	return applyArgs[0]?.data?.[key] === true;
}
var ErrorHandler = class {
	_console = console;
	handleError(error) {
		this._console.error("ERROR", error);
	}
};
function encapsulateBoundaryError(error) {
	if (isErrorLike(error)) return error;
	return new ErrorBoundaryWrappedError(error);
}
function isErrorLike(error) {
	return error instanceof Error || typeof error === "object" && error !== null && typeof error.name === "string" && typeof error.message === "string";
}
var ErrorBoundaryWrappedError = class extends Error {
	constructor(error) {
		super(typeof ngDevMode !== "undefined" && ngDevMode ? `Error boundary caught an error that's not an Error instance: ${String(error)}. Check this error's .cause for the actual error.` : String(error), { cause: error });
		this.name = "ErrorBoundaryWrappedError";
	}
};
var INTERNAL_APPLICATION_ERROR_HANDLER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "internal error handler" : "", { factory: () => {
	const zone = inject(NgZone);
	const injector = inject(EnvironmentInjector);
	let userErrorHandler;
	return (e) => {
		zone.runOutsideAngular(() => {
			if (injector.destroyed && !userErrorHandler) setTimeout(() => {
				throw e;
			});
			else {
				userErrorHandler ??= injector.get(ErrorHandler);
				userErrorHandler.handleError(e);
			}
		});
	};
} });
var errorHandlerEnvironmentInitializer = {
	provide: ENVIRONMENT_INITIALIZER,
	useValue: () => {
		const handler = inject(ErrorHandler, { optional: true });
		if ((typeof ngDevMode === "undefined" || ngDevMode) && handler === null) throw new RuntimeError(402, "A required Injectable was not found in the dependency injection tree. If you are bootstrapping an NgModule, make sure that the `BrowserModule` is imported.");
	},
	multi: true
};
var globalErrorListeners = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "GlobalErrorListeners" : "", { factory: () => {} });
function provideBrowserGlobalErrorListeners() {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => void inject(globalErrorListeners))]);
}
function ɵunwrapWritableSignal(value) {
	return null;
}
function signal(initialValue, options) {
	const [get, set, update] = createSignal(initialValue, options?.equal);
	const signalFn = get;
	const node = signalFn[SIGNAL];
	signalFn.set = set;
	signalFn.update = update;
	signalFn.asReadonly = signalAsReadonlyFn.bind(signalFn);
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		const debugName = options?.debugName;
		node.debugName = debugName;
		signalFn.toString = () => `[Signal${debugName ? " (" + debugName + ")" : ""}: ${signalFn()}]`;
	}
	return signalFn;
}
function signalAsReadonlyFn() {
	const node = this[SIGNAL];
	if (node.readonlyFn === void 0) {
		const readonlyFn = () => this();
		readonlyFn[SIGNAL] = node;
		node.readonlyFn = readonlyFn;
	}
	return node.readonlyFn;
}
var APP_ID = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "AppId" : "", { factory: () => DEFAULT_APP_ID });
var DEFAULT_APP_ID = "ng";
var validAppIdInitializer = {
	provide: ENVIRONMENT_INITIALIZER,
	multi: true,
	useValue: () => {
		const appId = inject(APP_ID);
		if (!/^[a-zA-Z0-9\-_]+$/.test(appId)) throw new RuntimeError(211, `APP_ID value "${appId}" is not alphanumeric. The APP_ID must be a string of alphanumeric characters. (a-zA-Z0-9), hyphens (-) and underscores (_) are allowed.`);
	}
};
var PLATFORM_INITIALIZER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Platform Initializer" : "");
var PLATFORM_ID = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Platform ID" : "", {
	providedIn: "platform",
	factory: () => "unknown"
});
var ANIMATION_MODULE_TYPE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "AnimationModuleType" : "");
var CSP_NONCE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "CSP nonce" : "", { factory: () => {
	return inject(DOCUMENT).body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null;
} });
var IMAGE_CONFIG_DEFAULTS = {
	breakpoints: [
		16,
		32,
		48,
		64,
		96,
		128,
		256,
		384,
		640,
		750,
		828,
		1080,
		1200,
		1920,
		2048,
		3840
	],
	placeholderResolution: 30,
	disableImageSizeWarning: false,
	disableImageLazyLoadWarning: false
};
var IMAGE_CONFIG = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ImageConfig" : "", { factory: () => IMAGE_CONFIG_DEFAULTS });
function makeStateKey(key) {
	return key;
}
function createDictionary() {
	return Object.create(null);
}
var TransferState = class TransferState {
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: TransferState,
		providedIn: "root",
		factory: () => {
			return new TransferState();
		}
	});
	store = createDictionary();
	onSerializeCallbacks = createDictionary();
	get(key, defaultValue) {
		if (!Object.hasOwn(this.store, key)) return defaultValue;
		const value = this.store[key];
		return value !== void 0 ? value : defaultValue;
	}
	set(key, value) {
		this.store[key] = value;
	}
	remove(key) {
		delete this.store[key];
	}
	hasKey(key) {
		return Object.hasOwn(this.store, key);
	}
	get isEmpty() {
		return Object.keys(this.store).length === 0;
	}
	onSerialize(key, callback) {
		this.onSerializeCallbacks[key] = callback;
	}
	toJson() {
		for (const key in this.onSerializeCallbacks) if (Object.hasOwn(this.onSerializeCallbacks, key)) try {
			this.store[key] = this.onSerializeCallbacks[key]();
		} catch (e) {
			console.warn("Exception in onSerialize callback: ", e);
		}
		return JSON.stringify(this.store).replace(/</g, "\\u003C").replace(/\//g, "\\u002F");
	}
};
function retrieveTransferredState(doc, appId) {
	const script = doc.getElementById(appId + "-state");
	if (script?.tagName === "SCRIPT" && script.textContent) try {
		return Object.assign(createDictionary(), JSON.parse(script.textContent));
	} catch (e) {
		console.warn("Exception while restoring TransferState for app " + appId, e);
	}
	return createDictionary();
}
function assertNotInReactiveContext(debugFn, extraContext) {
	if (getActiveConsumer() !== null) throw new RuntimeError(-602, ngDevMode && `${debugFn.name}() cannot be called from within a reactive context.${extraContext ? ` ${extraContext}` : ""}`);
}
var ViewContext = class {
	view;
	node;
	constructor(view, node) {
		this.view = view;
		this.node = node;
	}
	static __NG_ELEMENT_ID__ = injectViewContext;
};
function injectViewContext() {
	return new ViewContext(getLView(), getCurrentTNode());
}
var ChangeDetectionScheduler = class {};
var ZONELESS_ENABLED = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "Zoneless enabled" : "", { factory: () => true });
var PROVIDED_ZONELESS = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "Zoneless provided" : "", { factory: () => false });
var SCHEDULE_IN_ROOT_ZONE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "run changes outside zone in root" : "");
var EffectScheduler = class EffectScheduler {
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: EffectScheduler,
		providedIn: "root",
		factory: () => new ZoneAwareEffectScheduler()
	});
};
var ZoneAwareEffectScheduler = class {
	dirtyEffectCount = 0;
	queues = /* @__PURE__ */ new Map();
	add(handle) {
		this.enqueue(handle);
		this.schedule(handle);
	}
	schedule(handle) {
		if (!handle.dirty) return;
		this.dirtyEffectCount++;
	}
	remove(handle) {
		const zone = handle.zone;
		const queue = this.queues.get(zone);
		if (!queue.has(handle)) return;
		queue.delete(handle);
		if (handle.dirty) this.dirtyEffectCount--;
	}
	enqueue(handle) {
		const zone = handle.zone;
		if (!this.queues.has(zone)) this.queues.set(zone, /* @__PURE__ */ new Set());
		const queue = this.queues.get(zone);
		if (queue.has(handle)) return;
		queue.add(handle);
	}
	flush() {
		while (this.dirtyEffectCount > 0) {
			let ranOneEffect = false;
			for (const [zone, queue] of this.queues) if (zone === null) ranOneEffect ||= this.flushQueue(queue);
			else ranOneEffect ||= zone.run(() => this.flushQueue(queue));
			if (!ranOneEffect) this.dirtyEffectCount = 0;
		}
	}
	flushQueue(queue) {
		let ranOneEffect = false;
		for (const handle of queue) {
			if (!handle.dirty) continue;
			this.dirtyEffectCount--;
			ranOneEffect = true;
			handle.run();
		}
		return ranOneEffect;
	}
};
var EffectRefImpl = class {
	[SIGNAL];
	constructor(node) {
		this[SIGNAL] = node;
	}
	destroy() {
		this[SIGNAL].destroy();
	}
};
function effect(effectFn, options) {
	ngDevMode && assertNotInReactiveContext(effect, "Call `effect` outside of a reactive context. For example, schedule the effect inside the component constructor.");
	if (ngDevMode && !options?.injector) assertInInjectionContext(effect);
	if (ngDevMode && options?.allowSignalWrites !== void 0) console.warn(`The 'allowSignalWrites' flag is deprecated and no longer impacts effect() (writes are always allowed)`);
	const injector = options?.injector ?? inject(Injector);
	let destroyRef = options?.manualCleanup !== true ? injector.get(DestroyRef) : null;
	let node;
	const viewContext = injector.get(ViewContext, null, { optional: true });
	const notifier = injector.get(ChangeDetectionScheduler);
	if (viewContext !== null) {
		node = createViewEffect(viewContext.view, notifier, effectFn);
		if (destroyRef instanceof NodeInjectorDestroyRef && destroyRef._lView === viewContext.view) destroyRef = null;
	} else node = createRootEffect(effectFn, injector.get(EffectScheduler), notifier);
	node.injector = injector;
	if (destroyRef !== null) node.onDestroyFns = [destroyRef.onDestroy(() => node.destroy())];
	const effectRef = new EffectRefImpl(node);
	if (ngDevMode) {
		node.debugName = options?.debugName ?? "";
		const prevInjectorProfilerContext = setInjectorProfilerContext({
			injector,
			token: null
		});
		try {
			emitEffectCreatedEvent(effectRef);
		} finally {
			setInjectorProfilerContext(prevInjectorProfilerContext);
		}
	}
	return effectRef;
}
var EFFECT_NODE = /* @__PURE__ */ (() => ({
	...BASE_EFFECT_NODE,
	cleanupFns: void 0,
	zone: null,
	onDestroyFns: null,
	run() {
		if (ngDevMode && isInNotificationPhase()) throw new Error(`Schedulers cannot synchronously execute watches while scheduling.`);
		const prevRefreshingViews = setIsRefreshingViews(false);
		try {
			runEffect(this);
		} finally {
			setIsRefreshingViews(prevRefreshingViews);
		}
	},
	cleanup() {
		if (!this.cleanupFns?.length) return;
		const prevConsumer = setActiveConsumer(null);
		try {
			while (this.cleanupFns.length) this.cleanupFns.pop()();
		} finally {
			this.cleanupFns = [];
			setActiveConsumer(prevConsumer);
		}
	}
}))();
var ROOT_EFFECT_NODE = /* @__PURE__ */ (() => ({
	...EFFECT_NODE,
	consumerMarkedDirty() {
		this.scheduler.schedule(this);
		this.notifier.notify(12);
	},
	destroy() {
		consumerDestroy(this);
		if (this.onDestroyFns !== null) for (const fn of this.onDestroyFns) fn();
		this.cleanup();
		this.scheduler.remove(this);
	}
}))();
var VIEW_EFFECT_NODE = /* @__PURE__ */ (() => ({
	...EFFECT_NODE,
	consumerMarkedDirty() {
		this.view[2] |= 8192;
		markAncestorsForTraversal(this.view);
		this.notifier.notify(13);
	},
	destroy() {
		consumerDestroy(this);
		if (this.onDestroyFns !== null) for (const fn of this.onDestroyFns) fn();
		this.cleanup();
		this.view[23]?.delete(this);
	}
}))();
function createViewEffect(view, notifier, fn) {
	const node = Object.create(VIEW_EFFECT_NODE);
	node.view = view;
	node.zone = typeof Zone !== "undefined" ? Zone.current : null;
	node.notifier = notifier;
	node.userFn = fn;
	node.fn = createEffectFn(node, fn);
	view[23] ??= /* @__PURE__ */ new Set();
	view[23].add(node);
	node.consumerMarkedDirty(node);
	return node;
}
function createRootEffect(fn, scheduler, notifier) {
	const node = Object.create(ROOT_EFFECT_NODE);
	node.userFn = fn;
	node.fn = createEffectFn(node, fn);
	node.scheduler = scheduler;
	node.notifier = notifier;
	node.zone = typeof Zone !== "undefined" ? Zone.current : null;
	node.scheduler.add(node);
	node.notifier.notify(12);
	return node;
}
function createEffectFn(node, fn) {
	return () => {
		fn((cleanupFn) => (node.cleanupFns ??= []).push(cleanupFn));
	};
}
function isSignal(value) {
	return typeof value === "function" && value[SIGNAL] !== void 0;
}
function isWritableSignal(value) {
	return isSignal(value) && typeof value.set === "function";
}
var PendingTasks = class PendingTasks {
	internalPendingTasks = inject(PendingTasksInternal);
	scheduler = inject(ChangeDetectionScheduler);
	errorHandler = inject(INTERNAL_APPLICATION_ERROR_HANDLER);
	add() {
		const taskId = this.internalPendingTasks.add();
		return () => {
			if (!this.internalPendingTasks.has(taskId)) return;
			this.scheduler.notify(11);
			this.internalPendingTasks.remove(taskId);
		};
	}
	run(fn) {
		const removeTask = this.add();
		try {
			fn().catch(this.errorHandler).finally(removeTask);
		} catch (err) {
			this.errorHandler(err);
			removeTask();
		}
	}
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: PendingTasks,
		providedIn: "root",
		factory: () => new PendingTasks()
	});
};
// node_modules/rxjs/dist/cjs/internal/operators/partition.js
var require_partition = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.partition = void 0;
	var not_1 = require_not();
	var filter_1 = require_filter();
	function partition(predicate, thisArg) {
		return function(source) {
			return [filter_1.filter(predicate, thisArg)(source), filter_1.filter(not_1.not(predicate, thisArg))(source)];
		};
	}
	exports.partition = partition;
}));
// node_modules/rxjs/dist/cjs/internal/operators/race.js
var require_race = /* @__PURE__ */ __commonJSMin(((exports, module, this$1) => {
	var __read = this$1 && this$1.__read || function(o, n) {
		var m = typeof Symbol === "function" && o[Symbol.iterator];
		if (!m) return o;
		var i = m.call(o), r, ar = [], e;
		try {
			while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
		} catch (error) {
			e = { error };
		} finally {
			try {
				if (r && !r.done && (m = i["return"])) m.call(i);
			} finally {
				if (e) throw e.error;
			}
		}
		return ar;
	};
	var __spreadArray = this$1 && this$1.__spreadArray || function(to, from) {
		for (var i = 0, il = from.length, j = to.length; i < il; i++, j++) to[j] = from[i];
		return to;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.race = void 0;
	var argsOrArgArray_1 = require_argsOrArgArray();
	var raceWith_1 = require_raceWith();
	function race() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		return raceWith_1.raceWith.apply(void 0, __spreadArray([], __read(argsOrArgArray_1.argsOrArgArray(args))));
	}
	exports.race = race;
}));
// node_modules/rxjs/dist/cjs/operators/index.js
var require_operators = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.mergeAll = exports.merge = exports.max = exports.materialize = exports.mapTo = exports.map = exports.last = exports.isEmpty = exports.ignoreElements = exports.groupBy = exports.first = exports.findIndex = exports.find = exports.finalize = exports.filter = exports.expand = exports.exhaustMap = exports.exhaustAll = exports.exhaust = exports.every = exports.endWith = exports.elementAt = exports.distinctUntilKeyChanged = exports.distinctUntilChanged = exports.distinct = exports.dematerialize = exports.delayWhen = exports.delay = exports.defaultIfEmpty = exports.debounceTime = exports.debounce = exports.count = exports.connect = exports.concatWith = exports.concatMapTo = exports.concatMap = exports.concatAll = exports.concat = exports.combineLatestWith = exports.combineLatest = exports.combineLatestAll = exports.combineAll = exports.catchError = exports.bufferWhen = exports.bufferToggle = exports.bufferTime = exports.bufferCount = exports.buffer = exports.auditTime = exports.audit = void 0;
	exports.timeInterval = exports.throwIfEmpty = exports.throttleTime = exports.throttle = exports.tap = exports.takeWhile = exports.takeUntil = exports.takeLast = exports.take = exports.switchScan = exports.switchMapTo = exports.switchMap = exports.switchAll = exports.subscribeOn = exports.startWith = exports.skipWhile = exports.skipUntil = exports.skipLast = exports.skip = exports.single = exports.shareReplay = exports.share = exports.sequenceEqual = exports.scan = exports.sampleTime = exports.sample = exports.refCount = exports.retryWhen = exports.retry = exports.repeatWhen = exports.repeat = exports.reduce = exports.raceWith = exports.race = exports.publishReplay = exports.publishLast = exports.publishBehavior = exports.publish = exports.pluck = exports.partition = exports.pairwise = exports.onErrorResumeNext = exports.observeOn = exports.multicast = exports.min = exports.mergeWith = exports.mergeScan = exports.mergeMapTo = exports.mergeMap = exports.flatMap = void 0;
	exports.zipWith = exports.zipAll = exports.zip = exports.withLatestFrom = exports.windowWhen = exports.windowToggle = exports.windowTime = exports.windowCount = exports.window = exports.toArray = exports.timestamp = exports.timeoutWith = exports.timeout = void 0;
	var audit_1 = require_audit();
	Object.defineProperty(exports, "audit", {
		enumerable: true,
		get: function() {
			return audit_1.audit;
		}
	});
	var auditTime_1 = require_auditTime();
	Object.defineProperty(exports, "auditTime", {
		enumerable: true,
		get: function() {
			return auditTime_1.auditTime;
		}
	});
	var buffer_1 = require_buffer();
	Object.defineProperty(exports, "buffer", {
		enumerable: true,
		get: function() {
			return buffer_1.buffer;
		}
	});
	var bufferCount_1 = require_bufferCount();
	Object.defineProperty(exports, "bufferCount", {
		enumerable: true,
		get: function() {
			return bufferCount_1.bufferCount;
		}
	});
	var bufferTime_1 = require_bufferTime();
	Object.defineProperty(exports, "bufferTime", {
		enumerable: true,
		get: function() {
			return bufferTime_1.bufferTime;
		}
	});
	var bufferToggle_1 = require_bufferToggle();
	Object.defineProperty(exports, "bufferToggle", {
		enumerable: true,
		get: function() {
			return bufferToggle_1.bufferToggle;
		}
	});
	var bufferWhen_1 = require_bufferWhen();
	Object.defineProperty(exports, "bufferWhen", {
		enumerable: true,
		get: function() {
			return bufferWhen_1.bufferWhen;
		}
	});
	var catchError_1 = require_catchError();
	Object.defineProperty(exports, "catchError", {
		enumerable: true,
		get: function() {
			return catchError_1.catchError;
		}
	});
	var combineAll_1 = require_combineAll();
	Object.defineProperty(exports, "combineAll", {
		enumerable: true,
		get: function() {
			return combineAll_1.combineAll;
		}
	});
	var combineLatestAll_1 = require_combineLatestAll();
	Object.defineProperty(exports, "combineLatestAll", {
		enumerable: true,
		get: function() {
			return combineLatestAll_1.combineLatestAll;
		}
	});
	var combineLatest_1 = require_combineLatest();
	Object.defineProperty(exports, "combineLatest", {
		enumerable: true,
		get: function() {
			return combineLatest_1.combineLatest;
		}
	});
	var combineLatestWith_1 = require_combineLatestWith();
	Object.defineProperty(exports, "combineLatestWith", {
		enumerable: true,
		get: function() {
			return combineLatestWith_1.combineLatestWith;
		}
	});
	var concat_1 = require_concat();
	Object.defineProperty(exports, "concat", {
		enumerable: true,
		get: function() {
			return concat_1.concat;
		}
	});
	var concatAll_1 = require_concatAll();
	Object.defineProperty(exports, "concatAll", {
		enumerable: true,
		get: function() {
			return concatAll_1.concatAll;
		}
	});
	var concatMap_1 = require_concatMap();
	Object.defineProperty(exports, "concatMap", {
		enumerable: true,
		get: function() {
			return concatMap_1.concatMap;
		}
	});
	var concatMapTo_1 = require_concatMapTo();
	Object.defineProperty(exports, "concatMapTo", {
		enumerable: true,
		get: function() {
			return concatMapTo_1.concatMapTo;
		}
	});
	var concatWith_1 = require_concatWith();
	Object.defineProperty(exports, "concatWith", {
		enumerable: true,
		get: function() {
			return concatWith_1.concatWith;
		}
	});
	var connect_1 = require_connect();
	Object.defineProperty(exports, "connect", {
		enumerable: true,
		get: function() {
			return connect_1.connect;
		}
	});
	var count_1 = require_count();
	Object.defineProperty(exports, "count", {
		enumerable: true,
		get: function() {
			return count_1.count;
		}
	});
	var debounce_1 = require_debounce();
	Object.defineProperty(exports, "debounce", {
		enumerable: true,
		get: function() {
			return debounce_1.debounce;
		}
	});
	var debounceTime_1 = require_debounceTime();
	Object.defineProperty(exports, "debounceTime", {
		enumerable: true,
		get: function() {
			return debounceTime_1.debounceTime;
		}
	});
	var defaultIfEmpty_1 = require_defaultIfEmpty();
	Object.defineProperty(exports, "defaultIfEmpty", {
		enumerable: true,
		get: function() {
			return defaultIfEmpty_1.defaultIfEmpty;
		}
	});
	var delay_1 = require_delay();
	Object.defineProperty(exports, "delay", {
		enumerable: true,
		get: function() {
			return delay_1.delay;
		}
	});
	var delayWhen_1 = require_delayWhen();
	Object.defineProperty(exports, "delayWhen", {
		enumerable: true,
		get: function() {
			return delayWhen_1.delayWhen;
		}
	});
	var dematerialize_1 = require_dematerialize();
	Object.defineProperty(exports, "dematerialize", {
		enumerable: true,
		get: function() {
			return dematerialize_1.dematerialize;
		}
	});
	var distinct_1 = require_distinct();
	Object.defineProperty(exports, "distinct", {
		enumerable: true,
		get: function() {
			return distinct_1.distinct;
		}
	});
	var distinctUntilChanged_1 = require_distinctUntilChanged();
	Object.defineProperty(exports, "distinctUntilChanged", {
		enumerable: true,
		get: function() {
			return distinctUntilChanged_1.distinctUntilChanged;
		}
	});
	var distinctUntilKeyChanged_1 = require_distinctUntilKeyChanged();
	Object.defineProperty(exports, "distinctUntilKeyChanged", {
		enumerable: true,
		get: function() {
			return distinctUntilKeyChanged_1.distinctUntilKeyChanged;
		}
	});
	var elementAt_1 = require_elementAt();
	Object.defineProperty(exports, "elementAt", {
		enumerable: true,
		get: function() {
			return elementAt_1.elementAt;
		}
	});
	var endWith_1 = require_endWith();
	Object.defineProperty(exports, "endWith", {
		enumerable: true,
		get: function() {
			return endWith_1.endWith;
		}
	});
	var every_1 = require_every();
	Object.defineProperty(exports, "every", {
		enumerable: true,
		get: function() {
			return every_1.every;
		}
	});
	var exhaust_1 = require_exhaust();
	Object.defineProperty(exports, "exhaust", {
		enumerable: true,
		get: function() {
			return exhaust_1.exhaust;
		}
	});
	var exhaustAll_1 = require_exhaustAll();
	Object.defineProperty(exports, "exhaustAll", {
		enumerable: true,
		get: function() {
			return exhaustAll_1.exhaustAll;
		}
	});
	var exhaustMap_1 = require_exhaustMap();
	Object.defineProperty(exports, "exhaustMap", {
		enumerable: true,
		get: function() {
			return exhaustMap_1.exhaustMap;
		}
	});
	var expand_1 = require_expand();
	Object.defineProperty(exports, "expand", {
		enumerable: true,
		get: function() {
			return expand_1.expand;
		}
	});
	var filter_1 = require_filter();
	Object.defineProperty(exports, "filter", {
		enumerable: true,
		get: function() {
			return filter_1.filter;
		}
	});
	var finalize_1 = require_finalize();
	Object.defineProperty(exports, "finalize", {
		enumerable: true,
		get: function() {
			return finalize_1.finalize;
		}
	});
	var find_1 = require_find();
	Object.defineProperty(exports, "find", {
		enumerable: true,
		get: function() {
			return find_1.find;
		}
	});
	var findIndex_1 = require_findIndex();
	Object.defineProperty(exports, "findIndex", {
		enumerable: true,
		get: function() {
			return findIndex_1.findIndex;
		}
	});
	var first_1 = require_first();
	Object.defineProperty(exports, "first", {
		enumerable: true,
		get: function() {
			return first_1.first;
		}
	});
	var groupBy_1 = require_groupBy();
	Object.defineProperty(exports, "groupBy", {
		enumerable: true,
		get: function() {
			return groupBy_1.groupBy;
		}
	});
	var ignoreElements_1 = require_ignoreElements();
	Object.defineProperty(exports, "ignoreElements", {
		enumerable: true,
		get: function() {
			return ignoreElements_1.ignoreElements;
		}
	});
	var isEmpty_1 = require_isEmpty();
	Object.defineProperty(exports, "isEmpty", {
		enumerable: true,
		get: function() {
			return isEmpty_1.isEmpty;
		}
	});
	var last_1 = require_last();
	Object.defineProperty(exports, "last", {
		enumerable: true,
		get: function() {
			return last_1.last;
		}
	});
	var map_1 = require_map();
	Object.defineProperty(exports, "map", {
		enumerable: true,
		get: function() {
			return map_1.map;
		}
	});
	var mapTo_1 = require_mapTo();
	Object.defineProperty(exports, "mapTo", {
		enumerable: true,
		get: function() {
			return mapTo_1.mapTo;
		}
	});
	var materialize_1 = require_materialize();
	Object.defineProperty(exports, "materialize", {
		enumerable: true,
		get: function() {
			return materialize_1.materialize;
		}
	});
	var max_1 = require_max();
	Object.defineProperty(exports, "max", {
		enumerable: true,
		get: function() {
			return max_1.max;
		}
	});
	var merge_1 = require_merge();
	Object.defineProperty(exports, "merge", {
		enumerable: true,
		get: function() {
			return merge_1.merge;
		}
	});
	var mergeAll_1 = require_mergeAll();
	Object.defineProperty(exports, "mergeAll", {
		enumerable: true,
		get: function() {
			return mergeAll_1.mergeAll;
		}
	});
	var flatMap_1 = require_flatMap();
	Object.defineProperty(exports, "flatMap", {
		enumerable: true,
		get: function() {
			return flatMap_1.flatMap;
		}
	});
	var mergeMap_1 = require_mergeMap();
	Object.defineProperty(exports, "mergeMap", {
		enumerable: true,
		get: function() {
			return mergeMap_1.mergeMap;
		}
	});
	var mergeMapTo_1 = require_mergeMapTo();
	Object.defineProperty(exports, "mergeMapTo", {
		enumerable: true,
		get: function() {
			return mergeMapTo_1.mergeMapTo;
		}
	});
	var mergeScan_1 = require_mergeScan();
	Object.defineProperty(exports, "mergeScan", {
		enumerable: true,
		get: function() {
			return mergeScan_1.mergeScan;
		}
	});
	var mergeWith_1 = require_mergeWith();
	Object.defineProperty(exports, "mergeWith", {
		enumerable: true,
		get: function() {
			return mergeWith_1.mergeWith;
		}
	});
	var min_1 = require_min();
	Object.defineProperty(exports, "min", {
		enumerable: true,
		get: function() {
			return min_1.min;
		}
	});
	var multicast_1 = require_multicast();
	Object.defineProperty(exports, "multicast", {
		enumerable: true,
		get: function() {
			return multicast_1.multicast;
		}
	});
	var observeOn_1 = require_observeOn();
	Object.defineProperty(exports, "observeOn", {
		enumerable: true,
		get: function() {
			return observeOn_1.observeOn;
		}
	});
	var onErrorResumeNextWith_1 = require_onErrorResumeNextWith();
	Object.defineProperty(exports, "onErrorResumeNext", {
		enumerable: true,
		get: function() {
			return onErrorResumeNextWith_1.onErrorResumeNext;
		}
	});
	var pairwise_1 = require_pairwise();
	Object.defineProperty(exports, "pairwise", {
		enumerable: true,
		get: function() {
			return pairwise_1.pairwise;
		}
	});
	var partition_1 = require_partition();
	Object.defineProperty(exports, "partition", {
		enumerable: true,
		get: function() {
			return partition_1.partition;
		}
	});
	var pluck_1 = require_pluck();
	Object.defineProperty(exports, "pluck", {
		enumerable: true,
		get: function() {
			return pluck_1.pluck;
		}
	});
	var publish_1 = require_publish();
	Object.defineProperty(exports, "publish", {
		enumerable: true,
		get: function() {
			return publish_1.publish;
		}
	});
	var publishBehavior_1 = require_publishBehavior();
	Object.defineProperty(exports, "publishBehavior", {
		enumerable: true,
		get: function() {
			return publishBehavior_1.publishBehavior;
		}
	});
	var publishLast_1 = require_publishLast();
	Object.defineProperty(exports, "publishLast", {
		enumerable: true,
		get: function() {
			return publishLast_1.publishLast;
		}
	});
	var publishReplay_1 = require_publishReplay();
	Object.defineProperty(exports, "publishReplay", {
		enumerable: true,
		get: function() {
			return publishReplay_1.publishReplay;
		}
	});
	var race_1 = require_race();
	Object.defineProperty(exports, "race", {
		enumerable: true,
		get: function() {
			return race_1.race;
		}
	});
	var raceWith_1 = require_raceWith();
	Object.defineProperty(exports, "raceWith", {
		enumerable: true,
		get: function() {
			return raceWith_1.raceWith;
		}
	});
	var reduce_1 = require_reduce();
	Object.defineProperty(exports, "reduce", {
		enumerable: true,
		get: function() {
			return reduce_1.reduce;
		}
	});
	var repeat_1 = require_repeat();
	Object.defineProperty(exports, "repeat", {
		enumerable: true,
		get: function() {
			return repeat_1.repeat;
		}
	});
	var repeatWhen_1 = require_repeatWhen();
	Object.defineProperty(exports, "repeatWhen", {
		enumerable: true,
		get: function() {
			return repeatWhen_1.repeatWhen;
		}
	});
	var retry_1 = require_retry();
	Object.defineProperty(exports, "retry", {
		enumerable: true,
		get: function() {
			return retry_1.retry;
		}
	});
	var retryWhen_1 = require_retryWhen();
	Object.defineProperty(exports, "retryWhen", {
		enumerable: true,
		get: function() {
			return retryWhen_1.retryWhen;
		}
	});
	var refCount_1 = require_refCount();
	Object.defineProperty(exports, "refCount", {
		enumerable: true,
		get: function() {
			return refCount_1.refCount;
		}
	});
	var sample_1 = require_sample();
	Object.defineProperty(exports, "sample", {
		enumerable: true,
		get: function() {
			return sample_1.sample;
		}
	});
	var sampleTime_1 = require_sampleTime();
	Object.defineProperty(exports, "sampleTime", {
		enumerable: true,
		get: function() {
			return sampleTime_1.sampleTime;
		}
	});
	var scan_1 = require_scan();
	Object.defineProperty(exports, "scan", {
		enumerable: true,
		get: function() {
			return scan_1.scan;
		}
	});
	var sequenceEqual_1 = require_sequenceEqual();
	Object.defineProperty(exports, "sequenceEqual", {
		enumerable: true,
		get: function() {
			return sequenceEqual_1.sequenceEqual;
		}
	});
	var share_1 = require_share();
	Object.defineProperty(exports, "share", {
		enumerable: true,
		get: function() {
			return share_1.share;
		}
	});
	var shareReplay_1 = require_shareReplay();
	Object.defineProperty(exports, "shareReplay", {
		enumerable: true,
		get: function() {
			return shareReplay_1.shareReplay;
		}
	});
	var single_1 = require_single();
	Object.defineProperty(exports, "single", {
		enumerable: true,
		get: function() {
			return single_1.single;
		}
	});
	var skip_1 = require_skip();
	Object.defineProperty(exports, "skip", {
		enumerable: true,
		get: function() {
			return skip_1.skip;
		}
	});
	var skipLast_1 = require_skipLast();
	Object.defineProperty(exports, "skipLast", {
		enumerable: true,
		get: function() {
			return skipLast_1.skipLast;
		}
	});
	var skipUntil_1 = require_skipUntil();
	Object.defineProperty(exports, "skipUntil", {
		enumerable: true,
		get: function() {
			return skipUntil_1.skipUntil;
		}
	});
	var skipWhile_1 = require_skipWhile();
	Object.defineProperty(exports, "skipWhile", {
		enumerable: true,
		get: function() {
			return skipWhile_1.skipWhile;
		}
	});
	var startWith_1 = require_startWith();
	Object.defineProperty(exports, "startWith", {
		enumerable: true,
		get: function() {
			return startWith_1.startWith;
		}
	});
	var subscribeOn_1 = require_subscribeOn();
	Object.defineProperty(exports, "subscribeOn", {
		enumerable: true,
		get: function() {
			return subscribeOn_1.subscribeOn;
		}
	});
	var switchAll_1 = require_switchAll();
	Object.defineProperty(exports, "switchAll", {
		enumerable: true,
		get: function() {
			return switchAll_1.switchAll;
		}
	});
	var switchMap_1 = require_switchMap();
	Object.defineProperty(exports, "switchMap", {
		enumerable: true,
		get: function() {
			return switchMap_1.switchMap;
		}
	});
	var switchMapTo_1 = require_switchMapTo();
	Object.defineProperty(exports, "switchMapTo", {
		enumerable: true,
		get: function() {
			return switchMapTo_1.switchMapTo;
		}
	});
	var switchScan_1 = require_switchScan();
	Object.defineProperty(exports, "switchScan", {
		enumerable: true,
		get: function() {
			return switchScan_1.switchScan;
		}
	});
	var take_1 = require_take();
	Object.defineProperty(exports, "take", {
		enumerable: true,
		get: function() {
			return take_1.take;
		}
	});
	var takeLast_1 = require_takeLast();
	Object.defineProperty(exports, "takeLast", {
		enumerable: true,
		get: function() {
			return takeLast_1.takeLast;
		}
	});
	var takeUntil_1 = require_takeUntil();
	Object.defineProperty(exports, "takeUntil", {
		enumerable: true,
		get: function() {
			return takeUntil_1.takeUntil;
		}
	});
	var takeWhile_1 = require_takeWhile();
	Object.defineProperty(exports, "takeWhile", {
		enumerable: true,
		get: function() {
			return takeWhile_1.takeWhile;
		}
	});
	var tap_1 = require_tap();
	Object.defineProperty(exports, "tap", {
		enumerable: true,
		get: function() {
			return tap_1.tap;
		}
	});
	var throttle_1 = require_throttle();
	Object.defineProperty(exports, "throttle", {
		enumerable: true,
		get: function() {
			return throttle_1.throttle;
		}
	});
	var throttleTime_1 = require_throttleTime();
	Object.defineProperty(exports, "throttleTime", {
		enumerable: true,
		get: function() {
			return throttleTime_1.throttleTime;
		}
	});
	var throwIfEmpty_1 = require_throwIfEmpty();
	Object.defineProperty(exports, "throwIfEmpty", {
		enumerable: true,
		get: function() {
			return throwIfEmpty_1.throwIfEmpty;
		}
	});
	var timeInterval_1 = require_timeInterval();
	Object.defineProperty(exports, "timeInterval", {
		enumerable: true,
		get: function() {
			return timeInterval_1.timeInterval;
		}
	});
	var timeout_1 = require_timeout();
	Object.defineProperty(exports, "timeout", {
		enumerable: true,
		get: function() {
			return timeout_1.timeout;
		}
	});
	var timeoutWith_1 = require_timeoutWith();
	Object.defineProperty(exports, "timeoutWith", {
		enumerable: true,
		get: function() {
			return timeoutWith_1.timeoutWith;
		}
	});
	var timestamp_1 = require_timestamp();
	Object.defineProperty(exports, "timestamp", {
		enumerable: true,
		get: function() {
			return timestamp_1.timestamp;
		}
	});
	var toArray_1 = require_toArray();
	Object.defineProperty(exports, "toArray", {
		enumerable: true,
		get: function() {
			return toArray_1.toArray;
		}
	});
	var window_1 = require_window();
	Object.defineProperty(exports, "window", {
		enumerable: true,
		get: function() {
			return window_1.window;
		}
	});
	var windowCount_1 = require_windowCount();
	Object.defineProperty(exports, "windowCount", {
		enumerable: true,
		get: function() {
			return windowCount_1.windowCount;
		}
	});
	var windowTime_1 = require_windowTime();
	Object.defineProperty(exports, "windowTime", {
		enumerable: true,
		get: function() {
			return windowTime_1.windowTime;
		}
	});
	var windowToggle_1 = require_windowToggle();
	Object.defineProperty(exports, "windowToggle", {
		enumerable: true,
		get: function() {
			return windowToggle_1.windowToggle;
		}
	});
	var windowWhen_1 = require_windowWhen();
	Object.defineProperty(exports, "windowWhen", {
		enumerable: true,
		get: function() {
			return windowWhen_1.windowWhen;
		}
	});
	var withLatestFrom_1 = require_withLatestFrom();
	Object.defineProperty(exports, "withLatestFrom", {
		enumerable: true,
		get: function() {
			return withLatestFrom_1.withLatestFrom;
		}
	});
	var zip_1 = require_zip();
	Object.defineProperty(exports, "zip", {
		enumerable: true,
		get: function() {
			return zip_1.zip;
		}
	});
	var zipAll_1 = require_zipAll();
	Object.defineProperty(exports, "zipAll", {
		enumerable: true,
		get: function() {
			return zipAll_1.zipAll;
		}
	});
	var zipWith_1 = require_zipWith();
	Object.defineProperty(exports, "zipWith", {
		enumerable: true,
		get: function() {
			return zipWith_1.zipWith;
		}
	});
}));
// node_modules/@angular/core/fesm2022/_resource-chunk.mjs
/**
* @license Angular v22.2.5
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var OutputEmitterRef = class {
	destroyed = false;
	listeners = null;
	errorHandler = inject(ErrorHandler, { optional: true });
	isEmitting = false;
	hasNullListeners = false;
	destroyRef = inject(DestroyRef);
	constructor() {
		this.destroyRef.onDestroy(() => {
			this.destroyed = true;
			this.listeners = null;
		});
	}
	subscribe(callback) {
		if (this.destroyed) throw new RuntimeError(953, ngDevMode && "Unexpected subscription to destroyed `OutputRef`. The owning directive/component is destroyed.");
		(this.listeners ??= []).push(callback);
		return { unsubscribe: () => {
			const index = this.listeners ? this.listeners.indexOf(callback) : -1;
			if (index > -1) {
				if (this.isEmitting) {
					this.hasNullListeners = true;
					this.listeners[index] = null;
				} else this.listeners.splice(index, 1);
			}
		} };
	}
	emit(value) {
		if (this.destroyed) {
			console.warn(formatRuntimeError(953, ngDevMode && "Unexpected emit for destroyed `OutputRef`. The owning directive/component is destroyed."));
			return;
		}
		if (this.listeners === null) return;
		this.isEmitting = true;
		const previousConsumer = setActiveConsumer(null);
		try {
			for (const listenerFn of this.listeners) try {
				if (listenerFn !== null) listenerFn(value);
			} catch (err) {
				this.errorHandler?.handleError(err);
			}
		} finally {
			if (this.hasNullListeners) {
				this.hasNullListeners = false;
				this.listeners && removeNullValues(this.listeners);
			}
			setActiveConsumer(previousConsumer);
			this.isEmitting = false;
		}
	}
};
function removeNullValues(arr) {
	let i = arr.length - 1;
	while (i > -1) {
		if (arr[i] === null) arr.splice(i, 1);
		i--;
	}
}
function getOutputDestroyRef(ref) {
	return ref.destroyRef;
}
var CACHE_ACTIVE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "STATE_CACHE_ACTIVE" : "");
function computed(computation, options) {
	const getter = createComputed(computation, options?.equal);
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		const debugName = options?.debugName;
		getter[SIGNAL].debugName = debugName;
		getter.toString = () => `[Computed${debugName ? " (" + debugName + ")" : ""}: ${getter()}]`;
	}
	return getter;
}
function untracked(nonReactiveReadsFn) {
	return untracked$1(nonReactiveReadsFn);
}
var ResourceDependencyError = class extends Error {
	dependency;
	constructor(dependency) {
		super("Dependency error", { cause: dependency.error() });
		this.name = "ResourceDependencyError";
		this.dependency = dependency;
	}
};
var ResourceParamsStatus = class ResourceParamsStatus extends Error {
	_brand;
	constructor(msg) {
		super(msg);
	}
	static IDLE = new ResourceParamsStatus("IDLE");
	static LOADING = new ResourceParamsStatus("LOADING");
};
var identityFn = (v) => v;
function linkedSignal(optionsOrComputation, options) {
	if (typeof optionsOrComputation === "function") return upgradeLinkedSignalGetter(createLinkedSignal(optionsOrComputation, identityFn, options?.equal), typeof ngDevMode !== "undefined" && ngDevMode ? options?.debugName : void 0, options?.set);
	else return upgradeLinkedSignalGetter(createLinkedSignal(optionsOrComputation.source, optionsOrComputation.computation, optionsOrComputation.equal), typeof ngDevMode !== "undefined" && ngDevMode ? optionsOrComputation.debugName : void 0, optionsOrComputation.set);
}
function upgradeLinkedSignalGetter(getter, debugName, customSet) {
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		getter[SIGNAL].debugName = debugName;
		getter.toString = () => `[LinkedSignal${debugName ? " (" + debugName + ")" : ""}: ${getter()}]`;
	}
	const node = getter[SIGNAL];
	const upgradedGetter = getter;
	if (customSet !== void 0) {
		const rawSet = (newValue) => linkedSignalSetFn(node, newValue);
		upgradedGetter.set = (newValue) => customSet(newValue, rawSet);
		upgradedGetter.update = (updateFn) => customSet(updateFn(untracked(getter)), rawSet);
	} else {
		upgradedGetter.set = (newValue) => linkedSignalSetFn(node, newValue);
		upgradedGetter.update = (updateFn) => linkedSignalUpdateFn(node, updateFn);
	}
	upgradedGetter.asReadonly = signalAsReadonlyFn.bind(getter);
	return upgradedGetter;
}
function resource(options) {
	if (ngDevMode && !options?.injector) assertInInjectionContext(resource);
	const oldNameForParams = options.request;
	return new ResourceImpl(options.params ?? oldNameForParams ?? (() => null), getLoader(options), options.defaultValue, options.equal ? wrapEqualityFn(options.equal) : void 0, options.debugName, options.injector ?? inject(Injector), options.id);
}
var BaseWritableResource = class {
	value;
	isLoading;
	constructor(value, debugName) {
		this.value = value;
		this.value.set = this.set.bind(this);
		this.value.update = this.update.bind(this);
		this.value.asReadonly = signalAsReadonlyFn;
		this.isLoading = computed(() => this.status() === "loading" || this.status() === "reloading", ngDevMode ? createDebugNameObject(debugName, "isLoading") : void 0);
	}
	isError = computed(() => this.status() === "error");
	update(updateFn) {
		this.set(updateFn(untracked(this.value)));
	}
	isValueDefined = computed(() => {
		if (this.isError()) return false;
		return this.value() !== void 0;
	});
	_snapshot;
	get snapshot() {
		return this._snapshot ??= computed(() => {
			const status = this.status();
			if (status === "error") return {
				status: "error",
				error: this.error()
			};
			else return {
				status,
				value: this.value()
			};
		});
	}
	hasValue() {
		return this.isValueDefined();
	}
	asReadonly() {
		return this;
	}
};
var ResourceImpl = class extends BaseWritableResource {
	loaderFn;
	equal;
	debugName;
	transferCacheKey;
	pendingTasks;
	state;
	extRequest;
	effectRef;
	pendingController;
	resolvePendingTask = void 0;
	destroyed = false;
	unregisterOnDestroy;
	status;
	error;
	transferState;
	constructor(request, loaderFn, defaultValue, equal, debugName, injector, transferCacheKey, getInitialStream) {
		if (isInParamsFunction()) throw invalidResourceCreationInParams();
		super(computed(() => {
			const streamValue = this.state().stream?.();
			if (!streamValue) return defaultValue;
			if (this.state().status === "loading" && this.error()) return defaultValue;
			if (!isResolved(streamValue)) throw new ResourceValueError(this.error());
			return streamValue.value;
		}, {
			equal,
			...ngDevMode ? createDebugNameObject(debugName, "value") : void 0
		}), debugName);
		this.loaderFn = loaderFn;
		this.equal = equal;
		this.debugName = debugName;
		this.transferCacheKey = transferCacheKey;
		const cacheState = injector.get(CACHE_ACTIVE, void 0, { optional: true }) ?? { isActive: false };
		this.transferState = injector.get(TransferState, void 0, { optional: true }) ?? void 0;
		const paramsSignal = isSignal(request) ? request : computed(() => {
			try {
				setInParamsFunction(true);
				return request(paramsContext);
			} finally {
				setInParamsFunction(false);
			}
		}, ngDevMode ? createDebugNameObject(debugName, "params") : void 0);
		this.extRequest = linkedSignal(() => {
			try {
				setInParamsFunction(true);
				return {
					request: paramsSignal(),
					reload: 0
				};
			} catch (error) {
				rethrowFatalErrors(error);
				if (error === ResourceParamsStatus.IDLE) return {
					status: "idle",
					reload: 0
				};
				else if (error === ResourceParamsStatus.LOADING) return {
					status: "loading",
					reload: 0
				};
				return {
					error: encapsulateResourceError(error),
					reload: 0
				};
			} finally {
				setInParamsFunction(false);
			}
		}, ngDevMode ? createDebugNameObject(debugName, "extRequest") : void 0);
		this.state = linkedSignal({
			source: this.extRequest,
			computation: (extRequest, previous) => {
				let { request, status, error } = extRequest;
				let stream;
				if (error) {
					status = "resolved";
					stream = signal({ error }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0);
				} else if (!status) {
					if (!previous) {
						const transferState = this.transferState;
						const cacheKey = this.transferCacheKey;
						if (cacheState.isActive && cacheKey && transferState && request !== void 0) {
							if (transferState.hasKey(cacheKey)) stream = signal({ value: transferState.get(cacheKey, defaultValue) }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0);
						}
						if (!stream) stream = getInitialStream?.(extRequest.request);
						getInitialStream = void 0;
						status = request === void 0 ? "idle" : stream ? "resolved" : "loading";
					} else {
						status = request === void 0 ? "idle" : "loading";
						if (previous.value.extRequest.request === request) stream = previous.value.stream;
					}
				}
				return {
					extRequest,
					status,
					previousStatus: previous ? projectStatusOfState(previous.value) : "idle",
					stream
				};
			},
			...ngDevMode ? createDebugNameObject(debugName, "state") : void 0
		});
		this.effectRef = effect(this.loadEffect.bind(this), {
			injector,
			manualCleanup: true,
			...ngDevMode ? createDebugNameObject(debugName, "loadEffect") : void 0
		});
		this.pendingTasks = injector.get(PendingTasks);
		this.unregisterOnDestroy = injector.get(DestroyRef).onDestroy(() => this.destroy());
		this.status = computed(() => projectStatusOfState(this.state()), ngDevMode ? createDebugNameObject(debugName, "status") : void 0);
		this.error = computed(() => {
			const stream = this.state().stream?.();
			return stream && !isResolved(stream) ? stream.error : void 0;
		}, ngDevMode ? createDebugNameObject(debugName, "error") : void 0);
	}
	set(value) {
		if (this.destroyed) return;
		const error = untracked(this.error);
		const state = untracked(this.state);
		if (!error) {
			const current = untracked(this.value);
			if (state.status === "local" && (this.equal ? this.equal(current, value) : current === value)) return;
		}
		this.state.set({
			extRequest: state.extRequest,
			status: "local",
			previousStatus: "local",
			stream: signal({ value }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0)
		});
		this.abortInProgressLoad();
	}
	reload() {
		const { status } = untracked(this.state);
		if (status === "idle" || status === "loading") return false;
		this.extRequest.update(({ request, reload }) => ({
			request,
			reload: reload + 1
		}));
		return true;
	}
	destroy() {
		this.destroyed = true;
		this.unregisterOnDestroy();
		this.effectRef.destroy();
		this.abortInProgressLoad();
		this.state.set({
			extRequest: {
				request: void 0,
				reload: 0
			},
			status: "idle",
			previousStatus: "idle",
			stream: void 0
		});
	}
	async loadEffect() {
		const extRequest = this.extRequest();
		const { status: currentStatus, previousStatus } = untracked(this.state);
		if (extRequest.request === void 0) return;
		else if (currentStatus !== "loading") return;
		this.abortInProgressLoad();
		let resolvePendingTask = this.resolvePendingTask = this.pendingTasks.add();
		const { signal: abortSignal } = this.pendingController = new AbortController();
		try {
			const stream = untracked(() => {
				return this.loaderFn({
					params: extRequest.request,
					abortSignal,
					previous: { status: previousStatus }
				});
			});
			const shouldDiscard = () => abortSignal.aborted || untracked(this.extRequest) !== extRequest;
			if (isSignal(stream)) {
				if (shouldDiscard()) return;
				this.state.set({
					extRequest,
					status: "resolved",
					previousStatus: "resolved",
					stream
				});
				saveToTransferState(untracked(stream), this.transferCacheKey, this.transferState);
			} else {
				const resolvedStream = await stream;
				if (shouldDiscard()) return;
				this.state.set({
					extRequest,
					status: "resolved",
					previousStatus: "resolved",
					stream: resolvedStream
				});
				saveToTransferState(resolvedStream ? untracked(resolvedStream) : void 0, this.transferCacheKey, this.transferState);
			}
		} catch (err) {
			rethrowFatalErrors(err);
			if (abortSignal.aborted || untracked(this.extRequest) !== extRequest) return;
			this.state.set({
				extRequest,
				status: "resolved",
				previousStatus: "error",
				stream: signal({ error: encapsulateResourceError(err) }, ngDevMode ? createDebugNameObject(this.debugName, "stream") : void 0)
			});
		} finally {
			resolvePendingTask?.();
			resolvePendingTask = void 0;
		}
	}
	abortInProgressLoad() {
		untracked(() => this.pendingController?.abort());
		this.pendingController = void 0;
		this.resolvePendingTask?.();
		this.resolvePendingTask = void 0;
	}
};
function saveToTransferState(result, transferCacheKey, transferState) {
	if (transferCacheKey && transferState && result && isResolved(result)) transferState.set(transferCacheKey, result.value);
}
function wrapEqualityFn(equal) {
	return (a, b) => a === void 0 || b === void 0 ? a === b : equal(a, b);
}
function getLoader(options) {
	if (isStreamingResourceOptions(options)) return options.stream;
	return async (params) => {
		try {
			return signal({ value: await options.loader(params) }, ngDevMode ? createDebugNameObject(options.debugName, "stream") : void 0);
		} catch (err) {
			return signal({ error: encapsulateResourceError(err) }, ngDevMode ? createDebugNameObject(options.debugName, "stream") : void 0);
		}
	};
}
function isStreamingResourceOptions(options) {
	return !!options.stream;
}
function projectStatusOfState(state) {
	switch (state.status) {
		case "loading": return state.extRequest.reload === 0 ? "loading" : "reloading";
		case "resolved": return isResolved(state.stream()) ? "resolved" : "error";
		default: return state.status;
	}
}
function isResolved(state) {
	return state.error === void 0;
}
function createDebugNameObject(resourceDebugName, internalSignalDebugName) {
	return { debugName: `Resource${resourceDebugName ? "#" + resourceDebugName : ""}.${internalSignalDebugName}` };
}
function encapsulateResourceError(error) {
	if (isErrorLike(error)) return error;
	return new ResourceWrappedError(error);
}
var ResourceValueError = class extends Error {
	constructor(error) {
		super(ngDevMode ? `Resource is currently in an error state (see Error.cause for details): ${error.message}` : error.message, { cause: error });
	}
};
var ResourceWrappedError = class extends Error {
	constructor(error) {
		super(ngDevMode ? `Resource returned an error that's not an Error instance: ${String(error)}. Check this error's .cause for the actual error.` : String(error), { cause: error });
	}
};
function chain(resource) {
	switch (resource.status()) {
		case "idle": throw ResourceParamsStatus.IDLE;
		case "error": throw new ResourceDependencyError(resource);
		case "loading":
		case "reloading": throw ResourceParamsStatus.LOADING;
	}
	return resource.value();
}
var paramsContext = { chain };
var inParamsFunction = false;
function isInParamsFunction() {
	return inParamsFunction;
}
function setInParamsFunction(value) {
	inParamsFunction = value;
}
function invalidResourceCreationInParams() {
	return new RuntimeError(992, ngDevMode && `Cannot create a resource inside the \`params\` of another resource`);
}
function rethrowFatalErrors(error) {
	if (error instanceof RuntimeError && error.code === 992) throw error;
}
export { NG_PIPE_DEF as $, updateAncestorTraversalFlagsOnAttach as $i, getInjectableDef as $n, keyValueArraySet as $r, assertParentView as $t, EMPTY_OBJ as A, producerAccessed as Aa, setCurrentDirectiveIndex as Ai, fillProperties as An, isCurrentTNodeParent as Ar, assertFirstUpdatePass as At, INJECTOR$1 as B, setSelectedIndex as Bi, getComponentLViewByIndex as Bn, isInjectable as Br, assertLContainer as Bt, ChangeDetectionScheduler as C, SIGNAL_NODE as Ca, retrieveTransferredState as Ci, emitInjectorToCreateInstanceEvent as Cn, injectRootLimpMode as Cr, arraySplice as Ct, DOC_PAGE_BASE_URL as D, consumerPollProducersForChange as Da, scheduleCallbackWithRafRace as Di, enterDI as Dn, isComponentHost as Dr, assertElement as Dt, DOCUMENT as E, consumerDestroy as Ea, scheduleCallbackWithMicrotask as Ei, encapsulateBoundaryError as En, isComponentDef as Er, assertDomNode as Et, EnvironmentInjector as F, setInjectImplementation as Fi, getBindingIndex as Fn, isForwardRef as Fr, assertInInjectionContext as Ft, Injector as G, storeLViewOnDestroy as Gi, getCurrentParentTNode as Gn, isRootView as Gr, assertNotDefined as Gt, INJECTOR_SCOPE as H, signalAsReadonlyFn as Hi, getContextLView as Hn, isLView as Hr, assertLessThan as Ht, ErrorHandler as I, setInjectorProfiler as Ii, getBindingRoot as In, isInCheckNoChangesMode as Ir, assertIndexInDeclRange as It, NG_DIR_DEF as J, throwError as Ji, getCurrentTNodePlaceholderOk as Jn, isStandalone as Jr, assertNotReactive as Jt, MATH_ML_NAMESPACE as K, stringify as Ki, getCurrentQueryIndex as Kn, isSignal as Kr, assertNotEqual as Kt, EventEmitter as L, setInjectorProfilerContext as Li, getBindingsEnabled as Ln, isInI18nBlock as Lr, assertIndexInExpandoRange as Lt, ERROR_DETAILS_PAGE_BASE_URL as M, setActiveConsumer as Ma, setCurrentTNode as Mi, formatRuntimeError as Mn, isDirectiveHost as Mr, assertGreaterThan as Mt, EffectRefImpl as N, setThrowInvalidWriteToSignalError as Na, setCurrentTNodeAsNotParent as Ni, forwardRef as Nn, isEnvironmentProviders as Nr, assertGreaterThanOrEqual as Nt, DestroyRef as O, createComputed as Oa, setBindingIndex as Oi, enterView as On, isContentQueryHost as Or, assertEqual as Ot, EffectScheduler as P, signalSetFn as Pa, setInI18nBlock as Pi, getAllSpecialProviders as Pn, isExhaustiveCheckNoChanges as Pr, assertHasParent as Pt, NG_MOD_DEF as Q, unwrapRNode as Qi, getFactoryDef as Qn, keyValueArrayIndexOf as Qr, assertOneOf as Qt, IMAGE_CONFIG as R, setIsInCheckNoChangesMode as Ri, getClosureSafeProperty as Rn, isInInjectionContext as Rr, assertIndexInRange as Rt, CSP_NONCE as S, SIGNAL as Sa, resolveForwardRef as Si, emitInjectEvent as Sn, inject as Sr, arrayInsert2 as St, DEBUG_TASK_TRACKER as T, consumerBeforeComputation as Ta, runInInjectorProfilerContext as Ti, emitProviderConfiguredEvent as Tn, isClassProvider as Tr, assertDirectiveDef as Tt, INTERNAL_APPLICATION_ERROR_HANDLER as U, store as Ui, getCurrentDirectiveDef as Un, isProjectionTNode as Ur, assertNgModuleType as Ut, INJECTOR_DEF_TYPES as V, signal as Vi, getConstant as Vn, isLContainer as Vr, assertLView as Vt, InjectionToken as W, storeCleanupWithContext as Wi, getCurrentDirectiveIndex as Wn, isRefreshingViews as Wr, assertNodeInjector as Wt, NG_FACTORY_DEF as X, truncateMiddle as Xi, getDirectiveDefOrThrow as Xn, isWritableSignal as Xr, assertNumber as Xt, NG_ELEMENT_ID as Y, throwProviderNotFoundError as Yi, getDirectiveDef as Yn, isTypeProvider as Yr, assertNotSame as Yt, NG_INJ_DEF as Z, unwrapLView as Zi, getElementDepthCount as Zn, keyValueArrayGet as Zr, assertNumberInRange as Zt, untracked as _, ɵɵrestoreView as _a, removeFromArray as _i, cyclicDependencyErrorWithDetails as _n, hasI18n as _r, ZONELESS_ENABLED as _t, ResourceParamsStatus as a, wasLastNodeCreated as aa, makeEnvironmentProviders as ai, assertTNodeCreationIndex as an, getNativeByTNode as ar, PLATFORM_INITIALIZER as at, APP_ID as b, ERRORED as ba, requiresRefreshOrTraversal as bi, deepForEach as bn, incrementBindingIndex as br, angularZoneInstanceIdProperty as bt, computed as c, ɵɵdefineInjector as ca, markViewForRefresh as ci, attachInjectFlag as cn, getNgModuleDefOrThrow as cr, PendingTasksInternal as ct, invalidResourceCreationInParams as d, ɵɵinject as da, nextContextImpl as di, convertToBitFlags as dn, getOrCreateTViewCleanup as dr, SCHEDULE_IN_ROOT_ZONE as dt, validAppIdInitializer as ea, lastNodeWasCreated as ei, assertProjectionSlots as en, getInjectorDef as er, NG_PROV_DEF as et, isInParamsFunction as f, ɵɵinvalidFactoryDep as fa, promiseWithResolvers as fi, createDictionary as fn, getPipeDef as fr, SecurityContext as ft, setInParamsFunction as g, ɵɵresetView as ga, registerSpecialProvider as gi, cyclicDependencyError as gn, getTView as gr, XSS_SECURITY_URL as gt, rethrowFatalErrors as h, ɵɵnamespaceSVG as ha, providerToFactory as hi, createViewEffect as hn, getTNode as hr, Version as ht, ResourceImpl as i, walkUpViews as ia, load as ii, assertTNode as in, getNativeByIndex as ir, PLATFORM_ID as it, ENVIRONMENT_INITIALIZER as j, producerUpdateValueVersion as ja, setCurrentQueryIndex as ji, flatten as jn, isDestroyed as jr, assertFunction as jt, EMPTY_ARRAY as k, getActiveConsumer as ka, setBindingRootForHostBindings as ki, errorHandlerEnvironmentInitializer as kn, isCreationMode as kr, assertFirstCreatePass as kt, encapsulateResourceError as l, ɵɵdisableBindings as la, newArray as li, checkSecurityContext as ln, getNullInjector as lr, R3Injector as lt, resource as m, ɵɵnamespaceMathML as ma, provideEnvironmentInitializer as mi, createInjectorWithoutInjectorInstances as mn, getSelectedTNode as mr, VERSION as mt, OutputEmitterRef as n, viewAttachedToContainer as na, leaveSkipHydrationBlock as ni, assertString as nn, getLViewParent as nr, NoopNgZone as nt, ResourceValueError as o, ɵunwrapWritableSignal as oa, makeStateKey as oi, assertTNodeForLView as on, getNativeByTNodeOrNull as or, PROVIDED_ZONELESS as ot, linkedSignal as p, ɵɵnamespaceHTML as pa, provideBrowserGlobalErrorListeners as pi, createInjector as pn, getSelectedIndex as pr, TransferState as pt, NG_COMP_DEF as q, stringifyForError as qi, getCurrentTNode as qn, isSkipHydrationRootTNode as qr, assertNotInReactiveContext as qt, ResourceDependencyError as r, walkProviderTree as ra, leaveView as ri, assertTIcu as rn, getNamespace as rr, NullInjector as rt, chain as s, ɵɵdefineInjectable as sa, markAncestorsForTraversal as si, assertTNodeForTView as sn, getNgModuleDef as sr, PendingTasks as st, CACHE_ACTIVE as t, viewAttachedToChangeDetector as ta, leaveDI as ti, assertSame as tn, getLView as tr, NgZone as tt, getOutputDestroyRef as u, ɵɵenableBindings as ua, nextBindingIndex as ui, concatStringsWithSpace as un, getOrCreateLViewCleanup as ur, RuntimeError as ut, require_operators as v, require_cjs as va, removeLViewOnDestroy as vi, debugStringifyTypeForError as vn, importProvidersFrom as vr, _global as vt, CheckNoChangesMode as w, consumerAfterComputation as wa, runInInjectionContext as wi, emitInstanceCreatedByInjectorEvent as wn, internalImportProvidersFrom as wr, assertDefined as wt, CONTAINER_HEADER_OFFSET as x, REACTIVE_NODE as xa, resetPreOrderHookFlags as xi, effect as xn, initNgDevMode as xr, arrayEquals as xt, ANIMATION_MODULE_TYPE as y, setCurrentInjector as ya, renderStringify as yi, decreaseElementDepthCount as yn, increaseElementDepthCount as yr, addToArray as yt, IMAGE_CONFIG_DEFAULTS as z, setIsRefreshingViews as zi, getComponentDef as zn, isInSkipHydrationBlock as zr, assertInjectImplementationNotEqual as zt };
