$(document).ready(function() {
    var notaId = $("#notaId").val();

    // Mostrar modal
    $(document).on("click", "#btnNuevaNota", function () {
        $("#NuevaNota").modal('show');
    });

    // Crear nota
    $(document).on("click", "#guardarNota", function () {
        var titulo = $("#titulo").val();
        var tamaño = $("#tamaño").val();
        var color = $("#color").val();
        var nuevaNota = `<div class="col-12 col-md-6 col-lg-4 ${tamaño} mb-3" id="nota-${notaId}">
            <div class="card text-white bg-${color} mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title">${titulo}</h5>
                </div>
                <div class="card-footer d-flex justify-content-end">
                    <button class="btn btn-secondary" id="Borrar" data-id="${notaId}">Borrar</button>
                    <button class="btn btn-info" id="Editar" data-id="${notaId}">Editar</button>
                </div>
            </div>
        </div>`;
        $("#NuevaNota").modal('hide');
        $(nuevaNota).appendTo("#contenedor");
    });

    //Borrar nota
     $(document).on("click", "#Borrar", function () {  
        var notaId = $(this).data("id");
        $("#nota-" + notaId).remove();
        $(this).closest(".col-12").remove();
    });

    // Editar nota
    $(document).on("click", "#Editar", function(){
        $("#NuevaNota").modal('show');
        var titulo = $("#titulo").val();
        var notaId = $(this).data("id");
        $("#nota-" + notaId).val();
        var tamaño = $("#tamaño").val();
        var color = $("#color").val();
        var nuevaNota = `<div class="col-12 col-md-6 col-lg-4 ${tamaño} mb-3" id="nota-${notaId}">
            <div class="card text-white bg-${color} mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title">${titulo}</h5>
                </div>
                <div class="card-footer d-flex justify-content-end">
                    <button class="btn btn-secondary" id="Borrar" data-id="${notaId}">Borrar</button>
                    <button class="btn btn-info" id="Editar" data-id="${notaId}">Editar</button>
                </div>
            </div>
        </div>`;
        $("#NuevaNota").modal('hide');
        $(nuevaNota).appendTo("#nota-" + notaId);
    })

});